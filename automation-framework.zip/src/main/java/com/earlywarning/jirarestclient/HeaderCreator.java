/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.jirarestclient;

import java.nio.charset.Charset;
import java.util.Map;
import java.util.Set;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;

import com.earlywarning.jirarestclient.utilities.Encryption;

import lombok.Data;

/**
 * <p>A class that creates the headers for the message that is being sent to Jira XRay.</p>
 * <p>There are two properties associated with this class:</p><ul>
 * 	<li>username</li>
 * 	<li>password</li></ul>
 * <p>The properties are set by the Springframework to the values contained in the 
 * application.properties file. These properties in the file are encrypted and are
 * decrypted at runtime to create the authorization header.
 * @author cornettl
 *
 */
public class HeaderCreator {
	
	@Value("${user}")
	String username;
	
	@Value("${password}")
	String password;

	/**
	 * <p>A method to create the message headers from a map containing the header name
	 * and the value for that header.</p>
	 * <p>Currently only two headers are supported:</p><ul>
	 * 	<li>Authroization</li>
	 * 	<li>Content-Type</li></ul> 
	 * @param headers The map containing the header names and values.
	 * @return An instance of the HttpHeaders class.
	 */
	public HttpHeaders createHeaders(Map<String, String> headers) {
		HttpHeaders httpHeaders = new HttpHeaders();
		Set<String> keys = headers.keySet();
		
		for (String key : keys) {
			switch (key) {
			case "Authorization":
				httpHeaders.add(key, headers.get(key));
				break;
			case "Content-Type":
				httpHeaders.add(key, headers.get(key));
				break;
			}
		}
		return httpHeaders;
	}
	
	/**
	 * A method that decrypts the username and password and then creates a 
	 * byte array of the of the credentials that are Base64 encoded. The byte
	 * array is converted to a String and prepended with the authentication 
	 * type which is 'Basic'.
	 * @return The Base64 encoded credentials.
	 */
	public String encodeCreds() {
		Encryption enc = new Encryption();
		String auth = enc.decrypt(username) + ":" + enc.decrypt(password);
		byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
		String headerValue = "Basic " + new String(encodedAuth);
		return headerValue;
	}

}
