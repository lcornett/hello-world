package com.earlywarning.authentication.common;

import lombok.Data;

/**
 * A POJO representing the name element of an Authentify JSON request.
 * This class utilizes the lombok Data annotation to implement Setters and getters
 * for the private properties:<ul>
 * 	<li>firstName</li>
 * 	<li>middleName</li>
 * 	<li>lastName</li></ul>
 * See the 
 * <a href="{@docRoot}/com/earlywarning/authentication/common/package-summary.html#tags">
 * package-info</a> page for more information about the annotation.
 * @author cornettl
 *
 */
@Data
//@JsonInclude(Include.NON_NULL)
public class Name {
	private String firstName;
	private String middleName;
	private String lastName;
	
}
