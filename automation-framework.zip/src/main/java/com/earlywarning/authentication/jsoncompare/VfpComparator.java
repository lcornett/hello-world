/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.jsoncompare;

import com.earlywarning.authentication.common.Vfp;

import lombok.extern.log4j.Log4j2;

/**
 * A class that compares the value of the properties of two instances of a Vfp class
 * @author cornettl
 *
 */
@Log4j2
class VfpComparator extends StringComparator {

	/**
	 * A method that compares the values of two two instances of the Vfp class.
	 * @param actual The instance being compared
	 * @param expected The instance being compared to
	 * @return true of the values are the same, false otherwise
	 */
	boolean compareVfp(Vfp actual, Vfp expected) {
		final String comparator = "data.dataLookup.vfp.";
		String actualValue = "";
		String expectedValue = "";
		String[] elements = {"value"};
		
		try {
			if ((null == actual) && (null == expected)) {
				return status;
			}
			
			for (String element : elements) {
				switch (element) {
					case "value":
						actualValue = actual.getValue();
						expectedValue = expected.getValue();
						updateStatus(compareString(comparator + element, actualValue, expectedValue));
				}
			}
			
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		return status;
	}
}
