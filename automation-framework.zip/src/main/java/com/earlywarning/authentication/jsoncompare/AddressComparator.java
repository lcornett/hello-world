/**
  * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.jsoncompare;

import com.earlywarning.authentication.common.Address;

import lombok.extern.log4j.Log4j2;

/**
 * A class that compares the values of the elements of two Address elements. 
 * @author cornettl
 *
 */
@Log4j2
class AddressComparator extends StringComparator {
	
	/**
	 * A method that compares the elements of two Address objects
	 * @param actual The address being compared.
	 * @param expected The address being compared to.
	 * @return true if the element values match, false otherwise
	 */
	boolean compareAddress(Address actual, Address expected) {
		final String comparator = "data.dataLookup.address.";
		String actualValue = "";
		String expectedValue = "";
		String[] elements = {"streetAddress", "extendedAddress", "city", "postalCode", "region", "country"};
		
		try {
			
			if ((null == actual) && (null == expected)) {
				String msg = "The actual and the expected Address are both null!";
				log.info(msg);
				return status;
			}
			
			for (String element : elements) {
				switch (element) {
					case "city":
						actualValue = actual.getCity();
						expectedValue = expected.getCity();
						updateStatus(compareString(comparator + element, actualValue, expectedValue));
						break;
					case "country":
						actualValue = actual.getCountry();
						expectedValue = expected.getCountry();
						updateStatus(compareString(comparator + element, actualValue, expectedValue));
						break;
					case "extendedAddress":
						actualValue = actual.getExtendedAddress();
						expectedValue = expected.getExtendedAddress();
						updateStatus(compareString(comparator + element, actualValue, expectedValue));
						break;
					case "postalCode":
						actualValue = actual.getPostalCode();
						expectedValue = expected.getPostalCode();
						updateStatus(compareString(comparator + element, actualValue, expectedValue));
						break;
					case "region":
						actualValue = actual.getCity();
						expectedValue = expected.getCity();
						updateStatus(compareString(comparator + element, actualValue, expectedValue));
						break;
					case "streetAddress":
						actualValue = actual.getStreetAddress();
						expectedValue = expected.getStreetAddress();
						updateStatus(compareString(comparator + element, actualValue, expectedValue));
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		return status;
	}

}
