/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.ccv;

/**
 * The properties of this interface relate to the field names in the 
 * Authentify request and response messages. The request field properties
 * basically ensure that the name of the fields are not misspelled. The
 * response field properties evaluate to the JsonPath of the field in 
 * the response message. This allows for easy evaluation and validation
 * of the response message.
  * @author cornettl
 *
 */
public interface CCVFieldConstants {
	// request fields
	String REQUESTID = "RequestId";
	String API_CLIENT_ID = "ApiClientId";
	String SUB_CLIENT_ID = "SubClientId";
	String PAYFONE_ALIAS = "PayfoneAlias";
	String MOBILE_NUMBER = "MobileNumber";
	String MOBILE_STATUS_CHECK = "MobileStatusCheck";
	String MOBILE_CALL_VERIFICATION_CHECK = "MobileCallVerificationCheck";
	String MOBILE_CALL_VERIFICATION_DID = "MobileCallVerificationDID";
	String CALL_ARRIVAL_TIMESTAMP = "CallArrivalTimestamp";
	String MOBILE_IDENTITY_CHECK = "MobileIdentityCheck";
	String MOBILE_IDENTITY_MATCH_ATTRIBUTE = "MobileIdentityMatchAttribute";
	String EMAIL_ADDRESS = "EmailAddress";
	String FIRST_NAME = "FirstName";
	String MIDDLE_NAME = "MiddleName";
	String LAST_NAME = "LastName";
	String STREET_ADDRESS = "StreetAddress";
	String EXTENDED_ADDRESS = "ExtendedAddress";
	String CITY = "City";
	String REGION = "Region";
	String POSTAL_CODE = "PostalCode";
	String COUNTRY = "Country";
	String CONSENT_STATUS = "ConsentStatus";
	String CONSENT_COLLECTED_TIMESTAMP = "ConsentCollectedTimestamp";
	String CONSENT_TRANSACTION_ID = "ConsentTransactionId";
	String CONSENT_DESCRIPTION = "ConsentDescription";
	
	// response fields
	String RESPONSE_REQUEST_ID = "RequestId";
	String RESPONSE_STATUS = "Status";
	String RESPONSE_DESCRIPTION ="Description";
	String RESPONSE_ADDITIONAL_INFO = "AdditionalInfo";
	String MS_STATUS = "ResponseStatus.MS-Status";
	String MS_DESCRIPTION = "ResponseStatus.MS-Description";
	String MS_ADDITIONAL_INFO = "ResponseStatus.MS-AdditionalInfo";
	String MCV_STATUS = "ResponseStatus.MCV-Status";
	String MCV_DESCRIPTION = "ResponseStatus.MCV-Description";
	String MCV_ADDITIONAL_INFO = "ResponseStatus.MCV-AdditionalInfo";
	String MI_STATUS = "ResponseStatus.MI-Status";
	String MI_DESCRIPTION = "ResponseStatus.MI-Description";
	String MI_ADDITIONAL_INFO = "ResponseStatus.MI-AdditionalInfo";
	String MOBILE_STATUS_TRANSACTION_ID = "Response.MobileStatusTransactionId";
	String MOBILE_IDENTITY_CREATED_DATE = "Response.MobileIdentityCreatedDate";
	String RESPONSE_PAYFONE_ALIAS = "Response.PayfoneAlias";
	String MOBILE_OPERATOR_NAME = "Response.MobileOperatorName";
	String RESPONSE_MOBILE_NUMBER = "Response.MobileNumber";
	String EVENT_TYPE = "Response.SubscriberLastChangedEvents.EventType";
	String LAST_CHANGED_DATE = "Response.SubscriberLastChangedEvents.LastChangedDate";
	String STATUS_INDEX = "Response.StatusIndex";
	String CALL_VERIFICATION_TRANSACTION_ID = "";
	int ANI_STATUS = 47;
	int LINE_TYPE = 48;
	String CONFIDENCE_NAME = "Response.MobileIdentityMatchConfidence.Name";
	String CONFIDENCE_ADDRESS = "Response.MobileIdentityMatchConfidence.Address";
	String CONFIDENCE_EMAIL = "Response.MobileIdentityMatchConfidence.Email";
	String MOBILE_IDENTITY_TRANSACTION_ID = "Response.MobileIdentityTransactionId";
	
}
