/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.ccv;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Builder;

/**
 * <p>A POJO that represents an Authentify JSON message.</p>
 * <p>This class utilizes the lombok Builder annotation. This annotation provides
 * an implementation of the builder pattern by implementing the builder() method
 * and an all argument constructor for the class.
 * Also provided by the annotation is the &lt;class name&gt;Builder class. These elements
 * are mentioned here because since they are noted coded, there are no Java Doc comments
 * for these elements. For additional information about this annotation see the
 * <a href="{@docRoot}/com/earlywarning/authentication/ccv/package-summary.html#tags">
 * package-info</a> page.</p>
 * 
 * @author cornettl
 *
 */
@JsonPropertyOrder({"RequestId","ApiClientID","MobileNumber","MobileStatusCheck","MobileCallVerificationCheck","MobileCallVerificationDID","CallArrivalTimeStamp",
	"MobileIdentityCheck","MobileIdentityMAtchAttribute","ConsentStatus","ConsentCollectedTimestamp","ConsentTransactionId","ConsentDescription"
})
@JsonInclude(Include.NON_NULL)
@Builder
public class CCVRequest {
	private String requestId;
	private String apiClientId;
	private String mobileNumber;
	@JsonProperty(value="MobileStatusCheck")
	private boolean MobileStatusCheck;
	@JsonProperty(value="MobileCallVerificationCheck")
	private boolean MobileCallVerificationCheck;
	private String mobileCallVerificationDID;
	private String callArrivalTimestamp;
	@JsonProperty(value="MobileIdentityCheck")
	private boolean MobileIdentityCheck;
	private MobileIdentityMatchAttribute mobileIdentityMatchAttribute;
	private String consentStatus;
	private String consentCollectedTimestamp;
	private String consentTransactionId;
	private String consentDescription;
	private String subClientId;
	private String payfoneAlias;
	
	
	public String getSubClientId() {
		return subClientId;
	}
	public void setSubClientId(String subClientId) {
		this.subClientId = subClientId;
	}
	public String getPayfoneAlias() {
		return payfoneAlias;
	}
	public void setPayfoneAlias(String payfoneAlias) {
		this.payfoneAlias = payfoneAlias;
	}
	// Getters and Setters
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getApiClientId() {
		return apiClientId;
	}
	public void setApiClientId(String apiClientId) {
		this.apiClientId = apiClientId;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public boolean getMobileStatusCheck() {
		return MobileStatusCheck;
	}
	public void setMobileStatusCheck(boolean isMobileStatusCheck) {
		this.MobileStatusCheck = isMobileStatusCheck;
	}
	public boolean getMobileCallVerificationCheck() {
		return MobileCallVerificationCheck;
	}
	public void setMobileCallVerificationCheck(boolean isMobileCallVerificationCheck) {
		this.MobileCallVerificationCheck = isMobileCallVerificationCheck;
	}
	public String getMobileCallVerificationDID() {
		return mobileCallVerificationDID;
	}
	public void setMobileCallVerificationDID(String mobileCallVerificationDID) {
		this.mobileCallVerificationDID = mobileCallVerificationDID;
	}
	public String getCallArrivalTimestamp() {
		return callArrivalTimestamp;
	}
	public void setCallArrivalTimestamp(String callArrivalTimestamp) {
		this.callArrivalTimestamp = callArrivalTimestamp;
	}
	public boolean getMobileIdentityCheck() {
		return MobileIdentityCheck;
	}
	public void setMobileIdentityCheck(boolean isMobileIdentityCheck) {
		this.MobileIdentityCheck = isMobileIdentityCheck;
	}
	public MobileIdentityMatchAttribute getMobileIdentityMatchAttribute() {
		return mobileIdentityMatchAttribute;
	}
	public void setMobileIdentityMatchAttribute(MobileIdentityMatchAttribute mobileIdentityMatchAttribute) {
		this.mobileIdentityMatchAttribute = mobileIdentityMatchAttribute;
	}
	public String getConsentStatus() {
		return consentStatus;
	}
	public void setConsentStatus(String consentStatus) {
		this.consentStatus = consentStatus;
	}
	public String getConsentCollectedTimestamp() {
		return consentCollectedTimestamp;
	}
	public void setConsentCollectedTimestamp(String consentCollectedTimestamp) {
		this.consentCollectedTimestamp = consentCollectedTimestamp;
	}
	public String getConsentTransactionId() {
		return consentTransactionId;
	}
	public void setConsentTransactionId(String consentTransactionId) {
		this.consentTransactionId = consentTransactionId;
	}
	public String getConsentDescription() {
		return consentDescription;
	}
	public void setConsentDescription(String consentDescription) {
		this.consentDescription = consentDescription;
	}
}
