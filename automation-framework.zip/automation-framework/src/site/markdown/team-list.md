## The Project Team
This project is a collaboration of the QA team and the automation team. 

### The QA Team
	* Milena Dendebera - Manager
	* Michael Tsarfis
	* Galina Konshin
	* Cesar Guerrero
	* Nataliya Ripinskaya
	* Sergey Shimchonak
	* Mrinmoy Barik

### The Automation Team
	* Aravindhan Rajasekaran
	* Larry Cornett