
## Welcome to the Authentify Cucumber Testing Framework
The Authentify Cucumber Testing Framework was started in the second quarter of 2017 to help expedite the Authentify applications to 
market. Prior to the framework, manual tests were performed. Testing the applications manually is slow and error prone. Hence, the need to automate the application testing.

Early on, the decision was made to use Cucumber and RestAssured to automate the testing of the Authentify services.

### Cucumber
Cucumber was chosen as the testing framework because Early Warning's test management tool is XRay for Jira. XRay natively supports cucumber in that the tests can be exported from XRay with their id keys as cucumber tags which means that the results can be imported and the tests, test sets, and requirements will be updated automatically with the results.

### Rest Assured
Rest Assured was chosen because of its simple cucumber like API. 