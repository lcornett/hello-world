/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.jsoncompare;

import com.earlywarning.authentication.common.Data;
import com.earlywarning.authentication.common.Response;

import lombok.extern.log4j.Log4j2;

/**
 * A class that compares a response from an Authentify service with another response
 * @author cornettl
 *
 */
@Log4j2
class ResponseComparator extends StringComparator {

	/**
	 * Compares the elements of two response objects. The following elements are not evaluated
	 * because they are unique to each response:<ul>
	 * 	<li>sgid</li>
	 * 	<li>ewSID</li>
	 * 	<li>replyTo</li>
	 * 	<timestamoISO8601</li></ul>
	 * @param actual The Response being compared.
	 * @param expected The Response to compare to.
	 * @return True if the object elements match.
	 */
	boolean compareResponse(Response actual, Response expected) {
		String actualValue;
		String expectedValue;		
		String[] keys = {"clientId", "clientContext", "app", "clientAcctId", 
				"event", "statusCode", "data"};
		
		try {
			
			if ((null == actual) && (null == expected)) {
				return status;
			}
			
			for (String key : keys) {
				switch (key ) {
					case "clientId":
						actualValue = actual.getClientId();
						expectedValue = expected.getClientId();
						updateStatus(compareString(key, actualValue, expectedValue));
						break;
					case "clientContext":
						actualValue = actual.getClientContext();
						expectedValue = expected.getClientContext();
						updateStatus(compareString(key, actualValue, expectedValue));
						break;
					case "app":
						actualValue = actual.getApp();
						expectedValue = expected.getApp();
						updateStatus(compareString(key, actualValue, expectedValue));
						break;
					case "clientAcctId":
						actualValue = actual.getClientAcctId();
						expectedValue = expected.getClientAcctId();
						updateStatus(compareString(key, actualValue, expectedValue));
						break;
					case "ewSID":
						actualValue = actual.getEwSID();
						expectedValue = expected.getEwSID();
						updateStatus(compareString(key, actualValue, expectedValue));
						break;
					case "event":
						actualValue = actual.getEvent();
						expectedValue = expected.getEvent();
						updateStatus(compareString(key, actualValue, expectedValue));
						break;
					case "statusCode":	
						actualValue = actual.getStatusCode();
						expectedValue = expected.getStatusCode();
						updateStatus(compareString(key, actualValue, expectedValue));
						break;
					case "data":
						DataComparator dc = new DataComparator();
						Data actualData = actual.getData();
						Data expectedData = expected.getData();
						updateStatus(dc.compareData(actualData, expectedData));
				}			
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		return status;
	}
}
