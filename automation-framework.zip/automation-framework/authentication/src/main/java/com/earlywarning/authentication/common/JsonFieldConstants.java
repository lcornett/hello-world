/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.common;

/**
 * An interface providing the JSONPath for the fields implemented. This provides
 * a single point of change if and when the message layout changes.
 * Currently, only the Response message is implemented.
 * @author cornettl
 *
 */
public interface JsonFieldConstants {
	
	// Response fields
	public String ADDRESS_STATUS = "data.cardApiData.addressStatus";	
	public String APP = "app";
	public String CARD_STATUS = "data.cardApiData.cardStatus";
	public String CARD_TYPE = "data.cardApiData.cardType";
	public String CARD_VALID = "data.cardApiData.cardValid";
	public String CLIENT_ACCT_ID = "clientAcctId";
	public String CLIENT_CONTEXT = "clientContext";
	public String CLIENT_ID = "clientId";
	public String CVV_STATUS = "data/cardApiData.cvvStatus";
	public String DEBIT_NETWORK = "data.cardApiData.debitNetwork";
	public String EWSID = "ewSID";
	public String FAST_FUNDS = "data.cardApiData.fastFunds";
	public String ISSUER = "data.cardApiData.issuer";
	public String POSTAL_CODE_STATUS = "data.cardApiData.postalCodeStatus";
	
	public String REPLY_TO = "replyTo";
	
	public String SGID = "sgid";
	public String STATUS_CODE = "statusCode";
	public String STATUS_TEXT = "statusText";
	
	public String TIMESTAMP_ISO8601 = "timestampISO8601";
}
