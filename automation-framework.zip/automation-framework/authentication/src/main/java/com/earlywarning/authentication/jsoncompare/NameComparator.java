/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.jsoncompare;

import com.earlywarning.authentication.common.Name;

import lombok.extern.log4j.Log4j2;

/**
 * A Class that compares the elements of two instances of the Name class.
 * @author cornettl
 *
 */
@Log4j2
class NameComparator extends StringComparator {

	/**
	 * A method that compares the values of the properties of two Name classes 
	 * @param actual The instance of the Name class being compared
	 * @param expected The instance of the Name class being compared to
	 * @return true if the values are the same, false otherwise
	 */
	boolean compareName(Name actual, Name expected) {
		String actualValue = "";
		String expectedValue = "";
		String[] elements = {"firstName", "lastName", "middleName"};
		
		try {
			if ((null == actual) && (null == expected)) {
				return status;
			}
			
			for (String element : elements) {
				switch (element) {
					case "firstName":
						actualValue = actual.getFirstName();
						expectedValue = expected.getFirstName();
						updateStatus(compareString(element, actualValue, expectedValue));
						break;
					case "lastName":
						actualValue = actual.getLastName();
						expectedValue = expected.getLastName();
						updateStatus(compareString(element, actualValue, expectedValue));
						break;
					case "middleName":
						actualValue = actual.getMiddleName();
						expectedValue = expected.getMiddleName();
						updateStatus(compareString(element, actualValue, expectedValue));
				}
			}
			
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		return status;
	}
	
}
