/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.xml;

import lombok.Builder;
import lombok.Data;

/**
 * <p>A POJO representing the header node in the Authentify XML request message.
 * This class utilizes the lombok Data and Builder annotations. The 
 * Data annotation provides the setter and getter methods for the private
 * properties:</p><ul>
 * 	<li>tsoid</li>
 * 	<li>licenseKey</li>
 * 	<li>application</li>
 * 	<li>account</li>
 * 	<li>asid</li></ul>
 * The Builder annotation implements the builder pattern for the class.
 * <p>For additional information on the annotations used, see the 
 * <a href="{@docRoot}/com/earlywarning/authentication/xml/package-summary.html#tags">package-info</a> page.
 * @author cornettl
 *
 */
@Data
@Builder
public class Header {
	private String tsoid;
	private String licenseKey;
	private String application;
	private String account;
	private String asid;
}

