/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.jsoncompare;

import java.util.ArrayList;

import com.earlywarning.authentication.common.Event;

import lombok.extern.log4j.Log4j2;

/**
 * A class that compares the values in two lists of events. These events are lastChangedEvents, 
 * an element of the Authentify response message.
 * @author cornettl
 *
 */
@Log4j2
class EventsComparator extends StringComparator {
	private String comparator = "data.dataLookup.lastChangedEvents.";
	
	/**
	 * A method that compares two lists of Event class instances by getting an event from the 
	 * list being compared to and iterating through the list being compared to find the corresponding 
	 * event. If the event is found, the lastChangedDates of the events are compared.
	 * @param actual The list of Events being compared.
	 * @param expected The list of Events being compared to.
	 * @return true if the lists contain the same elements, false otherwise.
	 */
	boolean compareEventsList(ArrayList<Event> actual, ArrayList<Event> expected) {
		boolean isFound = false;
		Event actualEvent = null;
		Event expectedEvent = null;
		String actualEventValue = "";
		String expectedEventValue = "";
		String msg = "";
				
		try {
			if ((null == actual) && (null == expected)) {
				msg = "The lastChangeEvents element in both messages are null!";
				log.info(msg);
				return true;
			}
			
			if (actual.size() != expected.size()) {
				msg = "The lastChangeEvents elements in the messages are different sizes.";
				log.info(msg);
				return false;
			}
			
			for (int i = 0; i < expected.size(); i++) {
				expectedEvent = expected.get(i);
				expectedEventValue = expectedEvent.getValue();
				
				// Iterate through the actual events to find the corresponding event.
				for (int j = 0; j < actual.size(); j++) {
					actualEvent = actual.get(j);
					actualEventValue = actualEvent.getValue();
					if (actualEventValue.equals(expectedEventValue)) {
						isFound = true;
						updateStatus(compareString(comparator + expectedEvent, 
								actualEvent.getLastChangeDate(), expectedEvent.getLastChangeDate()));
						break;
					}
				}
				
				if (!isFound) {
					msg = "The expected expected event, " + expectedEvent + ", was not found in the list of actual events!";
					log.info(msg);
				} else {
					isFound = false;
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		return status;
	}
}
