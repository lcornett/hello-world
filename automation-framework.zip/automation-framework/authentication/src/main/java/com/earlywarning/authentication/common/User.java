/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/**
 * A POJO representing the User element of the Authentify JSON request.
 * This class utilizes the lombok Data and the jackson JsonInclude annotations.
 * The Data annotation provides setters and getters for the following private properties:
 * <ul><li>userId</li>
 * 	<li>password</li>
 * 	<li>newPassword</li></ul>
 * Information about these annotations may be found on the  
 * <a href="{@docRoot}/com/earlywarning/authentication/common/package-summary.html#tags"> package-info</a> page.
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_NULL)
public class User {
	private String userId;
	private String password;
	private String newPassword;
}

