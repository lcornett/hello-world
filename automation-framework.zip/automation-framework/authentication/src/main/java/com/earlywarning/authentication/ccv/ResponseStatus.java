/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.ccv;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * A POJO that represents the ResponseStatus object of the CCVResponse message.
 * @author cornettl
 *
 */
@JsonInclude(Include.NON_EMPTY)
public class ResponseStatus {
	@JsonProperty("MS-Status")
	private int msStatus;
	
	@JsonProperty("MS-Description")
	private String msDescription;
	
	@JsonProperty("MS-AdditionalInfo")
	private String msAdditionalInfo;
	
	@JsonProperty("MCV-Status")
	private int mvcStatus;
	
	@JsonProperty("MCV-Description")
	private String mvcDescription;
	
	@JsonProperty("MCV-AdditionalInfo")
	private String mvcAdditionalInfo;
	
	@JsonProperty("MI-Status")
	private int miStatus;
	
	@JsonProperty("MI-Description")
	private String miDescription;
	
	@JsonProperty("MI-AdditionalInfo")
	private String miAdditionalInfo;

	public int getMsStatus() {
		return msStatus;
	}

//	@JsonProperty("MS_Status")
	public void setMsStatus(int msStatus) {
		this.msStatus = msStatus;
	}

	public String getMsDescription() {
		return msDescription;
	}

	public void setMsDescription(String msDescription) {
		this.msDescription = msDescription;
	}

	public String getMsAdditionalInfo() {
		return msAdditionalInfo;
	}

	public void setMsAdditionalInfo(String msAdditionalInfo) {
		this.msAdditionalInfo = msAdditionalInfo;
	}

	public int getMvcStatus() {
		return mvcStatus;
	}

	public void setMvcStatus(int mvcStatus) {
		this.mvcStatus = mvcStatus;
	}

	public String getMvcDescription() {
		return mvcDescription;
	}

	public void setMvcDescription(String mvcDescription) {
		this.mvcDescription = mvcDescription;
	}

	public String getMvcAdditionalInfo() {
		return mvcAdditionalInfo;
	}

	public void setMvcAdditionalInfo(String mvcAdditionalInfo) {
		this.mvcAdditionalInfo = mvcAdditionalInfo;
	}

	public int getMiStatus() {
		return miStatus;
	}

	public void setMiStatus(int miStatus) {
		this.miStatus = miStatus;
	}

	public String getMiDescription() {
		return miDescription;
	}

	public void setMiDescription(String miDescription) {
		this.miDescription = miDescription;
	}

	public String getMiAdditionalInfo() {
		return miAdditionalInfo;
	}

	public void setMiAdditionalInfo(String miAdditionalInfo) {
		this.miAdditionalInfo = miAdditionalInfo;
	}
	
	
}
