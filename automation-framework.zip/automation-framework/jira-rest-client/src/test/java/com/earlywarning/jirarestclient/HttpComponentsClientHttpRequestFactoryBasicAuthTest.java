package com.earlywarning.jirarestclient;

import static org.junit.Assert.*;

import java.net.URI;
import java.net.URISyntaxException;

import org.apache.http.HttpHost;
import org.apache.http.protocol.HttpContext;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpMethod;

public class HttpComponentsClientHttpRequestFactoryBasicAuthTest {
	static HttpComponentsClientHttpRequestFactoryBasicAuth factory;
	
	@Before
	public void setUp() throws Exception {
		HttpHost host = new HttpHost("localhost");
		factory = new HttpComponentsClientHttpRequestFactoryBasicAuth(host);

	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testHttpComponentsClientHttpRequestFactoryBasicAuth() {
		assertNotNull(factory.host);
		
	}

	@Test
	public void testCreateHttpContextHttpMethodURI()  {
		HttpMethod method = HttpMethod.GET;
		try {
			URI uri = new URI("http://localhost");
			HttpContext context = null;
			context = factory.createHttpContext(method, uri);
			assertNotNull(context);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
