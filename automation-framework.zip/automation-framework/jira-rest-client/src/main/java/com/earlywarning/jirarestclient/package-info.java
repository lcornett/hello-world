/**
 * 
 */
/**
 * This package contains the classes required to connect to Jira and either
 * export the feature files or import the test results.
 * @author cornettl
 *
 */
package com.earlywarning.jirarestclient;