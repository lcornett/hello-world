/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.common;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.earlywarning.authentication.common.PollRequest;
import com.earlywarning.authentication.common.Request;
import com.earlywarning.authentication.common.RequestCreator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestRequestCreator {
	Map<String, String> map = new HashMap<String, String>();
	ObjectMapper mapper; 
	Request expected;
	
	@Before
	public void setUp() throws Exception {
		mapper = new ObjectMapper();
		String expectedRequest = "{\"clientId\": \"Authentify_Test\",\"license\": \"3360a6d7-7f15-4739-bb95-2fa402e0c4ee\","
				+ "\"app\": \"mobileLookupProd\",\"clientAcctId\": \"QATest\",\"clientContext\": \"Authentify_QA_TEST\","
				+ "\"event\": \"mobileAuthStart\",\"data\": {\"dataLookup\": {\"mobileNetworkOperator\": \"Verizon\","
				+ "\"deviceIp\": \"192.168.0.1\",\"FinalTargetUrl\": {\"value\": \"https://authentify.com/mobileAuthFinish\"},"
				+ "\"consentCollectedDate\": \"2015-11-19\",\"consentTransactionId\": \"B000101\","
				+ "\"consentDescription\": \"Got verbal approval\"},\"namedData\": {\"dataItem\": "
				+ "{\"name\": \"returnlegacydeviceid\", \"value\": \"false\"}}}}}";
		expected = mapper.readValue(expectedRequest, Request.class);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCreateRequestMapOfStringString() {
		map.put("clientId", "Authentify_Test");
		map.put("license", "3360a6d7-7f15-4739-bb95-2fa402e0c4ee");
		map.put("app", "mobileLookupProd");
		map.put("clientAcctId", "QATest");
		map.put("clientContext", "Authentify_QA_TEST");
		map.put("event", "mobileAuthStart");
		map.put("deviceIp", "192.168.0.1");
		map.put("finalTargetUrl", "https://authentify.com/mobileAuthFinish");
		map.put("consentCollectedDate", "2015-11-19");
		map.put("consentTransactionId", "B000101");
		map.put("consentDescription", "Got verbal approval");
		map.put("mobileNetworkOperator", "Verizon");
		map.put("dataItemName", "returnlegacydeviceid");
		map.put("dataItemValue", "false");
		
		try {
			Request request = RequestCreator.createRequest(map);
			String jsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);

			assertEquals(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(expected), jsonString);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testCreateRequestMapOfStringStringRequest() {
		Request request = new Request();
		Map<String, String> map = new HashMap<String, String>();
		
		map.put("clientId", "Authentify_Test");
		map.put("license", "3360a6d7-7f15-4739-bb95-2fa402e0c4ee");
		map.put("app", "mobileLookupProd");
		map.put("clientAcctId", "QATest");
		map.put("clientContext", "Authentify_QA_TEST");
		map.put("event", "mobileAuthStart");
		map.put("deviceIp", "192.168.0.1");
		
		
		try {
			request = RequestCreator.createRequest(map, request);
			
			map = new HashMap<String, String>();
			map.put("finalTargetUrl", "https://authentify.com/mobileAuthFinish");
			map.put("consentCollectedDate", "2015-11-19");
			map.put("consentTransactionId", "B000101");
			map.put("consentDescription", "Got verbal approval");
			map.put("mobileNetworkOperator", "Verizon");
			map.put("dataItemName", "returnlegacydeviceid");
			map.put("dataItemValue", "false");
			
			request = RequestCreator.createRequest(map, request);

			
			String jsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
			System.out.println(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(expected));
			System.out.println(jsonString);
			assertEquals(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(expected), jsonString);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testCreatePollRequest() {
		String ewSID = "8966425c-d4c9-4168-8a30-ef016a76b718";
		String poll = "";
		String expected = "{\"ewSID\":\"8966425c-d4c9-4168-8a30-ef016a76b718\",\"poll\":\"\"}";
		
		PollRequest pollRequest = RequestCreator.createPollRequest(ewSID, poll);
		
		try {
			assertEquals(expected, mapper.writeValueAsString(pollRequest));
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}		
	}

}
