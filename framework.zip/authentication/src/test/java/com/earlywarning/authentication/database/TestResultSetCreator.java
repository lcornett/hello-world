/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.Statement;
import java.util.Map;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import org.apache.commons.dbcp2.BasicDataSource;
import org.junit.Before;
import org.junit.Test;

import com.earlywarning.authentication.applogs.ResponseSetter;

public class TestResultSetCreator {

	@Before
	public void setUp() throws Exception {
		ResponseSetter.setResponse();
		
		ResultSetMetaData mockRsmd = mock(ResultSetMetaData.class);
		when(mockRsmd.getColumnName(anyInt())).thenReturn("columnName").thenReturn("column2");
		when(mockRsmd.getColumnCount()).thenReturn(3);
		
		ResultSet mockResultSet = mock(ResultSet.class);
		when(mockResultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);
		when(mockResultSet.getString(anyInt())).thenReturn("1234").thenReturn("Larry").thenReturn("Cornett");
		when(mockResultSet.getMetaData()).thenReturn(mockRsmd);
		
		
		
		Statement mockStatement = mock(Statement.class);
		when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);
		
		PreparedStatement mockStmt = mock(PreparedStatement.class);
		when(mockStmt.executeQuery()).thenReturn(mockResultSet);
		
		Connection mockConn = mock(Connection.class);
		when(mockConn.prepareStatement(anyString())).thenReturn(mockStmt);
		when(mockConn.createStatement()).thenReturn(mockStatement);
		
		BasicDataSource mockBds = mock(BasicDataSource.class);
		when(mockBds.getConnection()).thenReturn(mockConn);

		DataSource.bds = mockBds;
	}

	@Test
	public void testResultSetCreator() {
		ResultSetCreator creator = new ResultSetCreator();
		assertNotNull(creator);
	}

	@Test
	public void testResultSetCreatorString() {
		String teid = "5a4b230b-ca74-4cf1-9b3c-2bf08bd50026";
		ResultSetCreator creator = new ResultSetCreator(teid);
		assertNotNull(creator);
	}

	@Test
	public void testGetResultSet() {
		String teid = "5a4b230b-ca74-4cf1-9b3c-2bf08bd50026";
		ResultSetCreator creator = new ResultSetCreator(teid);
		Map<String, String> result = null;
		
		result = creator.getResultSet("payfone");
		assertTrue(result instanceof Map);
	}

	@Test
	public void testGetResultSetXml() {
		ResponseSetter.setXmlResponse();
		String teid = "5a4b230b-ca74-4cf1-9b3c-2bf08bd50026";
		ResultSetCreator creator = new ResultSetCreator(teid);
		Map<String, String> result = null;
		
		result = creator.getResultSet("payfone");
		assertTrue(result instanceof Map);
	}

	@Test
	public void testGetVendorLinkData() {
		ResultSetCreator creator = new ResultSetCreator();
		Map<String, String> result = null;
		
		result = creator.getVendorLinkData("payfone");
		
		assertTrue(result instanceof Map);
	}

	@Test
	public void testGetVendorLinkDataXml() {
		ResponseSetter.setXmlResponse();
		ResultSetCreator creator = new ResultSetCreator();
		Map<String, String> result = null;
		
		result = creator.getVendorLinkData("payfone");
		
		assertTrue(result instanceof Map);
	}

}
