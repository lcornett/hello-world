/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.Connection;

import org.apache.commons.dbcp2.BasicDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class TestDataSource {
	private BasicDataSource mockBds;
	private DataSource dataSource;
	
	@Before
	public void setUp() throws Exception {
		Connection mockConnection = mock(Connection.class);
		
		mockBds = mock(BasicDataSource.class);
		when(mockBds.getConnection()).thenReturn(mockConnection);
		DataSource.bds = mockBds;
	}

	@After
	public void tearDown() throws Exception {
	}


	@Test
	public void testGetInstanceString() {
		DataSource source = DataSource.getInstance("Register_Alpha");
		if (dataSource != null) {
			assertEquals(dataSource, source);
		} else {
			dataSource = source;
		}
		assertTrue(source instanceof DataSource);
	}
	
	@Test
	public void testGetInstanceString2() {
		DataSource source = DataSource.getInstance("Register_Alpha");
		if (dataSource != null) {
			assertEquals(dataSource, source);
		} else {
			dataSource = source;
		}

		assertTrue(source instanceof DataSource);
	}

	@Test
	public void testGetBds() {
		BasicDataSource basicDataSource = DataSource.getInstance("").getBds();
		assertEquals(mockBds, basicDataSource);
	}


}
