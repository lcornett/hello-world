/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.applogs;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.earlywarning.authentication.common.ApiDriver;
import com.earlywarning.authentication.database.ResultSetCreator;

import io.restassured.internal.RestAssuredResponseImpl;

public class TestLogValidator {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testValidateDbValue() {
		String logKey = "Response.PhoneNumber";
		String dbKey = "phoneNumber";
		
		ResponseSetter.setResponse();
		
		Map<String, String> dataSet = new HashMap<String, String>();
		dataSet.put("phoneNumber", "14807770045");
		ResultSetCreator mockCreator = mock(ResultSetCreator.class);
		when(mockCreator.getResultSet(anyString())).thenReturn(dataSet);
		
		LogParser mockParser = mock(LogParser.class);
		when(mockParser.parseLog(anyString(), anyString())).thenReturn(getLogContent());
		
		LogValidator val = new LogValidator();
		val.creator = mockCreator;
		val.parser = mockParser;
		assertTrue(val.validateDbValue(logKey, dbKey));
	}
	
	
	@Test
	public void testValidateDbValueXML() {
		String logKey = "Response.PhoneNumber";
		String dbKey = "phoneNumber";
		
		ResponseSetter.setXmlResponse();
		
		Map<String, String> dataSet = new HashMap<String, String>();
		dataSet.put("phoneNumber", "14807770045");
		ResultSetCreator mockCreator = mock(ResultSetCreator.class);
		when(mockCreator.getResultSet(anyString())).thenReturn(dataSet);
		
		LogParser mockParser = mock(LogParser.class);
		when(mockParser.parseLog(anyString(), anyString())).thenReturn(getLogContent());
		
		LogValidator val = new LogValidator();
		val.creator = mockCreator;
		val.parser = mockParser;
		assertTrue(val.validateDbValue(logKey, dbKey));
	}

	@Test
	public void testValidateDbValues() {
		Map<String, String> inputData = new HashMap<String, String>();
		inputData.put("Response.MobileNumber", "phoneNumber");
		inputData.put("Response.PayfoneAlias", "ExternalGUID");
		
		Map<String, String> dataSet = new HashMap<String, String>();
		dataSet.put("phoneNumber", "17733185771");
		
		Map<String, String> vendorData = new HashMap<String, String>();
		vendorData.put("ExternalGUID", "C8DF1D0C4VK8384E2F39618E23DE91EC00MEKIOMIXT9P23117637AB91EFB4BF4B1CCFB87B802F962F6G32657AF56C48D3FA2BB70D76CD00B0B311AC4");

		ResultSetCreator mockCreator = mock(ResultSetCreator.class);
		when(mockCreator.getResultSet(anyString())).thenReturn(dataSet);
		when(mockCreator.getVendorLinkData(anyString())).thenReturn(vendorData);
		
		LogParser mockParser = mock(LogParser.class);
		when(mockParser.parseLog(anyString(), anyString())).thenReturn(getPayfoneResponse());
		
		LogValidator val = new LogValidator();
		val.creator = mockCreator;
		val.parser = mockParser;
		assertTrue(val.validateDbValues(inputData));
	}

	@Test
	public void testValidateDbValuesTwoSame() {
		Map<String, String> inputData = new HashMap<String, String>();
		inputData.put("Response.MobileNumber", "phoneNumber");
		inputData.put("Response.PayfoneAlias", "ExternalGUID");
		inputData.put("Response.PhoneNumber", "phoneNumber");
		
		Map<String, String> dataSet = new HashMap<String, String>();
		dataSet.put("phoneNumber", "17733185771");
		
		Map<String, String> vendorData = new HashMap<String, String>();
		vendorData.put("ExternalGUID", "C8DF1D0C4VK8384E2F39618E23DE91EC00MEKIOMIXT9P23117637AB91EFB4BF4B1CCFB87B802F962F6G32657AF56C48D3FA2BB70D76CD00B0B311AC4");

		ResultSetCreator mockCreator = mock(ResultSetCreator.class);
		when(mockCreator.getResultSet(anyString())).thenReturn(dataSet);
		when(mockCreator.getVendorLinkData(anyString())).thenReturn(vendorData);
		
		LogParser mockParser = mock(LogParser.class);
		when(mockParser.parseLog(anyString(), anyString())).thenReturn(getPayfoneResponse());
		
		LogValidator val = new LogValidator();
		val.creator = mockCreator;
		val.parser = mockParser;
		assertFalse(val.validateDbValues(inputData));

	}

	@Test
	public void testValidateResponseValue() {
		String logKey = "Response.PhoneNumber";
		String responseKey = "data.phoneNumber";
		
		LogParser mockParser = mock(LogParser.class);
		when(mockParser.parseLog(anyString(), anyString())).thenReturn(getLogContent());

		ResponseSetter.setResponse();
		LogValidator val = new LogValidator();
		val.parser = mockParser;
		assertFalse(val.validateResponseValue(logKey, responseKey));
	}
	
	@Test
	public void testValidateResponseValueXml() {
		String logKey = "Response.PhoneNumber";
		String responseKey = "data.phoneNumber";
		
		LogParser mockParser = mock(LogParser.class);
		when(mockParser.parseLog(anyString(), anyString())).thenReturn(getLogContent());

		ResponseSetter.setXmlResponse();
		LogValidator val = new LogValidator();
		val.parser = mockParser;
		assertFalse(val.validateResponseValue(logKey, responseKey));
	}

	@Test(expected=NullPointerException.class)
	public void testValidateResponseValueNoContentType() {
		String logKey = "Response.PhoneNumber";
		String responseKey = "data.phoneNumber";
		
		ResponseSetter.setResponseNoContentType();
		LogParser mockParser = mock(LogParser.class);
		when(mockParser.parseLog(anyString(), anyString())).thenReturn(getLogContent());

		ResponseSetter.setResponseNoContentType();
		LogValidator val = new LogValidator();
		val.parser = mockParser;
		assertFalse(val.validateResponseValue(logKey, responseKey));
	}
	
	@Test
	public void testValidateResponseValuesJson() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("Response.MobileIdentityCreatedDate", "data.dataLookup.mobileIdentityCreated");
		map.put("Response.MobileNumber", "data.phoneNumber");
		
		ResponseSetter.setResponse();
		
		LogParser mockParser = mock(LogParser.class);
		when(mockParser.parseLog(anyString(), anyString())).thenReturn(getPayfoneResponse());
		LogValidator val = new LogValidator();
		val.parser = mockParser;
		assertTrue(val.validateResponseValues(map));
	}
	
	@Test
	public void testValidateResponseValuesXml() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("Response.MobileIdentityCreatedDate", "/AuthentXML/body/result/data/dataLookup/mobileIdentityCreated");
		map.put("Response.MobileNumber", "/AuthentXML/body/result/data/phoneNumber");
		
		ResponseSetter.setXmlResponse();
		
		LogParser mockParser = mock(LogParser.class);
		when(mockParser.parseLog(anyString(), anyString())).thenReturn(getPayfoneResponse());
		LogValidator val = new LogValidator();
		val.parser = mockParser;
		assertTrue(val.validateResponseValues(map));
	}


	@Test
	public void testValidateRequestValue() {
		
		ResponseSetter.setResponse();
		LogParser mockParser = mock(LogParser.class);
		when(mockParser.parseLogRequest(anyString(), anyString())).thenReturn(getLogRequest());
		
		LogValidator val = new LogValidator();
		val.parser = mockParser;
		assertTrue(val.validateRequestValue("MobileNumber", "getStatusPhone"));
	}

	@Test
	public void testValidateRequestValues() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("MobileNumber", "getStatusPhone");
		map.put("ConsentStatus", "optedIn");

		ResponseSetter.setResponse();
		LogParser mockParser = mock(LogParser.class);
		when(mockParser.parseLogRequest(anyString(), anyString())).thenReturn(getLogRequest());
		
		LogValidator val = new LogValidator();
		val.parser = mockParser;
		assertTrue(val.validateRequestValues(map));
	}

	@Test
	public void testValidateRequestValueXml() {
		
		ResponseSetter.setXmlResponse();
		LogParser mockParser = mock(LogParser.class);
		when(mockParser.parseLogRequest(anyString(), anyString())).thenReturn(getLogRequest());
		
		LogValidator val = new LogValidator();
		val.parser = mockParser;
		assertTrue(val.validateRequestValue("MobileNumber", "getStatusPhone"));
	}

	@Test
	public void testValidateRequestValueNoResponse() {
		ApiDriver.setResp(new RestAssuredResponseImpl());
		ApiDriver.setContentType(null);
		
		ResponseSetter.setXmlResponse();
		LogParser mockParser = mock(LogParser.class);
		when(mockParser.parseLogRequest(anyString(), anyString())).thenReturn(getLogRequest());
		
		LogValidator val = new LogValidator();
		val.parser = mockParser;
		assertTrue(val.validateRequestValue("MobileNumber", "getStatusPhone"));
	}

	@Test
	public void testValidateValue() {
		LogParser mockParser = mock(LogParser.class);
		when(mockParser.parseLog(anyString(), anyString())).thenReturn(getLogContent());
		
		LogValidator val = new LogValidator();
		val.parser = mockParser;
		assertTrue(val.validateValue("Response.PhoneNumber", "14807770045"));
	}
	
	@Test
	public void testValidateValues() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("Response.MobileIdentityCreatedDate", "4 to 6 years");
		map.put("Response.MobileNumber", "17733185771");

		LogParser mockParser = mock(LogParser.class);
		when(mockParser.parseLog(anyString(), anyString())).thenReturn(getPayfoneResponse());
		
		LogValidator val = new LogValidator();
		val.parser = mockParser;
		assertTrue(val.validateValues(map));
	}

	
	private String getLogContent() {
		String content = "{\"RequestId\" :\"cea1130c-be63-4516-a6d1-e9ce0ea7226d\", \"Status\" :0," + 
				"\"Description\" :\"Success.\", \"Response\" :{\"PhoneNumber\" :\"14807770045\", " + 
				"\"TransactionId\" :\"5248321765\", \"FraudStatus\" :\"No known fraud\"," + 
				"\"Path\" :0, \"StatusIndex\" :\"11\", \"PhoneNumberFlags\" :{\"Tenure\" :0, " + 
				"\"Velocity\" :0, \"Status\" :\"Native\", \"LineType\" :\"NonFixedVoIP\"}, " + 
				"\"DeviceFlags\" :{\"Tenure\" :0, \"Velocity\" :0}, \"OperatorFlags\" :{\"Tenure\" :0, " + 
				"\"Velocity\" :0}, \"SimFlags\" :{\"Tenure\" :0, \"Velocity\" :0}, \"PayfoneSignatureFlags\" :{" + 
				"\"Tenure\" :0}}}";
		return content;
	}
	
	private String getPayfoneResponse() {
		String response = "{\"RequestId\" :\"7e82d49b-f343-46d0-9534-ef5979f29ed1\",\"Status\" :0," + 
				"\"Description\" :\"Success.\",\"Response\" :{\"MobileIdentityCreatedDate\" :\"4 to 6 years\"," + 
				"\"MobileOperatorName\" :\"Verizon\",\"MobileNumber\" :\"17733185771\"," + 
				"\"PayfoneAlias\" :\"C8DF1D0C4VK8384E2F39618E23DE91EC00MEKIOMIXT9P23117637AB91EFB4BF4B1CCFB87B802F962F6G32657AF56C48D3FA2BB70D76CD00B0B311AC4\"," + 
				"\"MobileStatusTransactionId\" :\"5336036003\",\"SubscriberLastChangedEvents\" :[{" + 
				"\"EventType\" :\"DeviceChange\",\"LastChangedDate\" :\"2017-01-06T21:42:54Z\"}," + 
				"{\"EventType\" :\"SIMSwap\",\"LastChangedDate\" :\"2017-01-06T21:42:54Z\"}]," + 
				"\"StatusIndex\" :\"e5\"}}";
		return response;
	}
	
	private String getLogRequest() {
		String content = "{\"RequestId\" :\"9be50f6e-719a-4793-84ef-be3e072286db\",\"ApiClientId\" :\"Auth_U1b3mU644eA5eD\"," + 
				"\"SubClientId\" :\"Authentify9n2fvVC61y\",\"MobileNumber\" :\"17733185771\",\"ConsentCollectedTimestamp\" :\"2015-09-11\"," + 
				"\"ConsentTransactionId\" :\"4E040010B\",\"ConsentDescription\" :\"AMEX electronic\",\"ConsentStatus\" :\"optedIn\"}";
		return content;
	}

}
