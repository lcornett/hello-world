/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.earlywarning.authentication.applogs.ResponseSetter;
import com.earlywarning.authentication.common.ApiDriver;

import io.restassured.config.JsonConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.internal.ResponseParserRegistrar;
import io.restassured.internal.RestAssuredResponseImpl;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;

public class TestDatabaseMapper {

	@Before
	public void setUp() throws Exception {

	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetDatabase() throws Exception {
		setResponse("");
		assertEquals("Register01",DatabaseMapper.getDatabase());
	}
	
	@Test
	public void testGetDatabase1() throws Exception {
		setResponse("q2");
		assertEquals("Register02",DatabaseMapper.getDatabase());
	}

	@Test (expected=NullPointerException.class)
	public void testGetDatabaseError() throws Exception {
		ApiDriver.setResp(null);
			assertEquals("Register02",DatabaseMapper.getDatabase());
	}
	
	@Test
	public void testGetDatabaseNotFound() throws Exception {
		setResponse("q5");
		assertNull(DatabaseMapper.getDatabase());
	}

	@Test (expected=StringIndexOutOfBoundsException.class)
	public void testGetDatabaseElementNotFound() throws Exception {
		absentElement();
		assertNull(DatabaseMapper.getDatabase());
	}
	
	@Test
	public void testGetDatabaseXMLResponse() throws Exception {
		ResponseSetter.setXmlResponse();
		assertEquals("Register01",DatabaseMapper.getDatabase());
	}



	private void setResponse(String host) {
		RestAssuredResponseImpl impl = new RestAssuredResponseImpl();
		Response response = null;
		String content = "{\"clientId\": \"Authentify_Test\",\"clientContext\": \"Authentify_QA_TEST\"," +
				"\"sgid\": \"d7c892fd-b139-49e7-b362-125d418e3079\",\"app\": \"mobileLookupProd\"," + 
				"\"clientAcctId\": \"QATest\",\"ewSID\": \"d3645065-ed7a-4588-88ce-4b8c03dd6e22\"," + 
				"\"replyTo\": \"https://q1.authentify.com/getSessionStatus?id=786f0e08a394fe7a1b6bb46c5d4570da2cf66e58\"," + 
				"\"timestampISO8601\": \"2017-10-10T16:14:23Z\",\"event\": \"status\",\"statusCode\": \"0\"," + 
				"\"data\": {\"dataLookup\": {\"mobileIdentityCreated\": \"4 to 6 years\",\"mobileOperatorName\": \"Verizon\"," + 
				"\"lastChangeEvents\": [{\"value\": \"DeviceChange\",\"lastChangeDate\": \"2017-01-06T21:42:54Z\"}," + 
				"{\"value\": \"SIMSwap\",\"lastChangeDate\": \"2017-01-06T21:42:54Z\"}]," + 
				"\"statusIndex\": \"e5\"},\"phoneNumber\": \"17733185771\",\"ewDeviceId\": \"5a4b230b-ca74-4cf1-9b3c-2bf08bd50026\"" + 
				"}}";
		if (!host.isEmpty()) {
			content = content.replace("q1", host);
		}
		impl.setContent(content);
		impl.setContentType("application/json");
		ResponseParserRegistrar rpr = new ResponseParserRegistrar();
		rpr.registerParser("application/json", Parser.JSON);
		impl.setRpr(rpr);
		impl.setConfig(new RestAssuredConfig().jsonConfig(new JsonConfig()));
		response = impl;
		ApiDriver.setResp(response);
	}
	
	private void absentElement() {
			RestAssuredResponseImpl impl = new RestAssuredResponseImpl();
			Response response = null;
			String content = "{\"clientId\": \"Authentify_Test\",\"clientContext\": \"Authentify_QA_TEST\"," +
					"\"sgid\": \"d7c892fd-b139-49e7-b362-125d418e3079\",\"app\": \"mobileLookupProd\"," + 
					"\"clientAcctId\": \"QATest\",\"ewSID\": \"d3645065-ed7a-4588-88ce-4b8c03dd6e22\"," + 
//					"\"replyTo\": \"https://q1.authentify.com/getSessionStatus?id=786f0e08a394fe7a1b6bb46c5d4570da2cf66e58\"," + 
					"\"timestampISO8601\": \"2017-10-10T16:14:23Z\",\"event\": \"status\",\"statusCode\": \"0\"," + 
					"\"data\": {\"dataLookup\": {\"mobileIdentityCreated\": \"4 to 6 years\",\"mobileOperatorName\": \"Verizon\"," + 
					"\"lastChangeEvents\": [{\"value\": \"DeviceChange\",\"lastChangeDate\": \"2017-01-06T21:42:54Z\"}," + 
					"{\"value\": \"SIMSwap\",\"lastChangeDate\": \"2017-01-06T21:42:54Z\"}]," + 
					"\"statusIndex\": \"e5\"},\"phoneNumber\": \"17733185771\",\"ewDeviceId\": \"5a4b230b-ca74-4cf1-9b3c-2bf08bd50026\"" + 
					"}}";
			impl.setContent(content);
			impl.setContentType("application/json");
			ResponseParserRegistrar rpr = new ResponseParserRegistrar();
			rpr.registerParser("application/json", Parser.JSON);
			impl.setRpr(rpr);
			impl.setConfig(new RestAssuredConfig().jsonConfig(new JsonConfig()));
			response = impl;
			ApiDriver.setResp(response);
	}

}
