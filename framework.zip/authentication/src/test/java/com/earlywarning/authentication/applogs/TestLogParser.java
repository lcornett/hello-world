/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.applogs;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestLogParser {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testParseLog() {
		String path = getClass().getClassLoader().getResource("logs_since_/splog1.txt").getPath();
		path = path.substring(0, path.length() - 22);
		String teid = "adab3b14-dbeb-4fc9-8786-ddc50997f2a5";
		String response = null;
		LogParser parser = new LogParser();
		response = parser.parseLog(path, teid);
		
		assertEquals(getExpectedResponse(), response);
	}
	
	@Test (expected=NullPointerException.class)
	public void testParseLogException() {
		String path = "C:\\Development\\";
		String teid = "adab3b14-dbeb-4fc9-8786-ddc50997f2a5";
		String response = null;
		LogParser parser = new LogParser();
		response = parser.parseLog(path, teid);
		
		assertEquals(getExpectedResponse(), response);
	}


	@Test
	public void testParseLogRequest() {
		String path = getClass().getClassLoader().getResource("logs_since_/splog1.txt").getPath();
		path = path.substring(0, path.length() - 22);
		String teid = "adab3b14-dbeb-4fc9-8786-ddc50997f2a5";
		String request = null;
		LogParser parser = new LogParser();
		request = parser.parseLogRequest(path, teid);
		
		assertEquals(getExpectedRequest(), request);
	}

	private String getExpectedResponse() {
		String response = "{\"RequestId\" :\"adab3b14-dbeb-4fc9-8786-ddc50997f2a5\",\"Status\" :0,\"Description\""
				+ " :\"Success.\",\"Response\" :{\"MobileIdentityCreatedDate\" :\"4 to 6 years\",\"MobileOperatorName\" "
				+ ":\"Verizon\",\"MobileNumber\" :\"17733185771\",\"PayfoneAlias\" "
				+ ":\"C8DF1D0C4VK8384E2F39618E23DE91EC00MEKIOMIXT9P23117637AB91EFB4BF4B1CCFB87B802F962F6G32657AF56C48D3FA2BB70D76CD00B0B311AC4\","
				+ "\"MobileStatusTransactionId\" :\"5184168717\",\"SubscriberLastChangedEvents\" :[{\"EventType\" :\"DeviceChange\",\"LastChangedDate\""
				+ " :\"2017-01-06T21:42:54Z\"},{\"EventType\" :\"SIMSwap\",\"LastChangedDate\" :\"2017-01-06T21:42:54Z\"}],\"StatusIndex\" :\"e5\"}}";
		return response;
	}
	
	private String getExpectedRequest() {
		String request = "{\"RequestId\" :\"adab3b14-dbeb-4fc9-8786-ddc50997f2a5\",\"ApiClientId\" :\"Auth_U1b3mU644eA5eD\",\"SubClientId\" "
				+ ":\"Authentify9n2fvVC61y\",\"MobileNumber\" :\"17733185771\",\"ConsentCollectedTimestamp\" :\"2015-09-11\",\"ConsentTransactionId\" "
				+ ":\"4E040010B\",\"ConsentDescription\" :\"AMEX electronic\",\"ConsentStatus\" :\"optedIn\"}";
		return request;
	}

}
