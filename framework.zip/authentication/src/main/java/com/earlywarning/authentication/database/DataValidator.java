/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import java.util.Map;
import java.util.Set;

import org.mockito.MockingDetails;
import org.mockito.Mockito;

import com.earlywarning.authentication.common.ApiDriver;
import com.earlywarning.authentication.startup.Env;

import lombok.extern.log4j.Log4j2;

/**
 * A class that validates that the expected values match the actual values from the database 
 * for named fields. Some of these fields are contained in the Request message, some are 
 * contained in the Response message, some are just expected and won't be found in either of 
 * the messages.
 * @author cornettl
 *
 */
@Log4j2
public class DataValidator {
	static boolean result;
	static ResultSetCreator creator;

	/**
	 * Gets a dataset from the database and compares the expected values to the actual values in
	 * the dataset.
	 * @param map The expected values.
	 * @return true if all of the values are validated, false otherwise
	 */
	public static boolean validateData(Map<String, String> map) {
		Set<String> keys = map.keySet();
		Map<String, String> dataSet = getDataSet(); 
		String dbKey = null;
		result = true;
		String regex = "get[A-Za-z]+";
		String expected = null;
		
		try {
			for (String key : keys) {
				switch (key) {
					case "Action":
						dbKey = "sessioninfo.action";
						validateValue(key, map.get(key), dataSet.get(dbKey));
						break;
					case "asID":
						dbKey = "sessioninfoso.asID";
						validateValue(key, map.get(key), dataSet.get(dbKey));
						break;
					case "HashPhone":
						dbKey = "sessionresources.hashphone";
						
						if (map.get(key).matches(regex)) {
							expected = getEwDeviceId();
						} else {
							expected = map.get(key);
						}
						validateValue(key, expected, dataSet.get(dbKey));
						break;
					case "phoneNumber":
						dbKey = "sessioninfoso.phoneNumber";
						String phoneNumber = null;
						
						if (map.get(key).matches(regex)) {
							 phoneNumber = getStatusPhone();
						} else {
							phoneNumber = map.get(key);
						}
						validateValue(key, phoneNumber, dataSet.get(dbKey));
						break;
					case "resourceID":
						dbKey = "sessionresources.resourceid";
						validateValue(key, map.get(key), dataSet.get(dbKey));
						break;
					case "State":
						dbKey = "sessioninfo.state";
						validateValue(key, map.get(key), dataSet.get(dbKey));
						break;
					case "Status":
						dbKey = "sessioninfo.status";
						validateValue(key, map.get(key), dataSet.get(dbKey));
						break;
					case "sessionresources.Status":
						dbKey = "sessionresources.status";
						validateValue(key, map.get(key), dataSet.get(dbKey));
						break;
					case "SubType":
						dbKey = "sessionresources.subtype";
						validateValue(key, map.get(key), dataSet.get(dbKey));
						break;
					case "vendorlink.phoneNumber":
						validateValue(key, map.get(key), dataSet.get(key));
						break;
				default:
						String msg = "No such Key! " + key;
						log.info(msg);

					
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		return result;
	
	}
	
	public static boolean validateVendorLink(Map<String, String> map) {
		Set<String> keys = map.keySet();
		Map<String, String> vendorLinkData = getVendorLinkData();
		result = true;
		String regex = "get[A-Za-z]+";
		String expected = null;

		try {
			for (String key : keys) {
				switch (key) {
					case "AccountID":
						validateValue(key, map.get(key), vendorLinkData.get(key));
						break;
					case "InternalGUID":
						if (map.get(key).matches(regex)) {
							expected = getEwDeviceId();
						} else {
							expected = map.get(key);
						}
						validateValue(key, expected, vendorLinkData.get(key));
						break;
					case "ExternalGUID":
						if (map.get(key).matches(regex)) {
							expected = getLegacyDeviceId();
						} else {
							expected = map.get(key);
						}
						validateValue(key, expected, vendorLinkData.get(key));
						break;
					case "phoneNumber":
						if (map.get(key).matches(regex)) {
							expected = getPhoneNumber();
						} else {
							expected = map.get(key);
						}
						validateValue(key, expected, vendorLinkData.get(key));
						break;
					case "SOID":
						validateValue(key, map.get(key), vendorLinkData.get(key));
						break;
					default:
						String msg = "The field requested is not available!";
						log.info(msg);
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		return result;

	}
	
	/**
	 * A method to compare the expected and the actual value of a database field. The result of the comparison is logged.
	 * The overall result of the data validation is updated.
	 * @param key The name of the field that is being compared.
	 * @param expected The expected value of the field being compared.
	 * @param actual THe actual value of the field being compared.
	 */
	private static void validateValue(String key, String expected, String actual) {
		if (null == actual) {
			actual = "";
		}
		if (!expected.equals(actual)) {
			String msg = "The actual value for key " + key + " is " + actual + " and does not equal the expected value " + expected + ".";
			log.info(msg);
			updateResult(false);
		} else {
			log.info("The " + key + " element was successfully validated.");
		}

		return;
	}
	
	/**
	 * The method that updates the overall result of the data validation.
	 * @param status The result of a single comparison
	 */
	private static void updateResult(boolean status) {
		if (result == true && status == false) {
			result = false;
		}

	}
	
	/**
	 * A method to get the dataset of actual values from the database
	 * @return
	 */
	private static Map<String, String> getDataSet() {
		final String keyName = "ewSID";
		String ewSid = "";
		String contentType = "";
		
		try {
			contentType = ApiDriver.getResp().contentType();
			
			if (contentType.contains("json")) {
				ewSid = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), keyName);
			} else if (contentType.contains("xml")) {
				ewSid = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//teid/text()");
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		log.info("The ewSID is " + ewSid);
		MockingDetails details = Mockito.mockingDetails(creator);
		if (!details.isMock()) {
			creator = new ResultSetCreator(ewSid);
		}
		
		return creator.getResultSet("payfone");
	}
	
	/**
	 * Retrieves a value from the environment.properties file
	 * @return The value of the requested property.
	 */
	private static String getStatusPhone() {
		String result = null;
		String env = Env.getProperty("payfoneEnvironment");
		result = Env.getProperty(env + "StatusPhone").replaceAll("-", "");
		return result;
	}
	
	private static Map<String, String> getVendorLinkData() {		
		MockingDetails details = Mockito.mockingDetails(creator);
		if (!details.isMock()) {
			creator = new ResultSetCreator();
		}
			
		return creator.getVendorLinkData("payfone");		
	}
	
	static String getEwDeviceId() {
		String key = "data.ewDeviceId";
		String contentType = null;
		
		contentType = ApiDriver.getResp().contentType();
		
		if (contentType.contains("json")) {
			return ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), key);
		} else if (contentType.contains("xml")) {
			return ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//ewDeviceId/text()");
		}
		
		return "";
	}

	static String getLegacyDeviceId() {
		String key = "data.legacyDeviceId";
		String contentType = null;
		
		contentType = ApiDriver.getResp().contentType();
		
		if (contentType.contains("json")) {
			return ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), key);
		} else if (contentType.contains("xml")) {
			return ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//legacyDeviceId/text()");
		}
		return "";
	}
	
	static String getPhoneNumber() {
		String key = "data.phoneNumber";
		String contentType = null;
		
		contentType = ApiDriver.getResp().contentType();
		
		if (contentType.contains("json")) {
			return ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), key);
		} else if (contentType.contains("xml")) {
			return ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//phoneNumber/text()");
		}
		return "";
	}
}
