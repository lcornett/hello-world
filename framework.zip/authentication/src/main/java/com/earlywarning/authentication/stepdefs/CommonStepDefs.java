/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.stepdefs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.Map;

import com.earlywarning.authentication.applogs.LogValidator;
import com.earlywarning.authentication.common.ApiDriver;
import com.earlywarning.authentication.common.Request;
import com.earlywarning.authentication.common.RequestCreator;
import com.earlywarning.authentication.common.ResponseValidator;
import com.earlywarning.authentication.common.StoredParams;
import com.earlywarning.authentication.database.DataValidator;
import com.earlywarning.authentication.jsoncompare.JsonComparator;
import com.earlywarning.authentication.startup.Env;
import com.earlywarning.authentication.xmlcompare.XmlComparator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.DataTable;
import cucumber.api.java8.En;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;

/**
 * <p>A Cucumber step definition class using Java 8 lambdas. These step definitions
 * act on messages (requests and responses) that are defined in the com.earlywarning.authentication.common
 * package, which is how this class got it's name. The step definitions included in this class are 
 * described below.</p>
 * 
 * <p>The 'Given' Step Definitions:<ol>
 * 	<li><code>Given the request has the value &lt;string&gt; = &lt;string&gt;</code> - This step definition
 * 		allows the user to create a valid JSON request with the tag and value identified. The 
 * 		tag used must be one of the tags implemented in the RequestCreator class.</li>
 * 	<li><code>Given the request has the values</code> - This step definition requires a DataTable as
 * 		an argument. A DataTable takes the format <br> | &lt;name of tag&gt; | &lt;value of tag&gt; | <br>
 * 		Again this step definition allows the user to create a valid JSON request using the tags identified.</li>
 * 	<li><code>Given the following json request</code> - This step definition allows the user to input a preformatted
 * 		JSON message instead of building a JSON message. This allows using an invalid JSON message. The format
 * 		of this step definition is as follows:<br>
 * 		<code>Given the following json request
 * 			  """
 * 				&lt;Invalid JSON message&gt;
 * 			  """</code><br>
 * 		This step definition requires the triple quotes around the invalid JSON message.</li></ol>
 * <p> The 'When" Step Definitions:<ol>
 * 	<li><code>When the request is sent</code> - This step definition uses the 'environment.properties' file to 
 * 		populate the rest endpoint and post the message created in the Given step to that endpoint.</li>
 * 	<li><code>When the request is sent to  responsive web</code> - This step definition uses the 'environment.properties'
 * 		file to populate the responsive web endpoint. The message is then posted to that endpoint.</li>
 * 	<li><code>When the json request is sent to the responsive web</code> - This step definition is similar to the above
 * 		except that it posts the preformatted JSON message to the endpoint.</li>
 * 	<li><code>When the poll request is sent</code> - This step definition is used when it is expected that the response
 * 		has a status code of 7000 (Session in Progress). In this case, the system polls the server until
 * 		a final response is received.</li>
 * 	<li><code>When I send a request with the vfp</code> - A message having the vfp element is created and the message
 * 		is sent to the appropriate endpoint.</li>
 * 	<li><code>When the request is sent to the redirectedUrl</code> - This step definition doesn't do anything useful
 * 		at this time. It needs to be revisited.</li></ol>
 * <p>The 'Then' Step Definitions:<ol>
 * 	<li><code>Then the response element &lt;string&gt; = &lt;string&gt;</code> - This step definition is used to verify
 * 		a single element is a response.</li>
 * 	<li><code>Then the response redirectTargetUrl is not empty</code> - This step definition verifies that the 
 * 		redirectTargetUrl element of the response message is included and populated.</li>
 * 	<li><code>Then I send the request to get the vfp</code> - Creates the message to get the vfp.</li>
 * 	<li><code>Then the &lt;string&gt; tag is not in the final response</code> - Verifies that the specified
 * 		element is not in the final response.</li>
 * 	<li><code>Then the &lt;string&gt; tag is in the final response</code> - Verifies that the specified element is 
 * 		in the final response.</li>
 * 	<li><code>Then store the &lt;string&gt;</code> - Stores the value of the specified element for use in another
 * 		scenario.</li>
 * 	<li><code>Then store the response</code> - Stores the entire response for use in another scenario.</li>
 * 	<li><code>Then the response equals the stored response</code> - Compares the current response to the stored response.</li>
 * 	<li><code>Then the http status code is &lt;number&gt;</code> - Verifies that the httpStatus equals the expected httpStatus.</li>
 * 	<li><Code>Then the JSON elements are verified</code> - Uses a data table to list the JSON elements and their expected
 * 		values to validate the actual JSON result</li>
 * 	<li><code>Then compare the &lt;JsonPath&gt; with the stored &lt;JsonPath&gt;</code> - Compares a stored value with the 
 * 		actual returned value of an element.</li>
 *  <li><code>Then the actual &lt;String&gt; does not equal the stored &lt;String&gt;</code> - Compares the value of an element with
 *  	the stored value of that element.</li>
 *  <li><code>Then verify from log &lt;String&gt;  = from database &lt;String&gt;</code> - Gets a value from Payfone response in
 *  	the SessionProcessor log and compares it to a value in the database. The value from the SessionProcessor log must be a JSON
 *  	Path (e.g., Response.PayfoneAlias).</li>
 *  <li><code>Then verify from log against the database</code> - Verifies multiple values from the Payfone response against the database.
 *  	This step definition uses a data table to pass in the keys for both the SessionProcessor log and the database.</li>
 *  <li><code>Then verify from log &lt;String&gt;  = from result &lt;String&gt;</code> - Gets a value from Payfone response in
 *  	the SessionProcessor log and compares it to a value in the ews Response. Both value  must be a JSON Path (e.g., Response.PayfoneAlias).
 *  <li><code>Then verify from log against the result</code> - Verifies multiple values from the Payfone response to values in the 
 *  	ews response. A data table is used containing the payfone response keys and the ews response keys (i.e., | payfoneResponseKey | ewsResponseKey |).</li>
 *  <li><code>Then verify from log &lt;String&gt;  = &lt;String&gt;</code> - Gets a value from Payfone response in
 *  	the SessionProcessor log and compares it to a value. The value from the SessionProcessor log must be a JSON
 *  	Path (e.g., Response.PayfoneAlias).</li>
 *  <li><code>Then verify from log values</code> - a step that verifies multiple values from the logged Payfone response
 *  	against their corresponding absolute value. This step used a DataTable for the JsonPath and the absolute value.</li>
 *  <li><code>Then verify the following database fields</code> - This step definition requires a data table as a parameter and is used
 *  	to perform database validation.</li>
 *  <li><code>Then verify the following vendorLink table fields</code> - Similar to the above except the database validates
 *  	against the vendorLink table.</li>
 *  <li><code>Then verify in log request &lt;String&gt; = &lt;String&gt;</code> - The step definition looks through the SessionProcessor
 *  	log to retrieve the value of an element in the request to Payfone. The first string variable must be a JSON Path. The 
 *  	second string variable may be an absolute value or a 'get&lt;field&gt;'.</li>
 *  <li><code>Then verify from log request values</code> - Looks through the SessionProcessor log to get the Payfone request
 *  	where the request id matches the ewSID of the current response. Validates the values in the Payfone request against
 *  	expected values. This step definition uses a data table.</li> 
 * </ol><p>
 * 
 * @author cornettl
 *
 */
@Log4j2
public class CommonStepDefs implements En {
	private static Request request;
	private ObjectMapper mapper = new ObjectMapper();
	private static ApiDriver apiDriver;
	private static Response resp;
	private static String redirectTarget;
	private static String vfp;
	private static String jsonRequest;
	
	/**
	 * The constructor which contains all of the Step Definitions used by the 
	 * Cucumber framework. It is not intended to be used by the automation developer.
	 */
	public CommonStepDefs() {
		Given("^the request has the value \"([^\"]*)\" = \"([^\"]*)\"$", (String key, String value) -> {
		    Map<String, String> map = new HashMap<String, String>();
		    
			if (null == request) {
		    	request = new Request();
		    }
		    
			map.put(key, value);
		    
		    request = RequestCreator.createRequest(map, request);
    	});
		
		Given("^the request has the values$", (DataTable data) -> {
			Map<String, String> map = data.asMap(String.class, String.class);
			request = RequestCreator.createRequest(map);
		});
		
		Given("^the following json request$", (String json) -> {
		    jsonRequest = json;
		});

		When("^the request is sent$", () -> {
			String jsonString = null;
			String contentType = "application/json";
			String environment = Env.getProperty("environment");
			String url = Env.getProperty(environment+"Endpoint");
			apiDriver = new ApiDriver(contentType, url);
			
			try {
				jsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
				log.info("The request being sent is:\n" + jsonString);

				apiDriver.setBody(mapper.writeValueAsString(request));
				apiDriver.post();
			} catch (JsonProcessingException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		});
		
		When("^the request is sent to responsive web$", () -> {
			String environment = Env.getProperty("environment");
			String url = Env.getProperty(environment+"ResponsiveWebEndpoint");
			String contentType = "application/json";
			String jsonString = null;
			apiDriver = new ApiDriver(contentType, url);
			
			try {
				jsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
				log.info("The request being sent is: " + jsonString);
				
				apiDriver.setBody(mapper.writeValueAsString(request));
				apiDriver.post(true);
			} catch (JsonProcessingException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		});
		
		When("^the json request is sent to responsive web$", () -> {
			String environment = Env.getProperty("environment");
			String url = Env.getProperty(environment+"ResponsiveWebEndpoint");
			String contentType = "application/json";
			apiDriver = new ApiDriver(contentType, url);
			
			try {
				log.info("The request being sent is: " + jsonRequest);
				
				apiDriver.setBody(jsonRequest);
				apiDriver.post(true);
			} catch (Exception e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		});

		
		When("^the poll request is sent$", () -> {
			
			resp = apiDriver.poll();
		});
		
		When("^I send a request with the vfp$", () -> {
			String jsonString = null;
			
			try {
				request = RequestCreator.createVfpRequest(request, vfp);
				jsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
				log.info("The vfpRequest is " + jsonString);
				
				apiDriver.setBody(mapper.writeValueAsString(request));
				apiDriver.post();
			} catch (JsonProcessingException e) {
				log.info(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		});

		When("^the request is sent to the redirectedUrl$", () -> {
			
			ApiDriver.retrieveJsonValueString(resp, "phoneNumber");
		});

		Then("^the response element \"([^\"]*)\" = \"([^\"]*)\"$", (String field, String value) -> {
		    String msg = "";
		    String contentType = "";
		    String elementValue = null;
		    
			try {
				resp = ApiDriver.getResp();
				contentType = resp.contentType();
				
				if (contentType.contains("json")) {
					 elementValue = ApiDriver.retrieveJsonValueString(resp, field);
				} else if (contentType.contains("xml")) {
					String localField = field +"/text()";
					elementValue = ApiDriver.retrieveXMLvaluefromTag(resp, localField);
				}
				
				if (elementValue.equals(value)) {
					msg = "The actual and expected value of the element " + field + " is " + value +".";
					log.info(msg);
					assertTrue(true);
				} else {
					msg = "The actual value of " +field+ " is " + elementValue + ". The expected value is " + value +".";
					log.info(msg);
					assertTrue(false);
				}
			} catch (Exception e) {
				log.info(e.getMessage());
				log.debug(e.getMessage(), e);
				fail(e.getMessage());
			}
		});
		
		Then("^the response redirectTargetUrl is not empty$", () -> {
			String key = "data.dataLookup.RedirectTargetUrl";
			String contentType = null;
			
			resp = ApiDriver.getResp();
			contentType = resp.contentType();
			
			if (contentType.contains("json")) {
				redirectTarget = ApiDriver.retrieveJsonValueString(resp, key);
			} else if (contentType.contains("xml")) {
				key = "AuthentXML/body/response/data/dataLookup/RedirectTargetUrl/text()";
				redirectTarget = ApiDriver.retrieveXMLvaluefromTag(resp, redirectTarget);
			}
			assertTrue(!redirectTarget.isEmpty());
		});

		Then("^I send the request to get the vfp$", () -> {
		    
			vfp = RequestCreator.getvfp(redirectTarget);
			
		});
		
		Then("^the \"([^\"]*)\" tag is not in the final response$", (String key) -> {
			String contentType = null;
			String msg = "The " + key + " tag was not found in the final response!";
			
			resp = ApiDriver.getResp();
			contentType = resp.contentType();
			
			if (contentType.contains("json")) {
				assertTrue(ApiDriver.retrieveJsonValueString(resp, key).isEmpty());
			} else if (contentType.contains("xml")) {
				String localKey = key + "/text()";
				assertTrue(ApiDriver.retrieveXMLvaluefromTag(resp, localKey).isEmpty());
			}
			log.info(msg);
		});
		
		Then("^the \"([^\"]*)\" tag is in the final response$", (String key) -> {
			String msg = "The " + key + " element was found in the final result.";
			String contentType = null;
			
			resp = ApiDriver.getResp();
			contentType = resp.contentType();
			
			if (contentType.contains("json")) {
				assertTrue(!ApiDriver.retrieveJsonValueString(resp, key).isEmpty());
			} else if (contentType.contains("xml")) {
				String localKey = key + "/text()";
				assertTrue(!ApiDriver.retrieveXMLvaluefromTag(resp, localKey).isEmpty());
			}

			log.info(msg);
		});
		
		Then("^store the \"([^\"]*)\"$", (String tag) -> {
			String value = null;
			String contentType = null;
			String localTag = tag + "/text()";
			resp = ApiDriver.getResp();
			
			contentType = resp.contentType();
			
			if (contentType.contains("json")) {
				value = ApiDriver.retrieveJsonValueString(resp, tag);
			} else if (contentType.contains("xml")) {
				value = ApiDriver.retrieveXMLvaluefromTag(resp, localTag);
			}
			
			StoredParams.store(tag, value);
		});

		Then("^store the response$", () -> {
			String response = resp.asString();
			StoredParams.store("response", response);
		});
		
		Then("^the response equals the stored response$", () -> {
			String expected = StoredParams.retrieve("response");
			String actual = resp.asString();
			String contentType = resp.contentType();
			
			if (contentType.contains("json")) {
				assertTrue(JsonComparator.compareResponse(actual, expected));
			} else if (contentType.contains("xml")) {
				assertTrue(XmlComparator.compareElements(expected, actual));
			}
		});
		
		Then("^the http status code is (\\d+)$", (Integer expected) -> {
			int status = ApiDriver.getHttpStatus();
			String msg = "";
			if (expected == status) {
				msg = "The actual and the expected httpStatus were " + status +".";
			} else {
				msg = "The actual status code from the server was " + status + ". The expected code was " + expected + ".";
			}
			log.info(msg);
			assertTrue(expected == ApiDriver.getHttpStatus());
		});
		
		Then("^the JSON elements are verified$", (DataTable data) -> {
			Map<String, String> map = data.asMap(String.class, String.class);
			resp = ApiDriver.getResp();
			boolean result = ResponseValidator.validateResponse(resp, map);
			assertTrue(result);
			System.out.println(result);
		});
		
		Then("^compare the \"([^\"]*)\" with the stored \"([^\"]*)\"$", (String keyName, String storedKeyName) -> {
			String contentType = resp.contentType();
			String actualValue = null;
			
			if (contentType.contains("json")) {
				actualValue = ApiDriver.retrieveJsonValueString(resp, keyName);
			} else if (contentType.contains("xml")) {
				String localKeyName = keyName + "/text()";
				actualValue = ApiDriver.retrieveXMLvaluefromTag(resp, localKeyName);
			}
			
			String storedValue = StoredParams.retrieve(storedKeyName);
			
			assertEquals(actualValue,storedValue);
		});
		
		Then("^the actual \"([^\"]*)\" does not equal the stored \"([^\"]*)\"$", (String keyName, String storedKeyName) -> {
			String actualValue = ApiDriver.retrieveJsonValueString(resp, keyName);
			String storedValue = StoredParams.retrieve(storedKeyName);
			
			assertTrue(!actualValue.equals(storedValue));
		});
		
		Then("^verify from log \"([^\"]*)\" = from database \"([^\"]*)\"$", (String logKeyName, String databaseKeyName) -> {
			LogValidator validator = new LogValidator();
			assertTrue(validator.validateDbValue(logKeyName, databaseKeyName));
			
		});
		
		Then("^verify from log against the database$", (DataTable data) -> {
			Map<String, String> map = data.asMap(String.class, String.class);
			
			LogValidator validator = new LogValidator();
			assertTrue(validator.validateDbValues(map));
			
		});

		
		Then("^verify from log \"([^\"]*)\" = from result \"([^\"]*)\"$", (String logKeyName, String responseKeyName) -> {
			LogValidator validator = new LogValidator();
			assertTrue(validator.validateResponseValue(logKeyName, responseKeyName));
			
		});
		
		Then("^verify from log against the result$", (DataTable data) -> {
			Map<String, String> map = data.asMap(String.class, String.class);
			
			LogValidator validator = new LogValidator();
			assertTrue(validator.validateResponseValues(map));
			
		});

		Then("^verify from log \"([^\"]*)\" = \"([^\"]*)\"$", (String logKeyName, String value) -> {
			LogValidator validator = new LogValidator();
			assertTrue(validator.validateValue(logKeyName, value));
			
		});
		
		Then("^verify from log values$", (DataTable data) -> {
			Map<String, String> map = data.asMap(String.class, String.class);
			LogValidator validator = new LogValidator();
			assertTrue(validator.validateValues(map));
			
		});


		Then("^verify the following database fields$", (DataTable data) -> {
			final String msg = "Test is not being executed in the QA environment. Skipping database validation!";
			Map<String, String> map = data.asMap(String.class, String.class);
			
			// The database validation only occurs in the qa environment. Check the environment.
			if (!Env.getProperty("environment").equals("qa") && !Env.getProperty("payfoneEnvironment").equals("staging")) {
				log.info(msg);			
				return;
			}
			assertTrue(DataValidator.validateData(map));
		});
		
		Then("^verify the following vendorLink table fields$", (DataTable data) -> {
			final String msg = "Test is not being executed in the QA environment. Skipping database validation!";
			Map<String, String> map = data.asMap(String.class, String.class);
			
			// The database validation only occurs in the qa environment. Check the environment.
			if (!Env.getProperty("environment").equals("qa") && !Env.getProperty("payfoneEnvironment").equals("staging")) {
				log.info(msg);			
				return;
			}
			
			assertTrue(DataValidator.validateVendorLink(map));	    
		});
		
		Then("^verify in log request \"([^\"]*)\" = \"([^\"]*)\"$", (String logKeyName, String value) -> {
			LogValidator validator = new LogValidator();
			assertTrue(validator.validateRequestValue(logKeyName, value));
		});
		
		Then("^verify from log request values$", (DataTable data) -> {
			Map<String, String> map = data.asMap(String.class, String.class);
			LogValidator validator = new LogValidator();
			assertTrue(validator.validateRequestValues(map));
		});

	}
}
