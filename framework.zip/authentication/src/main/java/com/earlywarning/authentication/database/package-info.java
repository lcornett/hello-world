/**
 * 
 */
/**
 * This package contains the classes to connect to the databases for Authentify.
 * 
 * @author cornettl
 *
 */
package com.earlywarning.authentication.database;