/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.notificationserver;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.earlywarning.authentication.common.StoredParams;
import com.earlywarning.authentication.notificationserver.Request;
import com.earlywarning.authentication.startup.Env;
import com.earlywarning.authentication.utils.DateUtils;
import com.earlywarning.authentication.utils.FileFinder;

import lombok.extern.log4j.Log4j2;

/**
 * This RequestCreator class creates an instance of the 
 * com.earlywarning.authentication.notificationserver.Request class.
 * This class is used to create requests for the Notification Server.
 * @author cornettl
 */
@Log4j2
public class RequestCreator {
	private static SmsHeader.SmsHeaderBuilder headerBuilder;
	private static Request.RequestBuilder requestBuilder;
	private static EmailHeader.EmailHeaderBuilder emailBuilder;
	
	/**
	 * The method that creates the request. 
	 * @param map The name/value pairs of the elements of the request.
	 * @return An instance of the com.earlywarning.authentication.notificationserver.Request class.
	 */
	public static Request createRequest(Map<String, String> map) {
		Set<String> keys = map.keySet();
		Request request = null;
		SmsHeader header = null;
		EmailHeader email = null;
		String value = "";
		String regex = "";
		
		try {
			requestBuilder = Request.builder();
			
			for (String key : keys) {
				switch (key) {
					case "clientAcctId":
						if (map.get(key).equalsIgnoreCase("empty")) {
							requestBuilder.clientAcctId(value);
						} else {
							requestBuilder.clientAcctId(map.get(key));
						}						
						break;
					case "clientContext":
						if (map.get(key).equalsIgnoreCase("empty")) {
							requestBuilder.clientContext(value);
						} else {
							requestBuilder.clientContext(map.get(key));
						}
						break;
					case "clientId":
						if (map.get(key).equalsIgnoreCase("empty")) {
							requestBuilder.clientContext(value);
						} else {
							requestBuilder.clientId(map.get(key));
						}						
						break;
					case "clientSessionId":
						if (map.get(key).equalsIgnoreCase("empty")) {
							requestBuilder.clientSessionId(value);
						} else {
							requestBuilder.clientSessionId(map.get(key));
						}
						break;
					case "dataStore":
						requestBuilder.dataStore(Boolean.parseBoolean(map.get(key)));
						break;
					case "dateBegin":
						String when = map.get(key);
						if (map.get(key).equalsIgnoreCase("today")) {
							requestBuilder.dateBegin(DateUtils.getToday());
						} else if (when.matches("-?[0-9]")) {
							requestBuilder.dateBegin(DateUtils.getDate(Long.parseLong(when)));
						} else if (when.matches("get[A-Za-z]+")) { 
							requestBuilder.dateBegin(StoredParams.retrieve("date"));
						} else {
							requestBuilder.dateBegin(map.get(key));
						}
						break;
					case "email.destination":
						regex = "get[a-zA-Z]+";
						String emailDest = map.get(key);
						if (null == emailBuilder) {
							emailBuilder = EmailHeader.builder();
						}
						if (emailDest.equalsIgnoreCase("empty")) {
							emailBuilder.destination(value);
						} else if (emailDest.matches(regex)) {
							emailBuilder.destination(getEmailDestination());
						} else {
							emailBuilder.destination(map.get(key));
						}
						break;
					case "sms.destination":
						regex = "get[a-zA-Z]+";
						String dest = map.get(key);
						
						if (null == headerBuilder) {
							headerBuilder = SmsHeader.builder();
						}
						
						if (dest.equalsIgnoreCase("empty")) {
							headerBuilder.destination(value);
						} else if (dest.matches(regex)) {
							headerBuilder.destination(getDestination());
						} else {
							headerBuilder.destination(map.get(key));
						}						
						break;
					case "emailHeader":
						emailBuilder = EmailHeader.builder();
						break;
					case "emailType":
						
						if (null == emailBuilder) {
							emailBuilder = EmailHeader.builder();
						}

						if (map.get(key).equalsIgnoreCase("empty")) {
							emailBuilder.emailType(value);
						} else {
							emailBuilder.emailType(map.get(key));
						}
						break;
					case "event":
						if (map.get(key).equalsIgnoreCase("empty")) {
							requestBuilder.event(value);
						} else {
							requestBuilder.event(map.get(key));
						}						
						break;
					case "license":
						if (map.get(key).equalsIgnoreCase("empty")) {
							requestBuilder.license(value);
						} else {
							requestBuilder.license(map.get(key));
						}
						
						break;
					case "licenseKey":
						regex = "get[A-Za-z]+";
						if (map.get(key).matches(regex)) {
							String env = Env.getProperty("environment");
							requestBuilder.licenseKey(Env.getProperty(env + "License"));
						}
						break;
					case "maxRecords":
						requestBuilder.maxRecords(Integer.parseInt(map.get(key)));
						break;
					case "email.message":
						regex = "get[a-zA-Z0-9]+";
						
						if (null == emailBuilder) {
							emailBuilder = EmailHeader.builder();
						}

						if (map.get(key).equalsIgnoreCase("empty")) {
							emailBuilder.message(value);
						} else if (map.get(key).matches(regex)) {
							emailBuilder.message(get64KMessage());
						} else {						
//							emailBuilder.message(map.get(key));
							UUID uuid = UUID.randomUUID();
							MessageVerifier.setExpected(uuid.toString());
							emailBuilder.message(uuid.toString());
						}
						break;
//					case "notify.message":
//						if (map.get(key).equalsIgnoreCase("empty")) {
//							notifyBuilder.message(value);
//						} else {
//							notifyBuilder.message(map.get(key));
//						}
//						break;						
					case "sms.message":
						
						if (null == headerBuilder) {
							headerBuilder = SmsHeader.builder();
						}

						if (map.get(key).equalsIgnoreCase("empty")) {
							headerBuilder.message(value);
						} else {
							UUID uuid = UUID.randomUUID();
							MessageVerifier.setExpected(uuid.toString());
							headerBuilder.message(uuid.toString());
						}
						break;
					case "msgIndex":
						regex = "get[A-Za-z]+";
						if (map.get(key).matches(regex)) {
							requestBuilder.msgIndex(StoredParams.retrieve("ewSID"));
						} else {
							requestBuilder.msgIndex(map.get(key));
						}
						break;
					case "messageType":
						if (map.get(key).equalsIgnoreCase("empty")) {
							requestBuilder.messageType(value);
						} else {
							requestBuilder.messageType(map.get(key));
						}						
						break;
					case "numDays":
						requestBuilder.numDays(Integer.parseInt(map.get(key)));
						break;
					case "email.replyTo":
						
						if (null == emailBuilder) {
							emailBuilder = EmailHeader.builder();
						}

						if (map.get(key).equalsIgnoreCase("empty")) {
							emailBuilder.replyTo(value);
						} else {
							emailBuilder.replyTo(map.get(key));
						}
						break;
					case "email.sender":
						
						if (null == emailBuilder) {
							emailBuilder = EmailHeader.builder();
						}

						if (map.get(key).equalsIgnoreCase("empty")) {
							emailBuilder.sender(value);
						} else {
							emailBuilder.sender(map.get(key));
						}
						break;
					case "sms.sender":
						
						if (null == headerBuilder) {
							headerBuilder = SmsHeader.builder();
						}

						if (map.get(key).equalsIgnoreCase("empty")) {
							headerBuilder.sender(value);
						} else {
							headerBuilder.sender(map.get(key));
						}						
						break;
					case "email.subject":
						
						if (null == emailBuilder) {
							emailBuilder = EmailHeader.builder();
						}

						if (map.get(key).equalsIgnoreCase("empty")) {
							emailBuilder.subject(value);
						} else {
							emailBuilder.subject(map.get(key));							
						}
						break;
					case "userId":
						regex = "get[a-zA-Z]+";
						String userId = map.get(key);
						
						if (userId.equalsIgnoreCase("empty")) {
							requestBuilder.userId(value);
						} else if (userId.matches(regex)) {
							requestBuilder.userId(getUser());							
						} else {
							requestBuilder.userId(map.get(key));
						}						
						break;
					default:
						String msg = "The element " + key + " is unknown!";
						log.warn(msg);
				}
			}
			
			if (headerBuilder != null) {
				header = headerBuilder.build();
				requestBuilder.smsHeader(header);
			}
			
			if (emailBuilder != null) {
				email = emailBuilder.build();
				requestBuilder.emailHeader(email);
			}
			
			request = requestBuilder.build();
			
			if ((null == request.getLicense()) && (null == request.getLicenseKey())) {
				String env = Env.getProperty("environment");
				String license = Env.getProperty(env + "License");
				request.setLicense(license);				
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} finally {
			headerBuilder = null;
			emailBuilder = null;
			requestBuilder = null;
		}
		return request;
	}
	
	/**
	 * A method to get the desired userId from the environment.properties file. 
	 * @return The notification userId for the environment.
	 */
	private static String getUser() {
		String env = Env.getProperty("environment");
		String userId = Env.getProperty(env + "NotificationUserId");
		return userId;
	}
	
	/**
	 * A method to get the sms destination.
	 * @return The notification destination for the environment.
	 */
	private static String getDestination() {
		String env = Env.getProperty("environment");
		String dest = Env.getProperty(env + "NotificationDestination");
		return dest;
	}
	
	/**
	 * A method to get the email destination form the environment.properties file.
	 * @return The Notification email destination for the environment.
	 */
	private static String getEmailDestination() {
		String env = Env.getProperty("environment");
		String dest = Env.getProperty(env + "NotificationEmailDestination");
		return dest;
	}
	
	/**
	 * A method to get the contents of a 64k file.
	 * @return The contents of the file.
	 */
	private static String get64KMessage() {
		String fileName = "64k message.txt";
		String filePath = null;
		String line = null;
		StringBuilder builder = new StringBuilder();
		
		try {
			filePath = FileFinder.find(fileName);

			BufferedReader reader = new BufferedReader(new FileReader(filePath));
			while ((line = reader.readLine()) != null) {
				builder.append(line);
			}
			reader.close();
		} catch (FileNotFoundException e) {
			log.error(e.getMessage());;
			log.debug(e.getMessage(), e);
		} catch (IOException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} 
		
		return builder.toString();
	}

}
