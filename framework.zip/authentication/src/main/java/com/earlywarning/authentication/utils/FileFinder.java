/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.utils;

import static java.nio.file.FileVisitResult.CONTINUE;
import static java.nio.file.FileVisitResult.SKIP_SUBTREE;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.PathMatcher;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Arrays;

import lombok.extern.log4j.Log4j2;

/**
* Walks the filesystem looking for files that match the pattern given. Typically,
* the parameter passed into the the Find method is just a file name. The starting 
* directory is the parent of the the System property "user.dir".
* @author cornettl
*
*/
@Log4j2
public class FileFinder {
	private static boolean isDev;
	private static ArrayList<String> devdirs; 


	/**
	 * A public class that actually performs the work of locating the file requested.
	 *
	 * @author cornettl
	 */
	public static class Finder extends SimpleFileVisitor<Path> {

		private final PathMatcher matcher;
		@SuppressWarnings("unused")
		private int numMatches = 0;
		private String found;
		private String fileName;

		/**
		 * The constructor for the Finder class.
		 *
		 * @param pattern The pattern for the file/s to find
		 */
		Finder(String pattern) {
			matcher = FileSystems.getDefault().getPathMatcher("glob:" + pattern);
			fileName = pattern;
		}

		/**
		 * Compares the glob pattern against the file or directory name
		 *
		 * @param file The file to match
		 */
		void find(Path file) {
			Path name = file.getFileName();
			if (name != null && matcher.matches(name)) {
				numMatches++;
				log.info("Found " + file);
				found = file.toString();
			}

		}

		/**
		 * Prints the number of matches to the console.
		 *
		 * @return The last file found or null if not found
		 */
		String done() {
			if (null == found) {
				throw new NullPointerException("Could not find any file: " + fileName);
			}
//			System.out.println("Matched: " + numMatches);
			return found;
		}

		/**
		 * Invoke the pattern matching method on each file
		 */
		@Override
		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
			find(file);
			return CONTINUE;
		}

		/**
		 * Invoke the pattern matching method in each directory
		 */
		@Override
		public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
			for (String directory : devdirs) {
				if (dir.endsWith(directory)) {
					return SKIP_SUBTREE;
				}
			}
			find(dir);
			return CONTINUE;
		}

		@Override
		public FileVisitResult visitFileFailed(Path file, IOException exc) {
			System.err.println(exc);
			return CONTINUE;
		}
	}

	/*
	 * The method of the FileFinder class to call to find a file.
	 * @return The FQN of the file found or null
	 */
	public static String find(String fileName) {
		Path startingDir = Paths.get(System.getProperty("user.dir"));
		getEnvironment(startingDir.toString());
		
		
		if (!isDev) {
			startingDir = startingDir.getParent();
		}
		
		Finder finder = null;
		try {
			finder = new Finder(fileName);
			Files.walkFileTree(startingDir, finder);
		} catch (IOException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		return finder.done();
	}
	/**
	 * This method looks for the src directory. If the src directory is found
	 * the environment is flagged as a development environment. This probably 
	 * only works for maven projects. To enhance this, make the directory to find
	 * a property in a properties file. 
	 */
	static void getEnvironment(String dir) {
		File file = new File(dir);
		String[] contents = file.list();
		String dirToFind = "src";
		
		isDev = Arrays.asList(contents).contains(dirToFind);
		
		devdirs = new ArrayList<String>();
		for (String directory : contents) {
			if (!directory.equals(dirToFind)) {
				File currentFile = new File(directory);
				if (currentFile.isDirectory()) {
					devdirs.add(directory);
				}
			}
		}
		
	}	
}

