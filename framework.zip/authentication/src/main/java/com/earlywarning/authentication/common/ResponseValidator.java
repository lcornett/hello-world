/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.common;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;

/**
 * The ResponseValidator is designed to validate the elements of an
 * Authentify JSON reqponse message. It works in conjunction with the 
 * JsonFieldConstants interface to use the JsonPath parameter for each
 * element and get the value of the response element and compare it to
 * the expected value of the element.
 * @author cornettl
 *
 */
@Log4j2
public class ResponseValidator implements JsonFieldConstants {
	private static boolean result = true;

	/**
	 * Compares the actual value of a response element with the expected value.
	 * @param response The response of the Authentify ReST request
	 * @param map A map of name value pairs fo rthe ecpected value of the named elements
	 * @return true if all of the elements match their expected value, false otherwise.
	 */
	public static boolean validateResponse(Response response, Map<String, String> map) {
		Set<String> keys = map.keySet();
				
		try {
			keys.forEach((key) -> {
				switch (key) {
					case "address":
						validateResponseMatchObject(response, key, map.get(key));
						break;
					case "addressStatus":
						validate(response, ADDRESS_STATUS, map.get(key));
						break;
					case "app":
						validate(response, APP, map.get(key));
						break;
					case "cardStatus":
						validate(response, CARD_STATUS, map.get(key));
						break;
					case "cardType":
						validate(response,CARD_TYPE, map.get(key));
						break;
					case "cardValid":
						validate(response, CARD_VALID, map.get(key));
						break;
					case "city":
						validateResponseMatchObject(response, key, map.get(key));
						break;
					case "clientAcctId":
						validate(response, CLIENT_ACCT_ID, map.get(key));
						break;
					case "clientContext":
						validate(response, CLIENT_CONTEXT, map.get(key));
						break;
					case "clientId":
						validate(response, CLIENT_ID, map.get(key));
						break;
					case "cvvStatus":
						validate(response, CVV_STATUS, map.get(key));
						break;
					case "debitNetwork":
						validate(response, DEBIT_NETWORK, map.get(key));
						break;
					case "email":
						validateResponseMatchObject(response, key, map.get(key));
						break;
					case "ewSID":
						validate(response, EWSID, map.get(key));
						break;
					case "fastFunds":
						validate(response, FAST_FUNDS, map.get(key));
						break;
					case "firstName":
						validateResponseMatchObject(response, "firstName", map.get(key));
						break;
					case "issuer":
						validate(response, ISSUER, map.get(key));
						break;
					case "lastName":
						validateResponseMatchObject(response, key, map.get(key));
						break;
					case "middleName":
						validateResponseMatchObject(response, key, map.get(key));
						break;
					case "name":
						validateResponseMatchObject(response, "name", map.get(key));
						break;
					case "postalCode":
						validateResponseMatchObject(response, key, map.get(key));
						break;
					case "region":
						validateResponseMatchObject(response, key, map.get(key));
						break;
					case "replyTo":
						validate(response, REPLY_TO, map.get(key));
						break;
					case "sgid":
						validate(response, SGID, map.get(key));
						break;
					case "statusCode":
						validate(response, STATUS_CODE, map.get(key));
						break;
					case "statusText":
						validate(response, STATUS_TEXT, map.get(key));
						break;
					case "timestampISO8601":
						validate(response, TIMESTAMP_ISO8601, map.get(key));
						break;
					default:
						String msg = "The element " + key + " was not found.";
						log.info(msg);					
				}
			});
		} finally {
			
		}
		
		return result;		
	}
	
	/**
	 * A method that validates an expected value against an actual value. 
	 * @param response A ReST response in JSON format
	 * @param key The path of the element to get.
	 * @param expected The expected value of the element.
	 */
	private static void validate(Response response, String key, String expected) {
		String actual = null;
		
		actual = ApiDriver.retrieveJsonValueString(response, key);
		
		if (!expected.equals(actual)) {
			String msg = "The actual value for key " + key + " is " + actual + " and does not equal the expected value " + expected + ".";
			log.info(msg);
			updateResult(false);
		} else {
			log.info("The " + key + " element was successfully validated");
		}
	}
	
	private static void validateResponseMatchObject(Response response, String key, String expected) {
		String json = response.asString();
		String msg = "";
		String jsonPath = "data.dataLookup.matchResults.";
		ObjectMapper mapper = new ObjectMapper();
		com.earlywarning.authentication.response.json.Response jsonObj = null;
		ArrayList<Match> matches = null;
		
		
		try {
			
			 jsonObj= mapper.readValue(json, com.earlywarning.authentication.response.json.Response.class);
			 matches = jsonObj.getData().getDataLookup().getMatchResults();
			 
			 for (Match match : matches) {
				 if ((match.getType().equals(key)) && (match.getMatch().equals(expected))) {
					 msg = "The actual and expected value of the element " +jsonPath + key + " are equal.";
					 log.info(msg);
				 } else if ((match.getType().equals(key)) && (!match.getMatch().equals(expected))) {
					 msg = "The expected value of the element " + jsonPath + key + " is " + expected +". The actual value is " + match.getMatch() + ".";
					 log.info(msg);
					 updateResult(false);
				 }
			 }
			
		} catch (IOException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} 
		
		

	}
	
	/**
	 * A method to update the result of the validation after each element is validated. 
	 * @param status The result of the last element validated.
	 */
	private static void updateResult(boolean status) {
		if (result == true && status == false) {
			result = false;
		}

	}
}
