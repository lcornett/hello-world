/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.applogs;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.earlywarning.authentication.common.ApiDriver;
import com.earlywarning.authentication.utils.FileFinder;

import lombok.extern.log4j.Log4j2;

/**
 * Reads in the sessionprocessor.properties file. The sessionprocessor.properties file
 * maps ids to a share on a remote host. A rest response is used to to get the id of the 
 * logging host.
 * @author cornettl
 *
 */
@Log4j2
public class LoggerMapper {
	private Properties loggerMap = new Properties();
	private String propsFile;

	/**
	 * Reads the rest response and gets the id from the replyTo element.
	 * @return The UNC of the log location to parse
	 */
	public String getLogger() {
		
		if (loggerMap.isEmpty()) {
			propsFile = FileFinder.find("sessionprocessor.properties");
			try {	
				InputStream in = new FileInputStream(propsFile);
				loggerMap.load(in);
				in.close();
			} catch (IOException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			} 
		}

		String key = "replyTo";
		String id = null;
		int location = 0;
		
		try {
			String contentType = ApiDriver.getResp().contentType();
			if (contentType.contains("xml")) {
				key = "//" + key + "/text()";
				id = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), key);
			} else if (contentType.contains("json")) {
				id = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), key);
			} 
			
			location = id.indexOf("id=");
			id = id.substring(location + 3, id.length());
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
			throw e;
		}
		return loggerMap.getProperty(id);
	}
}
