/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.xml;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import lombok.Builder;
import lombok.Data;

/**
 * <p>A POJO that represents the namedData element of the Authentify XML
 * request message.</p>
 * <p>This class utilizes the lombok Data and the lombok Builder annotations.
 * The Data annotation implements the getters and setters for the private property:</p><ul>
 * 	<li>messageText</li></ul>. The Builder annotation provides an implementation of an
 * all argument constructor and an implementation of the &lt;class name&gt;Builder class.
 * For additional information about these annotations, please see
 * <a href="{@docRoot}/com/earlywarning/authentication/xml/package-summary.html#tags">package-info</a> page.
 *
 * @author cornettl
 *
 */
@Data
@Builder
public class NamedData {
	@JacksonXmlProperty(localName="dat:dataItem name=\"messageText\"")	
	private String messageText;
	
	@JacksonXmlProperty(localName="dataItem name=\"returnlegacydeviceid\"")
	private String returnLegacyDeviceId;
}

