package com.earlywarning.authentication.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/**
 * <p>A Java POJO representing the Address element of an Authentify
 * JSON Request. This class utilizes the lombok.Data annotation to
 * implement the setters and getters for the following private 
 * properties:<ul>
 * 	<li>streetAddress</li>
 * 	<li>extendedAddress</li>
 * 	<li>city</li>
 * 	<li>postalCode</li>
 * 	<li>region</li>
 * 	<li>country</li></ul>
 * <p>The jackson JsonInclude annotation is also used to only include non -null
 * elements. For more information about the annotations see 
 * <a href="{@docRoot}/com/earlywarning/authentication/common/package-summary.html#tags">
 * package-info</a> 
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_NULL)
public class Address {
	private String streetAddress;
	private String extendedAddress;
	private String city;
	private String postalCode;
	private String region;
	private String country;
}
