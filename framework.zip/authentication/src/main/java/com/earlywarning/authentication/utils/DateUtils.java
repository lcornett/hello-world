/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;

public class DateUtils {

	public static String getToday() {
		LocalDate ld = LocalDate.now();
		
		return ld.toString();
	}
	
	public static String getDate(long offset) {
		String result = null;
		LocalDate ld = LocalDate.now();
		ld = ld.plus(offset, ChronoUnit.DAYS);
		result = ld.toString();
		return result;
		
	}
	
	public static String getLongToday() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
		LocalDate ld = LocalDate.now();
		LocalDateTime ldt = LocalDateTime.of(ld, LocalTime.MIDNIGHT);
		String result = ldt.format(formatter);
		return result;
	}
	
	public static String getUTC() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyy-MM-dd HH:mm:ss.SSS");
		ZonedDateTime zdc;
		LocalDateTime ldt = LocalDateTime.now(ZoneOffset.UTC);
		zdc = ldt.atZone(ZoneId.of("UTC"));
		ldt = ldt.from(zdc);
		String result = ldt.format(formatter);
		return result;
	}
	
	public static String getFormattedToday(String format) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
		LocalDate ld = LocalDate.now();
		LocalDateTime ldt = LocalDateTime.of(ld, LocalTime.MIDNIGHT);
		String result = ldt.format(formatter);
		return result;

	}
	
	public static void main(String[] args) {
		System.out.println(getToday());
		System.out.println(getLongToday());
		System.out.println(getDate(5));
		System.out.println(getUTC());
		System.out.println(getFormattedToday("yyyy_MM_dd"));
	}
}

