/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import com.earlywarning.authentication.common.ApiDriver;

import lombok.extern.log4j.Log4j2;

/**
 * A class that querries the database and creates a HashMap out of the ResultSet.
 * The HashMap can then be used to validate the test case using the DataValidator.
 * @author cornettl
 *
 */
@Log4j2
public class ResultSetCreator {
	private Map<String, String> resultSet = new HashMap<String, String>();
	private String teid;
	
	/**
	 * No argument constructor for the class
	 */
	public ResultSetCreator() {
		
	}
	
	/**
	 * A one argument constructor for the class. The argument for this
	 * constructor comes from the Rest response. If the response is JSON
	 * the argument is the ewSID, if XML the argument is the teid.
	 * @param teid The appropriate identifier from the response.
	 */
	public ResultSetCreator(String teid) {
		this.teid = teid;
	}
	
	/**
	 * The method to get a result set. This takes an argument based on the
	 * system that is being tested. (Currently only 'Payfone' is supported.
	 * @param queryName currently Payfone
	 * @return A map of the result set. This only has the data for the query 1 of the workbook test cases.
	 */
	public Map<String, String> getResultSet(String queryName) {		
		switch (queryName.toLowerCase()) {
			case "payfone":
				return getPayfoneResultSet();
				
			default:
				String msg = "Querries for " + queryName + "don't exist!";
				log.info(msg);			
		}
		return resultSet;		
	}
	
	/**
	 * A method to get the vendorlink data from the database.
	 * @param queryName Currently 'Payfone'
	 * @return A map of the result set. This only has the data for the query 2 of the workbook test cases
	 */
	public Map<String, String> getVendorLinkData(String queryName) {

		switch (queryName.toLowerCase()) {
			case "payfone":
				return getPayfoneVendorLinkData();
			default:
				String msg = "Querries for " + queryName + " vendorLinkData don't exist!";
				log.info(msg);			
		}
				
		return null;		
	}
	
	/**
	 * Gets the Payfone1 querries ResultSet.
	 * @return The result set for the Payfone1 Querries.
	 */
	private Map<String, String> getPayfoneResultSet() {
		Map<String, String> localResultSet = new HashMap<String, String>();
		Connection conn = null;
		String sessionId = null;		
		String sessionIdQuery = "select sessionId from sessioninfo where teid = '" + teid + "'"; 
		String[] querries = Query.PAYFONE1.getStatements();
		ResultSet rs = null;
		PreparedStatement stmt = null;
		ResultSetMetaData rsmd = null;
		
		try {
			conn = DataSource.getInstance(DatabaseMapper.getDatabase()).getBds().getConnection();
			rs = execute(conn, sessionIdQuery);
			if (rs.next()) {
				sessionId = rs.getString(1);
			} else {
				return null;
			}
			
			for (String query : querries) {
				int start = query.indexOf("from")+5;
				int end = query.indexOf(" ", start);
				String tableName = query.substring(start, end); 

				stmt = conn.prepareStatement(query);
				stmt.setString(1, sessionId);
				rs = stmt.executeQuery();
				rsmd = rs.getMetaData();
				
				while (rs.next()) {
					for (int column = 1; column <= rsmd.getColumnCount(); column++) {
						localResultSet.put(tableName + "." + rsmd.getColumnName(column), rs.getString(column));
					}
				}
			}
			
		} catch (SQLException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		}
		return localResultSet;
	}
	
	/**
	 * A method the execute the query provided on the connection provided.
	 * @param conn A valid database connection.
	 * @param query The query to execute.
	 * @return The query's ResultSet
	 */
	private ResultSet execute(Connection conn, String query) {	
		ResultSet rs = null;
		
		try {
			Statement stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
		} catch (SQLException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		return rs;

	}
	
	/**
	 * A method to get the Payfone2 query result set
	 * @return The result from the Payfone2 query
	 */
	private Map<String, String> getPayfoneVendorLinkData() {
		String phoneNumber = null;
		String internalGuid = null;
		ResultSet rs = null;
		PreparedStatement stmt = null;
		ResultSetMetaData rsmd = null;
		Connection conn = null;
		String[] querries = Query.PAYFONE2.getStatements();
		Map<String, String> localResultSet = new HashMap<String, String>();
		String contentType = ApiDriver.getResp().contentType();
		
		if (contentType.contains("json")) {
			phoneNumber = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), "data.phoneNumber");
			internalGuid = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), "data.ewDeviceId");
		} else if (contentType.contains("xml")) {
			phoneNumber = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//phoneNumber/text()");
			internalGuid = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//ewDeviceId/text()");
		}
		
		try {
			conn = DataSource.getInstance(DatabaseMapper.getDatabase()).getBds().getConnection();

			for (String query : querries) {
				stmt = conn.prepareStatement(query);
				stmt.setString(1, phoneNumber);
				stmt.setString(2, internalGuid);
				
				rs = stmt.executeQuery();
				rsmd = rs.getMetaData();

				while (rs.next()) {
					for (int column = 1; column <= rsmd.getColumnCount(); column++) {
						localResultSet.put(rsmd.getColumnName(column), rs.getString(column));
					}
				}
			}		
		} catch (SQLException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		}
		
		return localResultSet;		
	}

}
