/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.applogs;

import java.util.Map;
import java.util.Set;

import com.earlywarning.authentication.common.ApiDriver;
import com.earlywarning.authentication.common.StoredParams;
import com.earlywarning.authentication.database.ResultSetCreator;
import com.earlywarning.authentication.startup.Env;

import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;

/**
 * A class that provides the methods to validate the Payfone response to the authentify 
 * request to an expected result that is obtained from the database or the response sent
 * to the ews original requester.
 * @author cornettl
 *
 */
@Log4j2
public class LogValidator {
	static LogParser parser;
	ResultSetCreator creator;
	boolean result = true;


	/**
	 * A method that obtains the value of a field from the Payfone response and compares it 
	 * to a value from a specific database column. This method assumes the payfone queries.
	 * @param logKey The field name of the Payfone response that will be retrieved from the log.
	 * @param dbKey The column name of the database field to compare to.
	 * @return true if the values match, false otherwise.
	 */
	public boolean validateDbValue(String logKey, String dbKey) {
		String logValue = null;
		Map<String, String> result = null;

		logValue = getLogValue(logKey);
		
		String query = dbKeyToQuery(dbKey);
		
		if (creator == null) {
			creator = new ResultSetCreator();
		}
		if (query.equals("PAYFONE1")) {
			result = creator.getResultSet("payfone");
		} else if (query.equals("PAYFONE2")) {
			result = creator.getVendorLinkData("payfone");
		}
		return validate(logKey, logValue, result.get(dbKey));
	}
	
	/**
	 * A method that validates the Payfone Response values against the values in the database. This accepts
	 * a Map parameter to avoid multiple cals to the database and to the logger.
	 * @param data Contains the keys for both the Logger and the database.
	 * @return true if the values match, false otherwise.
	 */
	public boolean validateDbValues(Map<String, String> data) {
		boolean status = false;
		String dbKey = null;
		String query = null;
		String logValue = null;
		Set<String> keys = data.keySet();
		Map<String, String> dbResult1 = null;
		Map<String, String> dbResult2 = null;
		ValueRetriever retriever = getLogRetriever();
		
		if (creator == null) {
			creator = new ResultSetCreator();
		}
		
		for (String key : keys) {
			dbKey = data.get(key);
			query = dbKeyToQuery(dbKey);
			
			if (query.equals("PAYFONE1")) {
				if (null == dbResult1) {
					dbResult1 = creator.getResultSet("payfone");
				}					
				logValue = retriever.getValue(key);
				updateResult(validate(key, logValue, dbResult1.get(dbKey)));
			} else if (query.equals("PAYFONE2")) {
				if (null == dbResult2) {
					dbResult2 = creator.getVendorLinkData("payfone");
				}					
				logValue = retriever.getValue(key);
				updateResult(validate(key, logValue, dbResult2.get(dbKey)));
			}				
		}
		
		status = result;
		return status;
	}
	
	/**
	 * A method that compares the value of a field from the Payfone response message
	 * to the value of the response key that is in ews's response to the original request.
	 * @param logKey The name of the field to retrieve the value of  from the log.
	 * @param responseKey The name of the field to retrieve the value of from the ews response.
	 * @return true if the values match, false otherwise.
	 */
	public boolean validateResponseValue(String logKey, String responseKey) {
		String logValue = null;
		String responseValue = null;
		String contentType = null;

		logValue = getLogValue(logKey);
		
		contentType = ApiDriver.getResp().contentType();
		
		if (contentType.contains("json")) {
			responseValue = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), responseKey);
		} else if (contentType.contains("xml")) {
			responseValue = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), responseKey);
		} else {
			log.error("Cannot retrieve response value because the content type " + contentType + " is unknown.");
		}		
		
		return validate(logKey, logValue, responseValue);
	}
	
	/**
	 * A method to validate multiple SessionProcessor log values against a ews response. This 
	 * Method is used so that the call to parser the log only happens once.
	 * @param map Contains the JsonPath for the log element and the path to the response element.
	 * @return true if the values match, false otherwise.
	 */
	public boolean validateResponseValues(Map<String, String> map) {
		String contentType = ApiDriver.getResp().contentType();
		
		if (contentType.contains("json")) {
			return validateJsonResponseValues(map);
		} else if (contentType.contains("xml")) {
			return validateXmlResponseValues(map);
		}
		
		log.error("Couldn't determine the contentType of the response! Cannot process the step.");
		return false;
	}
	
	/**
	 * A method that compares the value of a field from a Payfone request message to
	 * an absolute value. In place of an absolute value, a get&lt;String&gt; may be used. If
	 * the second string begins with get the method will try to get the desired value. If
	 * the method to get the desired value does not exist, this will be logged.
	 * @param logKey The element name in the Payfone request to retrieve the value of.
	 * @param value The value to compare to.
	 * @return True if the values match, false otherwise.
	 */
	public boolean validateRequestValue(String logKey, String value) {
		String logValue = null;
		String regex = "get[A-Za-z]+";
		
		if (value.matches(regex)) {
			value = getActualValue(value.substring(3));
		}
		
		logValue = getLogRequestValue(logKey);
		return validate(logKey, logValue, value);
		
	}
	
	
	public boolean validateRequestValues(Map<String, String> map) {
		boolean status = false;
		String logValue = null;
		String expectedValue = null;
		String regex = "get[A-Za-z]+";
		Set<String> keys = map.keySet();
		ValueRetriever retriever = getLogRetriever("request");
		
		for (String key : keys) {
			logValue = retriever.getValue(key);
			expectedValue = map.get(key);
			
			if (expectedValue.matches(regex)) {
				expectedValue = getProperty(expectedValue.substring(3)).replaceAll("-", "");
				if (logValue.length() > expectedValue.length()) {
					expectedValue = "1" + expectedValue;
				}
			}
			
			updateResult(validate(key, expectedValue, logValue));
			
		}
		status = result;
		result = true;
		return status;
	}

	/**
	 * A method that compares the value obtained from the SessionProcessor log
	 * response from Payfone to an absolute value.
	 * @param logKey The name of the element to get from the logged response.
	 * @param value The value to compare to.
	 * @return true if the values match, false otherwise.
	 */
	public boolean validateValue(String logKey, String value) {
		String logValue = null;
		logValue = getLogValue(logKey);
		
		return validate(logKey, logValue, value);
	}
	
	/**
	 * A method that compares the values obtained from the SessionProcessor
	 * log response from Payfone to their coresponding absolute values.
	 * @param map A map of JsonPath strings and the expected value for that path
	 * @return true if the values match, false otherwise.
	 */
	public boolean validateValues(Map<String, String> map) {
		boolean status = false;
		String logValue = null;
		Set<String> keys = map.keySet();
		ValueRetriever retriever = getLogRetriever();
		
		for (String key : keys) {
			logValue = retriever.getValue(key);
			updateResult(validate(key, logValue, map.get(key)));
		}
		
		status = result;
		result = true;
		
		return status;
	}

	/**
	 * A method that compares the value obtained from the SessionProcessor log to another 
	 * value. This other value is usually from either the database of the response message.
	 * @param logKey The field name of the logged response field.
	 * @param logValue The value of the logged response field.
	 * @param responseValue The value to compare to.
	 */
	private boolean validate(String logKey, String logValue, String expectedValue) {
		String msg = "";
		
		if (logValue.equals(expectedValue)) {
			msg = "The log key " + logKey + " value equals the expected value.";
			log.info(msg);
			return true;
		} else if (!logValue.equals(expectedValue)) {
			msg = "The log key " + logKey + " value " + logValue + " does not equal the expected value " + expectedValue + ".";
			log.info(msg);
		}
		
		return false;
	}
	
	/**
	 * A method to to return the Query value that will return the data desired according
	 * to the database column passed in.
	 * @param dbKey The database column of the data to retrieve.
	 * @return The value of the Query to execute.
	 */
	private String dbKeyToQuery(String dbKey) {
		final String query1 = "PAYFONE1";
		final String query2 = "PAYFONE2";
		
		switch (dbKey.toLowerCase()) {
			case "externalguid":
				return query2;
			case "internalguid":
				return query2;
			default:
				return query1;
		}
		
	}
	
	/**
	 * A method to get the value of an element from the Payfone response contained in a SessionProcessor log
	 * @param logKey The JSON Path of the element to retrieve the value of.
	 * @return The value of the element
	 */
	private String getLogValue(String logKey) {
		String logger = null;
		String teid = null;
		String rawResponse = null;
		String contentType = null;
		
		LoggerMapper mapper = new LoggerMapper();
		logger = mapper.getLogger();
		
		contentType = ApiDriver.getResp().contentType();
		
		if (contentType.contains("xml")) {
			teid = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//teid/test()");					
		} else if (contentType.contains("json")) {
			teid = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), "ewSID");
		} else {
			log.error("Could not retrieve the teid! ContentType " + contentType + " unknown!");
		}
		
		
		if (parser == null) {
			parser = new LogParser();
		}
		rawResponse = parser.parseLog(logger, teid);
		
		ValueRetriever vr = new ValueRetriever(rawResponse);
		return vr.getValue(logKey);

	}
	
	/**
	 * Gets the value, identified by the element name, from the logged Payfone request.
	 * @param logKey The element name in the request.	
	 * @return The value of the element.
	 */
	private String getLogRequestValue(String logKey) {
		String logger = null;
		String teid = null;
		String rawResponse = null;
		
		LoggerMapper mapper = new LoggerMapper();
		logger = mapper.getLogger();
		
		teid = getTeid();
		
		if (parser == null) {
			parser = new LogParser();
		}
		rawResponse = parser.parseLogRequest(logger, teid);
		
		ValueRetriever vr = new ValueRetriever(rawResponse);
		return vr.getValue(logKey);

	}
	
	/**
	 * A method to lookup a value of an element. The lookup can be a stored value
	 * or a value from the environment.properties file. If this method does not
	 * know how to lookup the value requested, that fact will be logged and the 
	 * method will return null.
	 * @param value The value to lookup.
	 * @return The value obtained or null.
	 */
	private String getActualValue(String value) {
		
		switch (value) {
			case "LegacyDeviceId":
				// This value must be a stored value
				String key = "data.legacyDeviceId";
				return StoredParams.retrieve(key);
			case "StatusPhone":
				// This value is retrieved from the environment.properties
				String env = Env.getProperty("payfoneEnvironment");
				String number =  Env.getProperty(env + value);
				number = number.replaceAll("-", "");
				
				if (number.length() == 10) {
					number = "1" + number;
				}
				return number;
			default:
				String msg = "Can't retrieve this value " + value + "!";
				log.error(msg);
		}
		
		return null;
	}
	
	/**
	 * A method that gets an instance of the ValueRetriever class that has been instantiated with 
	 * the Payfone response for the current transaction.
	 * @return An instance of the ValueRetriever class.
	 */
	private ValueRetriever getLogRetriever() {
		String type = "response";
		
		return getLogRetriever(type);
	}
	
	/**
	 * A method that gets an instance of the ValueRetriever class. This method allows the user to
	 * specify the type of Payfone message to get, either the request of the response.	
	 * @param type The type of message to load into the retirever.
	 * @return An instance of a ValueRetriever class.
	 */
	private ValueRetriever getLogRetriever(String type) {
		ValueRetriever retriever = null;
		String response = null;
		String logger = null;
		String teid = getTeid();
		
		LoggerMapper mapper = new LoggerMapper();
		logger = mapper.getLogger();

		if (parser == null) {
			parser = new LogParser();
		}
		
		if (type.equalsIgnoreCase("response")) {
			response = parser.parseLog(logger, teid);
		} else if (type.equalsIgnoreCase("request")) {
			response = parser.parseLogRequest(logger, teid);
		}

		retriever = new ValueRetriever(response);
		return retriever;
	}

	/**
	 * A method to get the teid/ewSID from the current ews response.
	 * @return The teid/ewSID from the current response.
	 */
	private String getTeid() {
		String teid = null;
		String contentType = null;
		
		contentType = ApiDriver.getResp().contentType();
		
		if (contentType.contains("xml")) {
			teid = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//teid/text()");					
		} else if (contentType.contains("json")) {
			teid = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), "ewSID");
		} else {
			log.error("Could not retrieve the teid! ContentType " + contentType + " unknown!");
		}
		
		return teid;
	}
	
	/**
	 * A method to update the instance variable 'result'. The variable starts off being true and is
	 * only pdated to false. 
	 * @param status
	 */
	private void updateResult(boolean status) {
		if (status == false) {
			result = false;
		}
	}
	
	/**
	 * A method that validates the values from the Payfone response against the values from the 
	 * ews response if the ews response is JSON. The map contains the full path of the Payfone
	 * response keys on the left and the full path of the ews response keys on the right.
	 * @param map A listing of the corresponding keys for the Payfone response and the ews response.
	 * @return true if the values match, false otherwise.
	 */
	private boolean validateJsonResponseValues(Map<String, String> map) {
		boolean status = true;
		String responseKey = null;
		String logValue = null;
		
		Set<String> keys = map.keySet();
		Response response = ApiDriver.getResp();
		ValueRetriever retriever = getLogRetriever();
		
		for (String key : keys) {
			responseKey = map.get(key);
			logValue = retriever.getValue(key);
			updateResult(validate(key, logValue, ApiDriver.retrieveJsonValueString(response, responseKey)));			
		}
		status = result;
		result = true;
		return status;
	}
	
	/**
	 * A method that validates the values from the Payfone response against the values from the 
	 * ews response if the ews response is XML. The map contains the full path of the Payfone
	 * response keys on the left and the full path of the ews response keys on the right.
	 * @param map A listing of the corresponding keys for the Payfone response and the ews response.
	 * @return true if the values match, false otherwise.
	 */
	private boolean validateXmlResponseValues(Map<String, String> map) {
		boolean status = true;
		String responseKey = null;
		String logValue = null;
		
		Set<String> keys = map.keySet();
		Response response = ApiDriver.getResp();
		ValueRetriever retriever = getLogRetriever();
		
		for (String key : keys) {
			responseKey = map.get(key);
			logValue = retriever.getValue(key);
			updateResult(validate(key, logValue, ApiDriver.retrieveXMLvaluefromTag(response, responseKey + "/text()")));			
		}
		status = result;
		result = true;
		return status;
	}
	
	/**
	 * A method that gets a property value from the environment.properties file.
	 * @param property The name of the property without the environment part
	 * @return The property value.
	 */
	private String getProperty(String property) {
		String environment = Env.getProperty("payfoneEnvironment"); 
		
		
		return Env.getProperty(environment + property);
	}

}
