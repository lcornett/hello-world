/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.xml;

import lombok.Builder;
import lombok.Data;

/**
 * A POJO that represents the dataLookup element of the AuthentXML request message.
 * This class uses the lombok annotation which implements the getter and setter methods
 * for the private properties.
 * @author cornettl
 *
 */
@Data
@Builder
public class XmlDataLookup {
	private String consentCollectedDate;
	private String consentTransactionId;
	private String consentDescription;
}
