/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.xmlcompare;


import com.earlywarning.authentication.jsoncompare.StringComparator;
import com.earlywarning.authentication.xml.ResponseData;
import com.earlywarning.authentication.xml.XmlResponseDataLookup;

/**
 * A class that compares the data elements of an actual and expected
 * AuthentXMLRessponse message.
 * @author cornettl
 *
 */
class XmlDataComparator extends StringComparator {

	/**
	 * A method that compares the expected and the actual ResponseData 
	 * elements of AuthentXML response messages.
	 * @param expected The object to compare to.
	 * @param actual The object to compare.
	 * @return true if the element values are the same, false if not.
	 */
	public boolean compare(ResponseData expected, ResponseData actual) {
		String expectedValue = null;
		String actualValue = null;
		String[] keys = {"dataLookup", "ewDeviceId", "phoneNumber"};
		
		for (String key : keys) {
			switch (key) {
				case "dataLookup":
					XmlDataLookupComparator comparator = new XmlDataLookupComparator();
					XmlResponseDataLookup expectedLookup = expected.getDataLookup();
					XmlResponseDataLookup actualLookup = actual.getDataLookup();
					updateStatus(comparator.compare(expectedLookup, actualLookup));
					break;
				case "ewDeviceId":
					expectedValue = expected.getEwDeviceId();
					actualValue = actual.getEwDeviceId();
					updateStatus(compareString(key, expectedValue, actualValue));
					break;
				case "phoneNumber":
					expectedValue = expected.getPhoneNumber();
					actualValue = actual.getPhoneNumber();
					updateStatus(compareString(key, expectedValue, actualValue));
					break;				
			}
		}
		
		return status;
	}
}
