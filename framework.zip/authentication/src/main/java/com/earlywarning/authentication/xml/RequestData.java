/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.xml;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import lombok.Builder;
import lombok.Data;

/**
 * <p>A POJO that represents the data element of the Authentify XML request message.
 * This class utilizes the lombok Data and the lombok Builder annotations. The 
 * Data annotation provides the implementation of the getter and setter methods
 * for the private properties:</p><ul>
 * 	<li>phoneNumber</li>
 * 	<li>name</li>
 * 	<li>address</li>
 * 	<li>namedData</li></ul>
 * <p>The Builder annotation provides an all argument constructor and a &lt;class name&gt;
 * Builder class. For additional information about these annotations see the
 * <a href="{@docRoot}/com/earlywarning/authentication/xml/package-summary.html#tags">package-info</a> page.</p>
 *
 * @author cornettl
 *
 */
@Data
@Builder
public class RequestData {
	@JacksonXmlProperty(localName="xmlns:dat=\"http://xml.authentify.net/CommonDataSchema.xml\"", isAttribute=true)
	private final String xmlns = "";
	
	@JacksonXmlProperty(localName="dat:phoneNumber")
	private String phoneNumber;
	
	@JacksonXmlProperty(localName="dat:name")
	private Name name;
	
	@JacksonXmlProperty(localName="dat:address")
	private Address address;
	
	@JacksonXmlProperty(localName="dat:namedData")
	private NamedData namedData;
	
	private String legacyDeviceId;
	private String ewDeviceId;
	private XmlDataLookup dataLookup;
}

