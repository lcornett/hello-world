/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.common;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.earlywarning.authentication.startup.Env;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.path.json.exception.JsonPathException;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;

/**
 * This class handles all of the calls to RestAssured as well as
 * some utility methods that operate on the Response object
 * (e.g., getting element values).
 * @author cornettl
 *
 */
@Log4j2
public class ApiDriver {
	private String url;
    private static String contentType;
    private String body;
    private static boolean isPoll;
	private static Response Resp;
    private static int httpStatus;

    /**
     * The constructor for the class.
     * @param contentType The content type of the message
     * @param url The rest endpoint
     */
    public ApiDriver(String contentType, String url) {
        final String phost = "proxyHost";
        final String pport = "proxyPort";
    	String host = null;
        int port = -1;
        
    	this.contentType = contentType;
        this.url = url;
        if (Boolean.parseBoolean(Env.getProperty("useProxy"))) {
        	host = Env.getProperty(phost);
        	port = Integer.parseInt(Env.getProperty(pport));
        	RestAssured.proxy(host, port);
        }
        
    }

    /**
     * setter for the url property
     * @param url The endpoint for the rest service
     */
    public void setUrl(String url) {
        this.url = url;
    }
    
    /**
     * Resets RestAssured
     */
    public void reset(){
    	RestAssured.reset();
    }
    
    /**
     * Setter for the contentTYpe property
     * @param contentType The content type to use.
     */
    public static void setContentType(String contentType) {
        ApiDriver.contentType = contentType;
    }

    /**
     * Sets the body of the message. The body must be consistent with
     * the content type
     * @param body The body of the message
     */
    public void setBody(String body) {
        this.body = body;
    }

	 /**
	 * A method to perform an HTTP post operation to an endpoint. This assumed that the 
	 * contentType, url and body have already been instantiated. 
	 */
    public void post() {
    	boolean procede = false;
    	post(procede);
    }
    
    /**
     * A method to perform an http post operation to an endpoint. An argument
     * is provided so that the http status, if other than 200, can be captured
     * and compared to an expected status without failing the test step.
     * @param procede true causes the processing to continue if the http status is not 200
     */
    public void post(boolean procede){
    	
    	try {
			Resp =
					given().
				    contentType(contentType).body(body).
				    when().
				    post(url).andReturn();
			Resp.then().log().all();
			if(!isPoll()) {
				log.info(isPoll);
				log.info("The response to the request is \n" + Resp.prettyPrint());
			}
			httpStatus = Resp.then().extract().statusCode();
			
			if (httpStatus != 200) {
				String msg = "The post operation was not successful. The response from the server was " + Resp.then().extract().statusLine() + ".";
				log.info(msg);
			}
			
			if (!procede) {
				assertThat(Resp.then().extract().statusCode()).isEqualTo(200);
			}
			
			if (!isPoll()) {
		    	String contentType = null;
		    	String statusCode = null;

				contentType = Resp.contentType();
				
				if (contentType.contains("json")) {
					statusCode = retrieveJsonValueString(Resp, "statusCode");
					if (statusCode.equals("7000")) {
						setPoll(true);
						poll();
					} 

				} else if (contentType.contains("xml")) {
					statusCode = retrieveXMLvaluefromTag(Resp, "//statusCode/text()");
					if (statusCode.equals("7000")) {
						setPoll(true);
						xmlPoll();
					} 

				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
    }

    /**
     * A method to perform an HTTP get operation to an endpoint.
     * @return The response from the endpoint
     */
    public String get(){
        baseURI = url;
        Resp = given().contentType(contentType).get(url);
        return Resp.asString();
    }
    
    /**
     * A method to poll an endpoint for an asyncronous operation. The 
     * ewSID field is retrieved from the initial response and used to create
     * the poll JSON message to retrieve the final response for the initial request.
     * The statusCode of the response body is retrieved. As long as the statusCode
     * is 7000, the method keeps polling the endpoint for a final result.
     * @return The response from the request
     */
    public Response poll(){
        String replyToUrl = null; 
        JsonPath jsonPath = new JsonPath(Resp.getBody().asString());
        replyToUrl = jsonPath.getString("replyTo");
        String ewSID = jsonPath.getString("ewSID");
        String statcode;
        
        try {
			String poll_body = "{\"ewSID\":\"" + ewSID.trim() + "\",\"poll\":\"\"}";
			ApiDriver driver = new ApiDriver("application/json",replyToUrl);
			driver.setBody(poll_body);
			int i = 1;

			try {
				do{
					Thread.sleep(5000);
					log.info("The poll request being sent is: " + poll_body);
				    driver.post();
				    
				    Resp = ApiDriver.getResp();
				    jsonPath = new JsonPath(Resp.asString());
				    statcode = jsonPath.getString("statusCode");
				    log.info("The response to poll iteration " + i++ + " is " + Resp.prettyPrint());
				}while(statcode.equals("7000"));
				setPoll(false);
			} catch (InterruptedException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		} catch (JsonPathException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}

        log.info("The final message response received is: \n" + Resp.prettyPrint());
        return Resp;
    }
    
    /**
     *  A method to poll an endpoint for an asyncronous operation. The 
     * ewSID field is retrieved from the initial response and used to create
     * the poll XML message to retrieve the final response for the initial request.
     * The statusCode of the response body is retrieved. As long as the statusCode
     * is 7000, the method keeps polling the endpoint for a final result.
     * @return The response from the request
     */
    public Response xmlPoll() {
    	String statusCode = "";
    	String replyToUrl = retrieveXMLvaluefromTag(Resp, "//replyTo/text()");
    	String teid = retrieveXMLvaluefromTag(Resp, "//teid/text()");
    	ApiDriver driver = new ApiDriver("application/xml", replyToUrl);
    	int i = 1;
    	String pollBody = "<AuthentXML xmlns=\"http://xml.authentify.net/MessageSchema.xml\" version=\"1.0\">\r\n" + 
    			"<header>\r\n" + 
    			"<teid>" + teid + "</teid>\r\n" + 
    			"</header>\r\n" + 
    			"<body>\r\n" + 
    			"<poll/>\r\n" + 
    			"</body>\r\n" + 
    			"</AuthentXML>";
    	driver.setBody(pollBody);
    	
    	try {
			do {
				Thread.sleep(5000);
				log.info("The poll request being sent is: " + pollBody);
				driver.post();
				Resp = ApiDriver.getResp();
				
				statusCode = retrieveXMLvaluefromTag(Resp, "//statusCode/text()");
			    log.info("The response to poll iteration " + i++ + " is " + Resp.prettyPrint());

			} while (statusCode.equals("7000"));
			setPoll(false);
		} catch (InterruptedException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
     	 
    	log.info("The final message response received is: \n" + Resp.prettyPrint());
        return Resp;
    }

    /**
     * A method to get the latest response
     * @return The response from the latest operation.
     */
    public static Response getResp() {
        return Resp;
    }
    
    /**
     * Sets the value of the response. This should only be used in unit testing.
     * @param response A valid instance of RestAssured Response class
     */
    public static void setResp(Response response) {
    	Resp = response;
    }
    
    /**
     * A method to get the http status from the latest response.
     * @return the http status.
     */
    public static int getHttpStatus() {
    	return httpStatus;
    }

    /**
     * Gets the value of an element using a xPath expression.
     * @param response The response from the ReST request
     * @param expression The xPath expression to find the element to get the value of.
     * @return The value of the element
     */
    public static String retrieveXMLvaluefromTag(Response response, String expression){
        String fieldVal = "";
        String input = response.asString();
       
        try {
        	XPathExpression xp = XPathFactory.newInstance().newXPath().compile(expression);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder;
            builder = factory.newDocumentBuilder();
            InputSource is = new InputSource();
            is.setCharacterStream(new StringReader(input));
            Document document = builder.parse(is);
            
            fieldVal = xp.evaluate(document);

        }catch (ParserConfigurationException P){
			log.info(P.getMessage());
			log.debug(P.getMessage(), P);
        }catch (SAXException S){
			log.info(S.getMessage());
			log.debug(S.getMessage(), S);
        }catch (IOException I){
			log.info(I.getMessage());
			log.debug(I.getMessage(), I);
        } catch (Exception e) {
			log.info(e.getMessage());
			log.debug(e.getMessage(), e);
       }
        return fieldVal;
    }
    
    /**
     * A Method to get the value of a JSON element
     * @param resp The response of a RestAssured operation
     * @param keyName The name of the element to get the value of.
     * 				  This should be a JSONPath expression.
     * @return The value of the element.
     */
    public static String retrieveJsonValueString(Response resp, String keyName) {
    	String value = "";
    	Object obj = null;
    	
    	if (resp.asString().isEmpty()) {
    		String msg = "The repsonse body is empty.";
    		log.info(msg);
    		return value;
    	}
    	try {
    		obj = resp.then().extract().path(keyName);
    		
    		if (obj instanceof String) {
    			value =  (String) obj;
    		}
    		
    		if (obj instanceof Integer) {
    			int i = (Integer) obj;
    			value = Integer.toString(i);
    		}
    		
    		if (obj instanceof HashMap) {
    			value = obj.toString();
    		}
    		
    		if (obj instanceof ArrayList) {
    			value = obj.toString();
    		}
    	} catch (JsonPathException e) {
			log.info(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (Exception e) {
			log.info(e.getMessage());
			log.debug(e.getMessage(), e);
		}
    	return value;
    }
    
    /**
     * Looks for a named element in the XML response message.
     * @param response The response message to evaluate.
     * @param element The name of the element to find.
     * @return True if the element is found.
     */
    public static boolean hasXmlElement(Response response, String element) {
    	boolean result = false;
    	XMLStreamReader xml = null;
    	
    	Reader reader = new StringReader(response.asString());
    	try {
			xml = XMLInputFactory.newFactory().createXMLStreamReader(reader);
			
			while (xml.hasNext()) {
				if (xml.next() == XMLStreamConstants.START_ELEMENT && element.equals(xml.getLocalName())) {
					return true;
				}
			}
		} catch (XMLStreamException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (FactoryConfigurationError e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} finally {
			try {
				xml.close();
			} catch (XMLStreamException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		}
    	return result;
    }
    
    /**
     * Gets the Class.method of the caller.
     * @return The calling method name.
     */
    private String getCaller() {
    	StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
    	StackTraceElement element = stackTraceElements[4];
    	String method = element.getMethodName();
    	return method;
    }
    
    public boolean isPoll() {
		return isPoll;
	}

	public void setPoll(boolean isPoll) {
		this.isPoll = isPoll;
	}


}
