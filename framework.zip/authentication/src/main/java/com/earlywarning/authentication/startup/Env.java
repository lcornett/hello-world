/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.startup;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.earlywarning.authentication.utils.FileFinder;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class Env {
	private static Properties props = new Properties();
	private static String propsFile; 
	
	static {
		if (props.isEmpty()) {
			propsFile = FileFinder.find("environment.properties");
			try {	
				InputStream in = new FileInputStream(propsFile);
				props.load(in);
				in.close();
				setEnvironment();
			} catch (IOException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			} 
		}
	}
	 
	public static String getProperty(String key) {
		String value = null;
		
		try {
			value = props.getProperty(key);
		} catch (NullPointerException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		return value;
	}
	
	private static void setEnvironment() {
		String key = "env";
		String value = null;
		
		value = System.getProperty(key);
		
		if (value != null) {
			props.setProperty("environment", value);
		}
	}
			 
}