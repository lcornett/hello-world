/**
 * 
 */
/**
 * Package contains the classes required to read the SessionProcessor logs from the server and validate a response to a request against those logs.
 * @author cornettl
 *
 */
package com.earlywarning.authentication.applogs;