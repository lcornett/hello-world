/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.notificationserver;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Builder;
import lombok.Data;

/**
 * A POJO that represents the smsHeader element of an Authentify request message.
 * This class utilizes the lombok Data and the jackson JsonInclude annotations. The 
 * Data annotation provides an implementation of the getters and setters for the 
 * private properties:<ul>
 * 	<li>destination</li>
 * 	<li>sender</li>
 * 	<li>message</li></ul>
 *	For additional information about the annotations, please see the
 * <a href="{@docRoot}/com/earlywarning/authentication/notificationserver/package-summary.html#tags">
 * package-info</a> page.
 * @author cornettl
 *
 */
@Data
@Builder
@JsonInclude(Include.NON_EMPTY)
public class SmsHeader {
	private String destination;
	private String sender;
	private String message;
}
