/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.dbcp2.BasicDataSource;

import com.earlywarning.authentication.startup.Env;
import com.earlywarning.jirarestclient.utilities.Encryption;

import lombok.extern.log4j.Log4j2;

/**
 * A class that provides a pool of database connections to multiple databases. The 
 * maximum number of database connections to a database is 3. There is no limit
 * to the number of databases that can have simultaneous connections.
 * @author cornettl
 *
 */
@Log4j2
public class DataSource {
	private final String DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private final String DB_USER = getUser();
	private final String DB_PASSWORD = getPassword();
	private final int CONN_POOL_SIZE = 2;
	private final int MAX_CONN_POOL_SIZE = 3;
	private Encryption enc = new Encryption();
	
	static BasicDataSource bds; // = new BasicDataSource();
	
	/**
	 * A private constructor for the class.
	 * @param URL The URL of the database to connect to.
	 */
	private DataSource(String URL) {
		if (bds == null) {
			bds = new BasicDataSource();
		}
		bds.setDriverClassName(DRIVER);
		bds.setUrl(URL);
		bds.setUsername(enc.decrypt(DB_USER));
		bds.setPassword(enc.decrypt(DB_PASSWORD));
		bds.setInitialSize(CONN_POOL_SIZE);
		bds.setMaxTotal(MAX_CONN_POOL_SIZE);
	}
	
	/**
	 * An inner class of the DataSource class. This class does the work of configuring the 
	 * connection pool and connections of the outer class.
	 * @author cornettl
	 *
	 */
	private static class DataSourceHolder {
		private static Map<String, DataSource> sources;
		
		/**
		 * Gets an instance of the desired datasource.
		 * @param database The name of the database to connect to
		 * @return An instance of the DataSource class.
		 */
		private static DataSource getInstance(String database) {
			DataSource datasource = null;
			String URL = "jdbc:sqlserver://" + getHost() + ":" + getPort() + ";databasename=" + database;
			try {
				if (sources != null && sources.containsKey(database)) {
					return sources.get(database);
				} else {
					sources = new HashMap<String, DataSource>();
					datasource = new DataSource(URL);
					sources.put(database, datasource);
				}
			} catch (Exception e) {
				log.error(e.getMessage());;
				log.debug(e.getMessage(), e);
			}
			return datasource;
		}
		
	}
		
	/**
	 * A method for getting a DataSource object for the desired database.
	 * @param database The name of the database to connect to.
	 * @return An Instance of the desired DataSource class.
	 */
	public static DataSource getInstance(String database) {
				
		return DataSourceHolder.getInstance(database);
	}
	
	/**
	 * A method to get the BasicDataSource object from the DataSource. The BasicDataSource is
	 * the object that makes the connection. 
	 * @return The data sources BasicDataSource object
	 */
	public BasicDataSource getBds() {
		return bds;
	}
	
	void setBds(BasicDataSource bds) {
		this.bds = bds;
	}
	
	private String getUser() {
		return Env.getProperty("username");
	}
	
	private String getPassword() {
		return Env.getProperty("password");
	}
	
	private static String getHost() {
		return Env.getProperty("host");
	}
	
	private static String getPort() {
		return Env.getProperty("port");
	}
	
}
