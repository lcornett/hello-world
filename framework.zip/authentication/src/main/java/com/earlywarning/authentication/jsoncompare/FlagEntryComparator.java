/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.jsoncompare;

import java.util.ArrayList;

import com.earlywarning.authentication.common.Entry;

import lombok.extern.log4j.Log4j2;

/**
 * A class that compares the elements of two FlagEntry objects.
 * @author cornettl
 *
 */
@Log4j2
class FlagEntryComparator extends StringComparator {
	private boolean status = true;
	
	@Override
	protected void updateStatus(boolean value) {
		if (!value) {
			status = value;
		}
	}
	
	/**
	 * A method that compares each element of two Entry classes of the FlagEntry element
	 * @param actual The Entry being compared
	 * @param expected The Entry being compared to
	 * @return true if the objects are the same, false otherwise
	 */
	boolean compareEntry(Entry actual, Entry expected) {
		final String comparator = "data.dataLookup.flagEntries.";
		String actualValue = "";
		String expectedValue = "";
		String[] elements = {"value", "lineType", "status", "tenure", "velocity"};
		
		if ((null == actual) && (null == expected)) {
			return status;
		}
		
		
		try {
			for (String element : elements) {
				switch (element) {
					case "lineType":
						actualValue = actual.getLineType();
						expectedValue = expected.getLineType();
						updateStatus(compareString(comparator + element, actualValue, expectedValue));
						break;
					case "status":
						actualValue = actual.getStatus();
						expectedValue = expected.getStatus();
						updateStatus(compareString(comparator + element, actualValue, expectedValue));
						break;
					case "tenure":
						actualValue = actual.getTenure();
						expectedValue = expected.getTenure();
						updateStatus(compareString(comparator + element, actualValue, expectedValue));
						break;
					case "value":
						actualValue = actual.getValue();
						expectedValue = expected.getValue();
						updateStatus(compareString(comparator + element, actualValue, expectedValue));
						break;
					case "velocity":
						actualValue = actual.getVelocity();
						expectedValue = expected.getVelocity();
						updateStatus(compareString(comparator + element, actualValue, expectedValue));
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		return status;
	}
	
	boolean compareEntry(ArrayList<Entry> actual, ArrayList<Entry> expected) {
		String msg = "";
		try {
			if ((null == actual) && (null == expected)) {
				 msg = "The flagEntries in both responses are null!";
				log.info(msg);
				return true;
			}
			
			if (actual.size() != expected.size()) {
				msg = "The flagEntries in the responses are different sizes!";
				log.info(msg);
				return false;
			}
			
			for (int i = 0; i < actual.size(); i++) {
				Entry actualEntry = actual.get(i);
				Entry expectedEntry = expected.get(i);
				updateStatus(compareEntry(actualEntry, expectedEntry));
			} 

		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
				
		return status;
	}

}
