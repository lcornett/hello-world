/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.applogs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Arrays;

import com.earlywarning.authentication.utils.DateUtils;

import lombok.extern.log4j.Log4j2;

/**
 * A class that accesses the SessionProcessor logs and retrieves the Payfone
 * response to a query based on the teid (this is the EWS field ewSID)
 * @author cornettl
 *
 */
@Log4j2
public class LogParser {

	/**
	 * The method that parses the log and retrieves the Payfone response. The logPath
	 * parameter is a partial parameter and requires additional processing to access the log.
	 * @param logPath The partial UNC path to the SessionProcessor log.
	 * @param teid The transaction id to lok for in the log.
	 * @return A string, in JSON format, that represents the Payfone response.
	 */
	public String parseLog(String logPath, String teid) {
		File file = new File(getCurrentLog(logPath));
		String response = "{";
		BufferedReader br = null;
		
		try {
			String regex = "\\s*\"RequestId\"\\s:\\s*\"" + teid + "\",";
			String regex2 = "\\s*\"Status\"\\s:\\s*\\d+,"; 
			String regex3 = " \\}";
			
			br = new BufferedReader(new FileReader(file));
			String line;
			while ((line = br.readLine()) != null) {
				if (line.matches(regex)) {
					response += line.trim();
					line = br.readLine();
					if (line.matches(regex2)) {
						response += line.trim();
						line = br.readLine();
						do {
							response += line.trim();
						} while (!(line = br.readLine()).matches(regex3));
							
					} else {
						response = "{";
					}
				}
			}
			response +="}";
			log.info("The composed response is " + response);
		} catch (FileNotFoundException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (IOException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		}
		
		return response;		
	}
	
	public String parseLogRequest(String logPath, String teid) {
		File file = new File(getCurrentLog(logPath));
		String response = "{";
		BufferedReader br = null;
		
		try {
			String regex = "\\s*\"RequestId\"\\s:\\s*\"" + teid + "\",";
			String regex2 = "\\s*\"ApiClientId\"\\s:\\s*\"Auth_[A-Za-z0-9]+\","; 
			String regex3 = " \\s*\\}";
			
			br = new BufferedReader(new FileReader(file));
			String line;
			while ((line = br.readLine()) != null) {
				if (line.matches(regex)) {
					response += line.trim();
					line = br.readLine();
					if (line.matches(regex2)) {
						response += line.trim();
						line = br.readLine();
						do {
							response += line.trim();
						} while (!(line = br.readLine()).matches(regex3));
							
					} else {
						response = "{";
					}
					response += "}";
					return response;
				}
			}
		} catch (FileNotFoundException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (IOException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		}
		
		return response;		
	}
	
/**
 * A method that takes a partial log path and completes it. It does this by using
 * the base part of the directory that contains the logs (e.g., logs_since_<todays_date>), 
 * appends the date to the partial directory name and searches that directory for the file
 * that was last modified. After finding the file. the absolute path of the file is 
 * returned.
 * @param logPath The partial log path. (Obtained from the LoggerMapper)
 * @return The absolute path of the log.
 */
	private String getCurrentLog(String logPath) {
		String directory = "logs_since_";
		String formattedDate = null;
		
		File file = new File(logPath);
		String[] directories = file.list(new FilenameFilter() {
			@Override
			public boolean accept(File current, String name) {
				return new File(current, name).isDirectory();
			}
		});
		
		if (!Arrays.asList(directories).contains(directory)) {
			// get todays directory from the list of directories
			formattedDate = DateUtils.getFormattedToday("yyyy_MM_dd");
			directory += formattedDate;
		}
		
		for (String dir : directories) {
			if (dir.contains(directory)) {
				logPath += "\\" + dir;
			}
		}
		file = new File(logPath);
		File files[] = file.listFiles(); // {
		File lastModified = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModified.lastModified() < files[i].lastModified()) {
				lastModified = files[i];
			}
		}
		return lastModified.getAbsolutePath();
	}
	

}
