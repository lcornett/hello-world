/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.jirarestclient;

import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.entity.ContentType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

/**
 * <p>This class handles importing the Cucumber results JSON file into
 * Jira XRay.</p>
 * <p>There are three properties of this class that are set by the Spring 
 * Framework:</p><ul>
 * 	<li>host</li>
 * 	<li>endpoint</li>
 * 	<li>jsonLog</li></ul>
 * <p>The values for these properties are in the application.properties
 * file. The value for the endpoint property is the importEndpoint 
 * property in the file.
 * This class is instantiated by the Spring Framework using the RestClientConfig
 * class.
 * @author cornettl
 *
 */
@Slf4j
public class Importer {
	RestTemplateFactory factory;
	
	@Autowired
	HeaderCreator creator;
	
	@Value("${host}")
	String host;
	
	@Value("${importEndpoint}")
	String endpoint;
	
	@Value("${jsonLog}")
	String jsonLog;
	
	
	/**
	 * Constructor. 
	 * @param factory An instance of the RestTemplateFactory class.
	 */
	public Importer (RestTemplateFactory factory) {
		this.factory = factory;
	}


	/**
	 * A method that sends the Cucumber log to the endpoint to
	 * be imported into Jira XRay.
	 * @throws Exception
	 */
	public void execute() throws Exception {
		URI uri = null;
		org.springframework.http.HttpStatus statusCode = null;
		ResponseEntity<String> response = null;


		try {
			uri = new URI(host+endpoint);
			RestTemplate template = factory.getObject();
			response = template.exchange(uri, HttpMethod.POST, getEntity(), String.class);
			statusCode = response.getStatusCode();
			if (statusCode == HttpStatus.OK) {
				String msg = "The response from the server was " + statusCode +".";
				System.out.println(response.getBody());
				log.info(msg);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
			throw e;
		}
	}
	
	/**
	 * A method that creates the message by creating the necessary headers and
	 * joining the headers and the body to create the message or the HttpEntity.
	 * The HttpEntity is then sent to the endpoint for processing.
	 * @return The complete message as an instance of a HttpEntity class.
	 * @throws IOException
	 */
	private HttpEntity<String> getEntity() throws IOException {
		HttpEntity<String> entity = null;
		HttpHeaders headers = null;
		Map<String, String> headerMap = new HashMap<String, String>();
		String creds = null;
		String body = null;
		
		try {
			creds = creator.encodeCreds();

			headerMap.put("Content-Type", ContentType.APPLICATION_JSON.toString());
			headerMap.put("Authorization", creds);
			headers = creator.createHeaders(headerMap);
			body = getBody();
			entity = new HttpEntity<String>(body, headers);
			
			return entity;
		} catch (IOException e) {
			throw e;
		}
	}
	
	/**
	 * A method that reads the jsonLog as a byte array.
	 * 
	 * @return The json log as a string.
	 * @throws IOException
	 */
	private String getBody() throws IOException {
		String body = null;
		
		try {
			byte[] fileBytes = Files.readAllBytes(Paths.get("../"+jsonLog));
			body = new String(fileBytes);
			body = body.replaceAll("\n", "");
			body = body.replaceAll("\\s+", "");
			System.out.println(body);
		} catch (IOException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
			throw e;
		}
		
		return body;
	}
	
}
