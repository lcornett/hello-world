/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.jirarestclient;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * The Spring Framework configuration class. This class is used
 * in lieu of a configuration xml file.
 * @author cornettl
 *
 */
@Configuration
@PropertySource("application.properties")
public class RestClientConfig {
	/**
	 * A method that instantiates the Exporter class for the application context
	 * @return An instance of the Exporter class.
	 */
	@Bean
	public Exporter exporter() {
		return new Exporter(restTemplateFactory());
	}
	
	/**
	 * A moethod that instantiates the Importer class for the application context
	 * @return An instance of the Importer class
	 */
	@Bean
	public  Importer importer() {
		return new Importer(restTemplateFactory());
	}
	
	/**
	 * A method that instantiates the RestTemplateFactory class for the application context.
	 * @return An instance of the RestTemplateFactory class
	 */
	@Bean
	public RestTemplateFactory restTemplateFactory() {
		return new RestTemplateFactory();
	}
	
	/**
	 * A method that instantiates the HeaderCreator class for the application context.
	 * @return An instance of the HeaderCreator class
	 */
	@Bean
	public HeaderCreator headerCreator() {
		return new HeaderCreator();
	}
	
}
