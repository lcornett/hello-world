/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.jsoncompare;

import com.earlywarning.authentication.common.DataUser;

import lombok.extern.log4j.Log4j2;

/**
 * A class that compares the values of the properties of two instances of the User class.
 * @author cornettl
 *
 */
@Log4j2
class UserComparator extends StringComparator {
	
	/**
	 * The method that compares the values of the properties of two instances of the User class.
	 * @param actual The instance to compare.
	 * @param expected The instance to compare to.
	 * @return true if the values match, false otherwise.
	 */
	boolean compareUser(DataUser actual, DataUser expected) {
		final String comparator = "data.user.";
		String actualValue = "";
		String expectedValue = "";
		String[] elements = {"uuid"};
		
		
		try {
			
			if ((null == actual) && (null == expected)) {
				return status;
			}
			
			for (String element : elements) {
				switch (element) {
					case "uuid":
						actualValue = actual.getUuid();
						expectedValue = expected.getUuid();
						updateStatus(compareString(comparator + element, actualValue, expectedValue));
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		return status;
	}
}
