/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.stepdefs;

import cucumber.api.Scenario;
import cucumber.api.java8.En;
import lombok.extern.log4j.Log4j2;

/**
 * Contains hooks that called by all all scenarios.
 * @author cornettl
 *
 */
@Log4j2
public class EmptyStepDef implements En {

	@SuppressWarnings("unused")
	private static Scenario scenario;
	
	@SuppressWarnings("static-access")
	@cucumber.api.java.Before
	public void before(Scenario scenario) {
		this.scenario = scenario;
		String id = scenario.getId();
		String[] info = id.split(";");
		
	    String msg = "\n********************************************************************\n"
	    		+ "Starting a new Scenario\n"
	    		+ "Feature:          " + info[0] + "\n";
	    String name =  "Scenario:         " + info[1] + "\n";
	    
	    String last = "********************************************************************";
	    
	    switch (info.length) {
	    case 2:
	    	msg = msg + name + last;
	    	break;
	    case 4:
		    String extendedMsg = "Example Group:    " + info[2] + "\n"
					 + "Line:             " + info[3] + "\n";
		    name = "Scenario Outline: " + info[1] + "\n";

	    	msg = msg + name +extendedMsg + last;
	    	break;
	    }

	    
	    log.info(msg);
	}

	public EmptyStepDef() {
		
	}
}
