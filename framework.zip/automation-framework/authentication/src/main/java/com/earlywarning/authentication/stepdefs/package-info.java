/**
 * 
 */
/**
 * <p>This package is a collection of all the Cucumber Step Definition files relating to the 
 * following Jira projects:<ul>
 * 	<li>Authentication M &amp; E</li>
 * 	<li>Authentify Platform Test Repository</li>
 * </ul>
 * <p>The Step Definition files use Java 8 lambdas. Java 8 lambdas were chosen because they 
 * provide a cleaner look (no annotations), 
 * and provide an understandable and more concise approach to implementing step 
 * definitions. There is one drawback however. The traditional method of implementing 
 * step definitions used annotated methods. This made each step definition easier to 
 * find in the IDE. The lambdas are all implemented in the constructor of the class
 * so they are not displayed in the class outline in the IDE.</p>
 * <p>To facilitate locating the appropriate step definition the following approach
 * is used: 
 * <ul>
 * 	<li>The Step Definitions will be grouped into classes according to their functions.</li>
 * 	<li>Step definitions will be grouped by their cucumber keyword.</li>
 * 	<li>Step definitions will be described in the order they appear in the class in
 * 		that classes JavaDoc.</li>
 * </ul>
 * <h3>DataTable</h3>
 * <p>The DataTable for the step definitions takes the following format:<br></p><code>
 * 	| &lt;text&gt; | &lt;text&gt; | </code>
 * <p>There can be as many columns and rows as needed. However when creating a rest message name value 
 * pairs are used.</p> 
 *  
 * @author cornettl
 *
 */
package com.earlywarning.authentication.stepdefs;