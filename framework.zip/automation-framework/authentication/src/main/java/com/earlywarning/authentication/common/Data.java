/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * A POJO to represent the data element of the Authentify json request.
 * This class utilizes the jackson JsonInclude annotation. 
 * The Data annotation implements the setters and getters for the private
 * properties:<ul>
 * 	<li>phoneNumber</li>
 * 	<li>ewdeviceId</li>
 * 	<li>legacyDeviceId</li>
 * 	<li>returnlegacydeviceid</li>
 * 	<li>dataLookup</li>
 * 	<li>namedData</li>
 * 	<li>user</li>
 * 	<li>cardInfo</li></ul>
 * See the 
 * <a href="{@docRoot}/com/earlywarning/authentication/common/package-summary.html#tags">
 * package-info</a> for the annotation details.
 * @author cornettl
 *
 */
@JsonInclude(Include.NON_EMPTY)
public class Data {
	private String phoneNumber;
	private String ewDeviceId;
	private String legacyDeviceId;
	private DataLookup dataLookup;
	private NamedData namedData;
	private DataUser user;
	private CardInfo cardInfo;	
	private String consentProvided;
	
	public String getConsentProvided() {
		return consentProvided;
	}
	public void setConsentProvided(String consentProvided) {
		this.consentProvided = consentProvided;
	}
	public NamedData getNamedData() {
		return namedData;
	}
	public void setNamedData(NamedData namedData) {
		this.namedData = namedData;
	}
	public String getEwDeviceId() {
		return ewDeviceId;
	}
	public void setEwDeviceId(String ewDeviceId) {
		this.ewDeviceId = ewDeviceId;
	}
	
	public String getLegacyDeviceId() {
		return legacyDeviceId;
	}
	public void setLegacyDeviceId(String legacyDeviceId) {
		this.legacyDeviceId = legacyDeviceId;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public DataLookup getDataLookup() {
		return dataLookup;
	}
	public void setDataLookup(DataLookup dataLookup) {
		this.dataLookup = dataLookup;
	}
	
	public void setUser(DataUser user) {
		this.user = user;
	}
	
	public DataUser getUser() {
		return user;
	}
	
	public void setCardInfo(CardInfo cardInfo) {
		this.cardInfo = cardInfo;
	}
	
	public CardInfo getCardInfo() {
		return cardInfo;
	}
	

}
