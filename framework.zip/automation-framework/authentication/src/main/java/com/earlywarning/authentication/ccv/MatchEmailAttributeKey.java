/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.ccv;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Builder;
import lombok.Data;

/**
 * A POJO that represents the MatchEmailAttributeKey element of the 
 * Authentify Call Center Verification request message.
 * This class utilizes the lombok Data and lombok Builder annotations.
 * The Data annotation provides the getter and setter implementations
 * for  the private property:<ul><li>emailAddress</li></ul>
 * The Builder annotation implements an all argument constructor, the
 * builder method and a MatchEmailAttributeKeyBuilder class which is 
 * returned by the builder method. For additional information about
 * these annotations may be found on the
 * <a href="{@docRoot}/com/earlywarning/authentication/ccv/package-summary.html#tags">
 * package-info</a> page.
 
 * @author cornettl
 *
 */
@JsonInclude(Include.NON_NULL)
@Data
@Builder
public class MatchEmailAttributeKey {
	String emailAddress;
}
