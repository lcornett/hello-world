/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.jsoncompare;

import java.io.IOException;

import com.earlywarning.authentication.common.Response;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

/**
 * A class that compares the elements of a JSON object. This class was designed to
 * compare the Response messages of two similar requests. To this end, the only 
 * public method implemented is the compareResponse method.
 * @author cornettl
 *
 */
@Log4j2
public class JsonComparator {
	
	/**
	 * Compares two JSON response messages by converting the string into a
	 * Response object then comparing the properties of that object.
	 * @param actual The response to be compared.
	 * @param expected The response to be compared to.
	 * @return True if the tested elements are the same, false otherwise.
	 */
	public static boolean compareResponse(String actual, String expected) {
		boolean result = false;
		ObjectMapper mapper = new ObjectMapper();
		ResponseComparator rc = new ResponseComparator();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		Response actualResponse = null;
		Response expectedResponse = null;
		
		try {
			actualResponse = mapper.readValue(actual, Response.class);
			expectedResponse = mapper.readValue(expected, Response.class);
			result = rc.compareResponse(actualResponse, expectedResponse);
			
		} catch (JsonParseException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (JsonMappingException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (IOException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		return result;		
	}
}	
	
	

