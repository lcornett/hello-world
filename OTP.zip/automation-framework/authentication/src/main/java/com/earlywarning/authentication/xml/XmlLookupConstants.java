/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.xml;

/**
 * This interface provides the xPath values for the elements in an Authentify
 * XML response message.
 * @author cornettl
 *
 */
public interface XmlLookupConstants {
	// Response fields
	public String AREA_CODE = "//dataItem[@name='areaCode']/text()";
	public String BUSINESS_INDICATOR = "//dataItem[@name='businessIndicator']/text()";
	public String BUSINESS_NAME_MATCH = "//businessName/@match";
	public String COUNTRY_CODE = "//dataItem[@name='countryCode']/text()";
	public String CURRENT_PHONE_TYPE = "//dataItem[@name='currentPhoneType']/text()";
	public String EXCHANGE = "//dataItem[@name='exchange']/text()";
	public String EXCHANGE_TYPE_CODE = "//dataItem[@name='exchangeTypeCode']/text()";
	public String FIRST_NAME_MATCH = "//firstName/@match";
	public String GEOLOCATION_LATITUDE ="//dataItem[@name='geolocationLatitude']/text()";
	public String GEOLOCATION_LONGITUDE = "//dataItem[@name='geolocationLongitude']/text()";
	public String GEOLOCATION_NAME = "//dataItem[@name='geolocationName']/text()";
	public String GEOLOCATION_POSTAL_CODE = "//dataItem[@name='geolocationPostalCode']/text()";
	public String GEOLOCATION_PROVINCE_NAME = "//dataItem[@name='geolocationProvinceName']/text()";
	public String IS_LANDLINE = "//dataItem[@name='isLandline']/text()";
	public String LANDLINE_INDICATOR = "//landlineIndicator/text()";
	public String LAST_NAME_MATCH = "//lastName/@match";
	public String MESSAGE_TEXT = "//dataItem[@name='messageText']/text()";
	public String NUMBER = "//dataItem[@name='number']/text()";
	public String NUMBER_PORTABILITY = "//dataItem[@name='numberPortability']/text()";
	public String ORIGINAL_CARRIER = "//dataItem[@name='originalCarrier']/text()";
	public String ORIGINAL_PHONE_TYPE = "//dataItem[@name='originalPhoneType']/text()";
	public String PHONE_TO_POSTAL_DISTANCE = "//dataItem[@name='phoneToPostalDistance']/text()";
	public String POPULATION_DENSITY = "//dataItem[@name='populationDensity']/text()";
	public String PORTED_CARRIER = "//dataItem[@name='portedCarrier']/text()";
	public String POSTAL_CODE_MATCH = "//postalCode/@match";
	public String REGISTERED_CARRIER_NAME = "//dataItem[@name='registeredCarrierName']/text()";
	public String STATUS_CODE = "//statusCode/text()";
	public String STREET_ADDRESS_MATCH = "//streetAddress/@match";
	public String ZIP_EXCHANGE_DISTANCE = "//dataItem[@name='zipExchangeDistance']/text()";
	
}

