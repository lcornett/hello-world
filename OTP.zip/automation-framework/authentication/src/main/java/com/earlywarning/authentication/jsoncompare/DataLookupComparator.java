/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.jsoncompare;

import java.util.ArrayList;

import com.earlywarning.authentication.common.Address;
import com.earlywarning.authentication.common.DataLookup;
import com.earlywarning.authentication.common.Entry;
import com.earlywarning.authentication.common.Event;
import com.earlywarning.authentication.common.Match;
import com.earlywarning.authentication.common.Name;
import com.earlywarning.authentication.common.Vfp;

import lombok.extern.log4j.Log4j2;

/**
 * A class that compares the values of two instances of the DataLookup class.
 * @author cornettl
 *
 */
@Log4j2
class DataLookupComparator extends StringComparator {
	
	/**
	 * The method that compares the values of two instances of the DataLookup class.
	 * @param actual The instance being compared.
	 * @param expected The instance being compared to.
	 * @return true if the values match, false otherwise.
	 */
	boolean compareDataLookup(DataLookup actual, DataLookup expected) {
		final String comparator = "data.dataLookup.";
		String actualValue = "";
		String expectedValue = "";
		String[] fields = {"finalTargetUrl", "mobileNetworkOperator", "deviceIp", "deviceType", "consentCollectedDate", "consentTransactionId",
				"consentDescription", "lastVerificationDate", "vfp", "enterprisePhoneNumber", "callArrivalTime", "email", 
				"name", "address", "flagEntries", "mobileIdentityCreated", "mobileOperatorName", "lastChangeEvents", "statusIndex",
				"matchResults", "ownershipStatus"};
		
		try {
			if ((null == actual) && (null == expected)) {
				return status;
			}
			
			for (String field : fields) {
				switch (field) {
					case "address":
						AddressComparator ac = new AddressComparator();
						Address actualAddress = actual.getAddress();
						Address expectedAddress = expected.getAddress();
						updateStatus(ac.compareAddress(actualAddress, expectedAddress));
						break;
					case "callArrivalTime":
						actualValue = actual.getCallArrivalTime();
						expectedValue = expected.getCallArrivalTime();
						updateStatus(compareString(comparator + field, actualValue, expectedValue));
						break;
					case "consentCollectedDate":
						actualValue = actual.getConsentCollectedDate();
						expectedValue = expected.getConsentCollectedDate();
						updateStatus(compareString(comparator + field, actualValue, expectedValue));
						break;
					case "consentDescription":
						actualValue = actual.getConsentDescription();
						expectedValue = expected.getConsentDescription();
						updateStatus(compareString(comparator + field, actualValue, expectedValue));
						break;
					case "consentTransactionId":
						actualValue = actual.getConsentTransactionId();
						expectedValue = expected.getConsentTransactionId();
						updateStatus(compareString(comparator + field, actualValue, expectedValue));
						break;
					case "deviceIp":
						actualValue = actual.getDeviceIp();
						expectedValue = expected.getDeviceIp();
						updateStatus(compareString(comparator + field, actualValue, expectedValue));
						break;
					case "deviceType":
						actualValue = actual.getDeviceType();
						expectedValue = expected.getDeviceType();
						compareString(comparator + field, actualValue, expectedValue);
						updateStatus(compareString(comparator + field, actualValue, expectedValue));
						break;						
					case "email":
						actualValue = actual.getEmail();
						expectedValue = expected.getEmail();
						updateStatus(compareString(comparator + field, actualValue, expectedValue));
						break;
					case "enterprisePhoneNumber":
						actualValue = actual.getEnterprisePhoneNumber();
						expectedValue = expected.getEnterprisePhoneNumber();
						updateStatus(compareString(comparator + field, actualValue, expectedValue));
						break;
					case "finalTargetUrl":
						actualValue = actual.getFinalTargetUrl().getValue();
						expectedValue = expected.getFinalTargetUrl().getValue();
						updateStatus(compareString(comparator + field, actualValue, expectedValue));
						break;
					case "flagEntries":
						FlagEntryComparator fec = new FlagEntryComparator();
						ArrayList<Entry> actualEntries = actual.getFlagEntries();
						ArrayList<Entry> expectedEntries = expected.getFlagEntries();
						updateStatus(fec.compareEntry(actualEntries, expectedEntries));
						break;
					case "lastChangeEvents":
						EventsComparator ec = new EventsComparator();
						ArrayList<Event> actualEvents = actual.getLastChangeEvents();
						ArrayList<Event> expectedEvents = expected.getLastChangeEvents();
						updateStatus(ec.compareEventsList(actualEvents, expectedEvents));
						break;
					case "lastVerificationDate":
						actualValue = actual.getLastVerificationDate();
						expectedValue = expected.getLastVerificationDate();
						updateStatus(compareString(comparator + field, actualValue, expectedValue));
						break;
					case "matchResults":
						MatchComparator mc = new MatchComparator();
						ArrayList<Match> actualMatchResults = actual.getMatchResults();
						ArrayList<Match> expectedMatchResults = expected.getMatchResults();
						updateStatus(mc.compareMatches(actualMatchResults, expectedMatchResults));
						break;
					case "mobileIdentityCreated":
						actualValue = actual.getMobileIdentityCreated();
						expectedValue = expected.getMobileIdentityCreated();
						updateStatus(compareString(comparator + field, actualValue, expectedValue));
						break;
					case "mobileNetworkOperator":
						actualValue = actual.getMobileNetworkOperator();
						expectedValue = expected.getMobileNetworkOperator();
						updateStatus(compareString(comparator + field, actualValue, expectedValue));
						break;
					case "mobileOperatorName":
						actualValue = actual.getMobileOperatorName();
						expectedValue = expected.getMobileOperatorName();
						updateStatus(compareString(comparator + field, actualValue, expectedValue));
						break;
					case "name":
						NameComparator nc = new NameComparator();
						Name actualName = actual.getName();
						Name expectedName = expected.getName();
						updateStatus(nc.compareName(actualName, expectedName));
						break;
					case "ownershipStatus":
						actualValue = actual.getOwnershipStatus();
						expectedValue = expected.getOwnershipStatus();
						updateStatus(compareString(comparator + field, actualValue, expectedValue));
						break;						
					case "statusIndex":
						actualValue = actual.getStatusIndex();
						expectedValue = expected.getStatusIndex();
						updateStatus(compareString(comparator + field, actualValue, expectedValue));
						break;
					case "vfp":
						VfpComparator vc = new VfpComparator();
						Vfp actualVfp = actual.getVfp();
						Vfp expectedVfp = expected.getVfp();
						updateStatus(vc.compareVfp(actualVfp, expectedVfp));					
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}

		return status;
	}

}
