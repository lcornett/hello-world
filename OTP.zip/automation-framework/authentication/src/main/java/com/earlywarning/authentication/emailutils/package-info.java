/**
 * 
 */
/**
 * Classes for processing email messages.
 * @author cornettl
 *
 */
package com.earlywarning.authentication.emailutils;