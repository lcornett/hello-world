/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.xml;

import java.util.Map;
import java.util.Set;

import com.earlywarning.authentication.xml.AuthentXML.AuthentXMLBuilder;
import com.earlywarning.authentication.xml.Header.HeaderBuilder;
import com.earlywarning.authentication.xml.Name.NameBuilder;
import com.earlywarning.authentication.xml.NamedData.NamedDataBuilder;
import com.earlywarning.authentication.common.StoredParams;
import com.earlywarning.authentication.startup.Env;
import com.earlywarning.authentication.xml.Address.AddressBuilder;
import com.earlywarning.authentication.xml.RequestData.RequestDataBuilder;


import lombok.extern.log4j.Log4j2;

/**
 * <p>A class to create an XML version of the Authentify request message. Currently the 
 * Authentify request message can be XML or JSON. XML is the legacy version of the 
 * message and the move to JSON is being made.</p> 
 * <p>As initially developed, this class is used to test those services for which a JSON
 * message has not been developed yet. As a result, not all of the message elements have 
 * been implemented.
 * @author cornettl
 *
 */
@Log4j2
public class XmlRequestCreator {
	private static AuthentXMLBuilder requestBuilder = AuthentXML.builder();
	private static HeaderBuilder headerBuilder = null;
	private static NameBuilder nameBuilder = null;
	private static NamedDataBuilder ndBuilder = null;
	private static AddressBuilder addressBuilder = null;
	private static RequestDataBuilder dataBuilder = null;
	
	/**
	 * Creates the XML request from a Map&lt;String, String&gt; that is passed in a s an argument.
	 * If an element that comprises the header element is not passed in as a mewmber of the 
	 * map parameter, a default header is provided. The default header consists of the following
	 * names and values:<ul>
	 * 	<li>tsoid = 'Authentify_Sales'</li>
	 * 	<li>application = 'fullDataLookup'</li>
	 * 	<li>asid = 'QA_Test'</li>
	 * 	<li>licenseKey - The license key is retrieved from the environment.properties file.</li></ul>
	 * The elements that are not included in the map parameter will not be included in the request.
	 * 
	 * @param map A map of the element names and their values
	 * @return An instance of the AuthentXML class
	 */
	public static AuthentXML createRequest(Map<String, String> map) {
		Set<String> keys = map.keySet();
		AuthentXML message = null;
		XmlRequest request = new XmlRequest();
		Body body = new Body();
		Name name = null;
		Address address = null;
		RequestData data = null;
		Header header = null;
		NamedData namedData = null;
		
		try {
			keys.forEach((key) -> {;
				switch (key) {
					case "account":	
						if (null == headerBuilder) {
							headerBuilder = Header.builder();
						}
						headerBuilder.account(map.get(key));
						break;
					case "application":
						if (null == headerBuilder) {
							headerBuilder = Header.builder();
						}
						headerBuilder.application(map.get(key));
						break;
					case "asid":
						if (null == headerBuilder) {
							headerBuilder = Header.builder();
						}
						headerBuilder.asid(map.get(key));
						break;
					case "firstName":
						if (nameBuilder == null) {
							nameBuilder = Name.builder();
						}
						nameBuilder.firstName(map.get(key));
						break;
					case "lastName":
						if (nameBuilder == null) {
							nameBuilder = Name.builder();
						}
						nameBuilder.lastName(map.get(key));
						break;
					case "licenseKey":
						if (null == headerBuilder) {
							headerBuilder = Header.builder();
						}
						headerBuilder.licenseKey(map.get(key));
						break;
					case "messageText":
						if (null == ndBuilder) {
							ndBuilder = NamedData.builder();
						}
						ndBuilder.messageText(map.get(key));
						break;
					case "phoneNumber":
						String regex = "getDemoNumber";
						String number = null;
						if (map.get(key).matches(regex)) {
							number = getDemoPhone();
						} else {
							number = map.get(key);
						}
						if (dataBuilder == null) {
							dataBuilder = RequestData.builder();
						}
						dataBuilder.phoneNumber(number);
						break;
					case "postalCode":
						if (addressBuilder == null) {
							addressBuilder = Address.builder();
						}
						addressBuilder.postalCode(map.get(key));
						break;
					case "streetAddress":
						if (addressBuilder == null) {
							addressBuilder = Address.builder();
						}
						addressBuilder.streetAddress(map.get(key));
						break;	
					case "tsoid":
						if (null == headerBuilder) {
							headerBuilder = Header.builder();
						}
						headerBuilder.tsoid(map.get(key));
						break;
					default:
						String msg = "The tag " + key + " is unknown!";
						log.info(msg);
				}
			});
			
			if (null == headerBuilder) {
				header = getDefaultHeader();
			} else {
				header = headerBuilder.build();
				if (header.getLicenseKey() == null) {
					header.setLicenseKey(getLicenseKey());
				}
			}
			
			if (null != nameBuilder) {
				name = nameBuilder.build();
				dataBuilder.name(name);
			}
			if (null != addressBuilder) {
				address = addressBuilder.build();
				dataBuilder.address(address);
			}
			if (null != ndBuilder)	{
				namedData = ndBuilder.build();
				dataBuilder.namedData(namedData);
			}

			data = dataBuilder.build();
			
			request.setData(data);
			body.setRequest(request);
			
			requestBuilder.header(header);
			requestBuilder.body(body);
			message = requestBuilder.build();
			return message;
		} finally {
			nameBuilder = null;
			addressBuilder = null;
			dataBuilder = null;
			ndBuilder = null;
			requestBuilder = AuthentXML.builder();
		}
	}
	
	/**
	 * A method that returns a header element with default data.
	 * @return a header element with default data
	 */
	private static Header getDefaultHeader() {
		Header header = null;
		HeaderBuilder headerBuilder = Header.builder();
		
		headerBuilder.tsoid("Authentify_Sales");
		headerBuilder.application("FullDataLookup");
		headerBuilder.asid("QA_Test");
		headerBuilder.licenseKey(getLicenseKey());
		header = headerBuilder.build();
		return header;
	}
	
	/**
	 * A method to get the license key from the environment.properties file
	 * for the environment.
	 * @return The license key
	 */
	private static String getLicenseKey() {
		String enviromnent = Env.getProperty("environment");
		String licenseKey = Env.getProperty(enviromnent + "License");
		
		return licenseKey;
	}
	
	/**
	 * A method that gets the phone number for the Authentify Demo
	 * feature from the environment.properties file. In order to make 
	 * this work, I also have to store the number so I can get its parts
	 * later. If the number is a 10 digit number it's OK. IF it is an 11
	 * digit number, the last 10 digits are saved. Anything else, a message
	 * is written to the log.
	 * @return The phone number to use.
	 */
	private static String getDemoPhone() {	
		String env = Env.getProperty("environment");
		String demoNumber = Env.getProperty(env + "DemoPhone");
		
		if (demoNumber.length() == 10) {
			StoredParams.store("demoNumber", demoNumber);
		} else if (demoNumber.length() == 11) {
			StoredParams.store("demoNumber", demoNumber.substring(1));
		} else {
			String msg = "I don't know what to do with the Authentify_Demo phoneNumber " + demoNumber + ".";
			log.info(msg);
		}
		return demoNumber;
	}
}

