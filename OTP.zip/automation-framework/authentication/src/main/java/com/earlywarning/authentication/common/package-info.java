/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
/**
 * <p id="package_description">This package contains all of the classes required to create and validate the 
 * Authentify JSON messages. Most of the classes are POJOs that utilize the lombok
 * Data annotation as well as the JsonInclude(Include.NON_EMPTY) annotation.</p>
 * 
 * <p>The tables below illustrate the JSON request message layout.</P>
 * <h2>Request</h2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>JSON Element/Node</th><th>Type</th><th>Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>clientId</td><td>string</td><td align="center">Y</td><td></td><td>In the test environment, the value is usually 'Authentify_Test</td></tr>
 * 	<tr><td>license</td><td>string</td><td align="center">Y</td><td></td><td>Required to user the service</td></tr>
 * 	<tr><td>app</td><td>string</td><td align="center">Y</td><td>mobileLookupProd</td><td>Identifies what the message is for.</td></tr>
 * 	<tr><td>clientAcctId</td><td>string</td><td align="center">N</td><td></td><td>In the test environment, this value is usually QA_Test</td></tr>
 * 	<tr><td>clientContext</td><td>string</td><td align="center">N</td><td></td><td>Int the test environment, teh value is usually 'Authentify_QA_Test'</td></tr>
 * 	<tr><td>event</td><td>string</td><td align="center">Y</td><td>status<br>verifyIdentity<br>verifyPhone<br>create<br>setPassword<br>verifyPassword<br>remove<br>getIntelligence<br>mobileAuthStart<br>mobileAuthFinish</td><td>Defines how the request is processed.</td></tr>
 * 	<tr><td>data</td><td>node</td><td align="center">Y</td><td></td><td>The data used in the request.</td></tr>
 * 	<tr><td>user</td><td>node</td><td align="center">N</td><td></td><td>Used in the Responsive Web feature.</td></tr>		
 * </table>
 * 
 * <h2>Data</h2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>JSON Element/Node</th><th>Type</th><th>Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>ewDeviceId</td><td>string</td><td align="center">C</td><td></td><td></td></tr>
 * 	<tr><td>phoneNumber</td><td>string</td><td align="center">C</td><td></td><td></td></tr>
 * 	<tr><td>legacyDeviceId</td><td>string</td><td align="center">C</td><td></td><td></td></tr>
 * 	<tr><td>returnLegacyDeviceId</td><td>string</td><td align="center">C</td><td>true<br>false</td><td></td></tr>
 * 	<tr><td>dataLookup</td><td>node</td><td align="center">C</td><td></td><td></td></tr>
 * 	<tr><td>user</td><td>node</td><td align="center">C</td><td></td><td>This is implemented in the DataUser class</td></tr>
 * 	<tr><td>cardInfo</td><td>node</td><td align="center">C</td><td></td><td></td></tr> 	
 * </table>
 * 
 * <h2>DataLookup</h2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>JSON Element/Node</th><th>Type</th><th>Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>finalTargetUrl</td><td>String</td><td align="center">N</td><td></td><td></td></tr>
 * 	<tr><td>mobileNetworkOperator</td><td>String</td><td align="center">N</td><td></td><td></td></tr>
 * 	<tr><td>deviceIp</td><td>String</td><td align="center">N</td><td></td><td></td></tr>
 * 	<tr><td>consentCollectedDate</td><td>string</td><td align="center">C</td><td></td><td></td></tr>
 * 	<tr><td>consentTransactionId</td><td>string</td><td align="center">C</td><td></td><td></td></tr>
 * 	<tr><td>consentDescription</td><td>string</td><td align="center">C</td><td></td><td></td></tr>
 * 	<tr><td>lastVerificationDate</td><td>String</td><td align="center">N</td><td></td><td></td></tr>
 * 	<tr><td>vfp</td><td>node</td><td align="center">N</td><td></td><td></td></tr>
 *  <tr><td>enterprisePhoneNumber</td><td>String</td><td align="center">N</td><td></td><td></td></tr>
 *  <tr><td>callArrivalTime</td><td>String</td><td align="center">C</td><td></td><td></td></tr>
 *  <tr><td>email</td><td>string</td><td align="center">C</td><td></td><td></td></tr>
 *  <tr><td>name</td><td>node</td><td align="center">C</td><td></td><td></td></tr>
 *  <tr><td>address</td><td>node</td><td align="center">C</td><td></td><td></td></tr>
 * </table>
 * 
 <h2>Vfp</H2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>JSON Element/Node</th><th>Type</th><th>Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>value</td><td>string</td><td align="center">Y</td><td></td><td></td></tr> 
 * </table>
 * 
 * <h2>Name</h2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>JSON Element/Node</th><th>Type</th><th>Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>firstName</td><td>string</td><td align="center">Y</td><td></td><td></td></tr> 
 * 	<tr><td>middleName</td><td>string</td><td align="center">Y</td><td></td><td></td></tr> 
 * 	<tr><td>lastName</td><td>string</td><td align="center">Y</td><td></td><td></td></tr> 
 * </table> 
 * 
 * <h2>Address</H2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>JSON Element/Node</th><th>Type</th><th>Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>streetAddress</td><td>string</td><td align="center">Y</td><td></td><td></td></tr> 
 * 	<tr><td>ExtendedAddress</td><td>string</td><td align="center">Y</td><td></td><td></td></tr> 
 * 	<tr><td>city</td><td>string</td><td align="center">Y</td><td></td><td></td></tr> 
 * 	<tr><td>postalCode</td><td>string</td><td align="center">Y</td><td></td><td></td></tr> 
 * 	<tr><td>region</td><td>string</td><td align="center">Y</td><td></td><td></td></tr> 
 * 	<tr><td>country</td><td>string</td><td align="center">Y</td><td></td><td></td></tr> 
 * </table>
 * 
 * <h2>User (DataUser.class)</h2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>JSON Element/Node</th><th>Type</th><th>Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>uuid</td><td>string</td><td align="center">Y</td><td></td><td></td></tr>
 * </table>
 * 
 * <h2>CardInfo</h2> 
 *  <table style="width:350" border="1px" summary="">
 * 	<tr><th>JSON Element/Node</th><th>Type</th><th>Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>cvv</td><td>string</td><td align="center">Y</td><td></td><td></td></tr> 
 * </table>

 * 
 * <h3 id="tags">Annotations</h3>
 * <p>The lombok Data annotation provides the implementation for the setters and getters as well as the 
 * 'toString(), hashCode() and equals() methods without having to code these boilerplate methods. Because
 * these methods are provided by lombok and not specifically coded, the Java Doc for the class does not include 
 * the lombok provided methods.</p>
 * <p>The JsonInclude annotation is provided by the jackson-databind jar. The JsonInclude annotation
 * is used typically to tell the serializer what fields to include and not include. Typically NON_NULL or
 * NON_EMPTY fields are included.
 * 	 
 * @author cornettl
 *
 */
package com.earlywarning.authentication.common;