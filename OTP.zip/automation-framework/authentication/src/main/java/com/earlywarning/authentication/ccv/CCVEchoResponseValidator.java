/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.ccv;

import java.util.Map;
import java.util.Set;

import com.earlywarning.authentication.common.ApiDriver;

import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2; 

/**
 * A class that validates the CCV Echo response by comparing the actual
 * element values with the expected element values.
 * @author cornettl
 *
 */
@Log4j2
public class CCVEchoResponseValidator {
	private static boolean result = true;
	
	/**
	 * A method that validates the response message by comparing the actual message
	 * element values with the expected message element values.
	 * @param response The response from the HTTP Post operation.
	 * @param map A map of the element names with their expected values.
	 * @return true if the response elements match the expected values.
	 */
	public static boolean validateResponse(Response response, Map<String, String> map) {
		Set<String> keys = map.keySet();
		String jsonPath = "";
		
		for (String key : keys) {
			switch (key) {
				case "AdditionalInfo":	
					jsonPath = "AdditionalInformation";
					validate(response, jsonPath, map.get(key));
					break;
				case "Description":
					jsonPath = "Description";
					validate(response, jsonPath, map.get(key));
					break;					
				case "message":
					jsonPath = "Response.Message";
					validate(response, jsonPath, map.get(key));
					break;
				case "status":
					jsonPath = "Status";
					validate(response, jsonPath, map.get(key));
					break;
				case "version":
					jsonPath = "Response.Version";
					validate(response, jsonPath, map.get(key));
					break;
				default:
					String msg = "Unknown element: " + key;
					log.error(msg);			
			}
		}
		boolean status = result;
		result = true;
		return status;
	}
	
	/**
	 * The method that actually performs the comparison between the actual and the 
	 * expected element value. The actual value is retrieved from the response before
	 * comparison. After the comparison the instance variable result is updated.
	 * @param response The response from the RestService call.
	 * @param path The jsonPath of the element to get the value of.
	 * @param expected The expected value of the element.
	 */
	private static void validate(Response response, String path, String expected) {
		String actual = "";
		
		actual = ApiDriver.retrieveJsonValueString(response, path);
		
		if (!actual.equals(expected)) {
			updateResult(false);
		}
	}
	
	/**
	 * Updates the result instance variable. If the parameter of this
	 * method is false then the result valiable is set to false, otherwise
	 * nothing happens.
	 * @param value The result of the last comparison
	 */
	private static void updateResult(boolean value) {
		if (value = false) {
			result = false;
		}
	}
}
