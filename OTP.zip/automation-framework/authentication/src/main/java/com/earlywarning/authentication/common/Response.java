/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.common;

/**
 * A POJO that represents the Authentify response message.
 * @author cornettl
 *
 */
public class Response {
	private String clientId;
	private String clientContext;
	private String sgid;
	private String app;
	private String clientAcctId;
	private String ewSID;
	private String replyTo;
	private String timestampISO8601;
	private String event;
	private String statusCode;
	private Data data;
	
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getClientContext() {
		return clientContext;
	}
	public void setClientContext(String clientContext) {
		this.clientContext = clientContext;
	}
	public String getSgid() {
		return sgid;
	}
	public void setSgid(String sgid) {
		this.sgid = sgid;
	}
	public String getApp() {
		return app;
	}
	public void setApp(String app) {
		this.app = app;
	}
	public String getEwSID() {
		return ewSID;
	}
	public void setEwSID(String ewSID) {
		this.ewSID = ewSID;
	}
	public String getReplyTo() {
		return replyTo;
	}
	public void setReplyTo(String replyTo) {
		this.replyTo = replyTo;
	}
	public String getTimestampISO8601() {
		return timestampISO8601;
	}
	public void setTimestampISO8601(String timestampISO8601) {
		this.timestampISO8601 = timestampISO8601;
	}
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
	public String getClientAcctId() {
		return clientAcctId;
	}
	public void setClientAcctId(String clientAcctId) {
		this.clientAcctId = clientAcctId;
	}
	
	
}
