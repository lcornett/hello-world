package com.earlywarning.authentication.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;

/**
 * A POJO that represents the enterprisePhoneNumber element of
 * the Authentify JSON request message. This class utilizes the 
 * lombok Data and the jackson JsonInclude annotations. The Data
 * annotation implements the setter and getter for the private
 * property:<ul><li>value</li></ul>
 * Please see the 
 * <a href="{@docRoot}/com/earlywarning/authentication/common/package-summary.html#tags"> 
 * package-info</a> page for more information about the annotations.
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_NULL)
public class EnterprisePhoneNumber {
	private String value;
}
