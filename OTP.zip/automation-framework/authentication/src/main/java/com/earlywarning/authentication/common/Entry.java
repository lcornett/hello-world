/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.common;

import lombok.Data;

/**
 * <p>A POJO that represents an element in the array 'data.datalookup.flagEntries' of the Authentify response message.</p> 
 * <p>This class utilizes the lombok Data annotation to implement the getters and setters for the private properties:</p><ul>
 * 	<li>value</li>
 * 	<li>lineType</li>
 * 	<li>status</li>
 * 	<li>tenure</li>
 * 	<li>velocity</li></ul>
 * <p>For additional information about the annotation, please see the 
 * <a href="{@docRoot}/com/earlywarning/authentication/common/package-summary.html#tags">package-info</a> page.
 * @author cornettl
 *
 */
@Data
public class Entry {
	private String value;
	private String lineType;
	private String status;
	private String tenure;
	private String velocity;
}
