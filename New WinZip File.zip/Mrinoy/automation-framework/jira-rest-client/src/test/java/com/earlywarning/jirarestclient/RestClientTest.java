package com.earlywarning.jirarestclient;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

public class RestClientTest {

	@Before
	public void setUp() throws Exception {
		Exporter exporter = mock(Exporter.class);
		Importer importer = mock(Importer.class);
		ApplicationContext context = mock(ApplicationContext.class);
		RestClient.context = context;
		when(context.getBean(Exporter.class)).thenReturn(exporter);
		when(context.getBean(Importer.class)).thenReturn(importer);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testMainImporter() throws Exception {
		String[] args = {"import"};
		RestClient.main(args);
		
		assertTrue(true);
	}
	
	@Test 
	public void testMainExporter() throws Exception {
		String[] args = {"export", "QCA-209;QCA-229"} ;
		RestClient.main(args);
		
		assertTrue(true);
	}

	@Test(expected=NullPointerException.class)
	public void testMainNoArgs() throws Exception {
		String[] args = null;
		RestClient.main(args);
		
		assertTrue(true);
	}

	@Test(expected=ArrayIndexOutOfBoundsException.class)
	public void testMainExportOneArg() throws Exception {
		String[] args = {"export"};
		RestClient.main(args);
		
		assertTrue(true);
	}

	@Test(expected=IllegalArgumentException.class)
	public void testMainInvalidArg() throws Exception {
		String[] args = {"Exporter"};
		RestClient.main(args);
		
		assertTrue(true);
	}

}
