/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.jirarestclient;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import lombok.extern.slf4j.Slf4j;

/**
 * The entry point for the JiraRestClient application. Contains the main method.
 * @author cornettl
 *
 */
@Slf4j
public class RestClient {
	static Exporter exporter;
	static ApplicationContext context;
	static Importer importer;
	
	/**
	 * The main logic for the application. This expects the first argument in the 
	 * array to be the operation to perform. Valid options are export and import.
	 * If 'export' is used, then a second argument is expected. The second are is the 
	 * list of issues to export.
	 * @param args An array of strings 
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		String function = null;
		if(context == null) {
			context = new AnnotationConfigApplicationContext(RestClientConfig.class);
		}
		exporter = context.getBean(Exporter.class);
		importer = context.getBean(Importer.class);

		try {
			function = args[0];
			switch (function.toLowerCase()) {
				case "export":
					// this function should come with another param
					// indicating the tests to export from Jira
					String tests = args[1];
					exporter.executeRequest(tests);
					break;
				case "import":
					// this function imports the execution results to Jira
					importer.execute();
					break;
				default:
					final String msg = "The argument " + function + " is not valid!";
					log.error(msg);
					throw new IllegalArgumentException(msg);
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
			throw e;
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
			throw e;
		}
	}


}
