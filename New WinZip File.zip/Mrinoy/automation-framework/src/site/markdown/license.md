## Project License
The artifacts produced for this project are the sole property of Early Warning &reg; and subject to the following copyright.

 Copyright &copy; Early Warning Services, LLC. All Rights Reserved.
 
 Internal use only. Confidential and proprietary. You may not disclose, copy
 or distribute this material for any purpose in any medium without the
 expressed written consent of Early Warning Services, LLC.
