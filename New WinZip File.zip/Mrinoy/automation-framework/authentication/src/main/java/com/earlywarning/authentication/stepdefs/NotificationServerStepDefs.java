/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.stepdefs;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import com.earlywarning.authentication.common.ApiDriver;
import com.earlywarning.authentication.common.StoredParams;
import com.earlywarning.authentication.notificationserver.MessageVerifier;
import com.earlywarning.authentication.notificationserver.Request;
import com.earlywarning.authentication.notificationserver.RequestCreator;
import com.earlywarning.authentication.startup.Env;
import com.earlywarning.authentication.utils.DateUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.DataTable;
import cucumber.api.java8.En;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;

// TODO Java Docs
@Log4j2
public class NotificationServerStepDefs implements En {
	private static Request request;
	private static ApiDriver apiDriver;
	private static ObjectMapper mapper = new ObjectMapper();
	private static String jsonRequest;
	
	public NotificationServerStepDefs() {
		Given("^the notification request has the values$", (DataTable data) -> {
			Map<String, String> map = data.asMap(String.class, String.class);
			request = RequestCreator.createRequest(map);			
		});
		
		Given("^the following notification request$", (String json) -> {
		    jsonRequest = json;

		});
		
		Given("^the current date/time is stored$", () -> {
			String utc = DateUtils.getUTC();
			StoredParams.store("date", utc);
			//throw new PendingException();
		});
		
		When("^the notification request is sent$", () -> {
			String jsonString = null;
			String contentType = "application/json";
			String environment = Env.getProperty("environment");
			String url = Env.getProperty(environment+"NotificationEndpoint");
			apiDriver = new ApiDriver(contentType, url);
			
			try {
				if (null == jsonRequest) {
					jsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
				} else {
					jsonString = jsonRequest;
					jsonRequest = null;
				}
				log.info("The request being sent is:\n" + jsonString);					

				apiDriver.setBody(jsonString);
				apiDriver.post();
			} catch (JsonProcessingException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		});
		
		When("^the notification request is sent for http status$", () -> {
			String jsonString = null;
			String contentType = "application/json";
			String environment = Env.getProperty("environment");
			String url = Env.getProperty(environment+"NotificationEndpoint");
			apiDriver = new ApiDriver(contentType, url);
			
			try {
				if (null == jsonRequest) {
					jsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
				} else {
					jsonString = jsonRequest;
					jsonRequest = null;
				}
				log.info("The request being sent is:\n" + jsonString);					

				apiDriver.setBody(jsonString);
				apiDriver.post(true);
			} catch (JsonProcessingException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		});

		
		Then("^the httpStatus is (\\d+)$", (Integer expected) -> {
			int status = ApiDriver.getHttpStatus();
			String msg = "";
			if (expected == status) {
				msg = "The actual and the expected httpStatus were " + status +".";
			} else {
				msg = "The actual status code from the server was " + status + ". The expected code was " + expected + ".";
			}
			log.info(msg);
			assertTrue(expected == ApiDriver.getHttpStatus());
		});

		Then("^verify the SMS is delivered$", () -> {
			String step = "Then verify the SMS is delivered.";
		    String msg = step + " is a manual step and cannot be automated at this time.";
		    log.info(msg);
		    MessageVerifier mv = new MessageVerifier();
		    try {
				assertTrue(mv.smsVerifier());
			} catch (InterruptedException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		    
		});
		
		Then("^verify the SMS is not delivered$", () -> {
			String step = "Then verify the SMS is not delivered.";
		    String msg = step + " is a manual step and cannot be automated at this time.";
		    log.info(msg);
		    
		    MessageVerifier mv = new MessageVerifier();
		    try {
				assertFalse(mv.smsVerifier());
			} catch (InterruptedException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}

		});


		Then("^verify short code on device is (\\d+)$", (Integer shortCode) -> {
		   String step = "Then verify short code on device is " + shortCode;
			String msg = step + " is a manual step and cannot be automated at this time.";
		    log.info(msg);
		    
		});

		Then("^verify httpStatus is (\\d+)$", (Integer httpStatus) -> {
			String msg = "";
			boolean result = false;
			
			if (httpStatus == ApiDriver.getHttpStatus()) {
				msg = "The actual and expected http statusCode is " + httpStatus + ".";
				result = true;
			} else {
				msg = "The actual httpStatus is " + ApiDriver.getHttpStatus() + " and the expected httpStatus is" + httpStatus + ".";
				
			}
			
			log.info(msg);
			assertTrue(result);
		});

		Then("^verify response status = \"([^\"]*)\"$", (String expectedStatus) -> {
			boolean result = false;
			String msg = "";
			Response response = ApiDriver.getResp();
			String actualStatus = ApiDriver.retrieveJsonValueString(response, "status");
			
			if (actualStatus.equals(expectedStatus)) {
				result = true;
				msg = "The value of status element in the response and the expected value are both " + expectedStatus +".";
			} else {
				msg = "The actual status element value is " + actualStatus +". The expected value is "  + expectedStatus + ".";
			}
			log.info(msg);
			assertTrue(result);
		});

		When("^verify the email was delivered$", () -> {
		    // Write code here that turns the phrase above into concrete actions
			
			MessageVerifier mv = new MessageVerifier();
			try {
				assertTrue(mv.verifyEmail());
			} catch (InterruptedException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);			}
		});
	}

}
