/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.common;

import lombok.Data;

/**
 * A POJO that represents the lastVerificationDate element of the Authentify
 * JSON request message. This class utilizes the lombok Data annotation to
 * provide the implementation of the setter and getter for the private 
 * property:<ul><li>value</li></ul>
 * Please see the 
 * <a href="{@docRoot}/com/earlywarning/authentication/common/package-summary.html#tags">
 * package-info</a> page for additional information about the annotation.
 * @author cornettl
 *
 */
@Data
public class LastVerificationDate {
	private String value;
}
