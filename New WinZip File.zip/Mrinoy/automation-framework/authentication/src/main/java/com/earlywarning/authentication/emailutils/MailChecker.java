/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.emailutils;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import com.earlywarning.jirarestclient.utilities.Encryption;
import com.earlywarning.authentication.notificationserver.MessageVerifier;
import com.earlywarning.authentication.startup.Env;

import lombok.extern.log4j.Log4j2;


/**
 * A class that logs into an email account, gets the most recent email, and 
 * verifies that an expected string is contained in the body. If the string 
 * is not contained in the body of the email, it tries again until the set timeout. 
 * @author cornettl
 *
 */
@Log4j2
public class MailChecker {
	
	/**
	 * Logs into an email account, gets the most recent email, and verified that the 
	 * parameter passed in is contained in the body of the email. This will be done in a loop
	 * until the expected string is found or the timeout period has been reached.
	 * @param expected The string to look for.
	 * @return True if the expected string is found, false otherwise.
	 */
	public boolean check(String expected) {
		boolean result = false;
		MailReader reader = new MailReader();
		Folder emailFolder = null;
		Store store = null;
		Encryption enc = new Encryption();
		final String host = Env.getProperty("emailHost");
		final String user = null;
		MessageVerifier.setSubject(null);
		int timeout = Integer.parseInt(Env.getProperty("emailCheckTimeout"));
		
		try {
			Properties properties = new MailProperties().getProperties();
			
			Session emailSession = Session.getInstance(properties, new Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(Env.getProperty("emailAddress"), enc.decrypt(Env.getProperty("emailPassword")));
				}
			});
			
				
			// create the pop3 store object and connect with the pop server
			store = emailSession.getStore();
			store.connect(host, user, enc.decrypt(Env.getProperty("emailPassword")));
			
			// create the folder object and open it.
			emailFolder = store.getFolder("INBOX");
			emailFolder.open(Folder.READ_ONLY);
			
			// retrieve the messages from the folder in an array and print it
			
			long startTime = System.currentTimeMillis();
			long stopTime = timeout + startTime;
			
			do {
				int count = emailFolder.getMessageCount();
				Message message = emailFolder.getMessage(count);
				String str = reader.readMail(message);
				if (str.contains(expected)) {
					MessageVerifier.setSubject(message.getSubject());
					result = true;
					break;
				}
				Thread.sleep(1000);
			} while (System.currentTimeMillis() < stopTime);
			
		} catch (MessagingException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (IOException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (InterruptedException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} finally {
			try {
				emailFolder.close(false);
				store.close();
			} catch (MessagingException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		}
		return result;
	}
	
//	
//	/**
//	 * 
//	 * @param args
//	 */
//	public static void main(String[] args) {
//		String host = "outlook.ews.int";
//		String mailStoreType = "imap";
//		String username = "lawrence.cornett@earlywarning.com";
//		String password = "YN\\#&pX!|V";
//		
//		MailChecker mail = new MailChecker();
//		mail.check(null);
//	}
}
