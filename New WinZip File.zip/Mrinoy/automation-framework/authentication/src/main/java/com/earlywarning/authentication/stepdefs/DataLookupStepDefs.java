/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.stepdefs;

import static org.junit.Assert.assertTrue;

import java.util.Map;

import com.earlywarning.authentication.common.ApiDriver;
import com.earlywarning.authentication.startup.Env;
import com.earlywarning.authentication.xml.AuthentXML;
import com.earlywarning.authentication.xml.XmlRequestCreator;
import com.earlywarning.authentication.xml.XmlResponseValidator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import cucumber.api.DataTable;
import cucumber.api.java8.En;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;

/**
 * <p>A cucumber Step Definition class using Java 8 lambdas. These step definitions
 * act on messages described in the com.earlywarning.authentication.xml package and 
 * were originally implemented to test the Authentify DataLookup feature. The step 
 * definitions contained in this class are described below.</p>
 * 
 * <p>The 'Given' Step Definitions.<ol>
 * 	<li><code>Given the datalookup request has the following data</code> - This step definition requires a DataTable as
 * 		an argument. A DataTable takes the format <br> | &lt;name of tag&gt; | &lt;value of tag&gt; | <br>
 * 		Again this step definition allows the user to create a valid XML request using the tags identified.</li>
 * 	<li><code>Given the following SOAP message</code> - This step definition allows the user to input a preformatted
 * 		SOAP message instead of building a SOAP message. The format of this step definition is as follows:<br>
 * 		<code>Given the following SOAP message
 * 			  """
 * 				&lt;valid SOAP message&gt;
 * 			  """
 * 		</code>This step definition requires the triple quotes around the SOAP message.</li></ol>
 * <p>The 'When' Step Definitions.<ol>
 * 	<li><code>When the request is posted to the service</code> - Sets the body of the message to the
 * 		created xml message and posts the message to the endpoint contained in the 'environment.properties'
 * 		file.</li>
 * 	<li><code>When the soapMessage is sent</code> - Sets the body of the message to the passed in SOAP 
 * 		message and posts the message to the endpoint.</li></ol>
 * <p>The 'Then' Step Definitions.<ol>
 * 	<li><code>Then the following values are verified</code> -  This step definition requires a DataTable as
 * 		an argument. A DataTable takes the format <br> | &lt;name of tag&gt; | &lt;expected value of tag&gt; | <br>
 * 		The values of the named elements are compared against the expected values.</li>
 * 	<li><code>Then the response values are verified</code> - The same as the above definition except the 
 * 		values are verified in the SOAP message.</li>
 * 	<li><code>When the xml poll request is sent</code> - Constructs an XML poll request and sends it the the endpoint
 * 		until a response other than statusCode 7000 (Session in Progress) is received.</li></ol>
 * 	
 * @author cornettl
 *
 */
@Log4j2
public class DataLookupStepDefs implements En {
	private static AuthentXML request;
	private static String environment = Env.getProperty("environment");
	private static String endpoint = Env.getProperty(environment + "XmlEndpoint");
	private static ApiDriver driver = new ApiDriver("application/xml", endpoint);
	private static XmlMapper mapper = new XmlMapper();
	private static Response response;
	private static String soapMessage;
	
	/**
	 * This constructor contains all of the Step Definition lambdas. It is not intended to 
	 * be used by the automation developer.
	 */
	public DataLookupStepDefs() {
		Given("^the datalookup request has the following data$", (DataTable data) -> {
			Map<String, String> map = data.asMap(String.class, String.class);
			request = XmlRequestCreator.createRequest(map);
		});
		
		Given("^the following SOAP message$", (String soapMessage) -> {
			DataLookupStepDefs.soapMessage = soapMessage;
		});
		
		When("^the request is posted to the service$", () -> {
			try {
				mapper.enable(SerializationFeature.INDENT_OUTPUT);
				String body = mapper.writeValueAsString(request);
				driver.setBody(body);
				log.info("The request sent to the server is:\n" + body);
				driver.post();
				response = ApiDriver.getResp();
			} catch (JsonProcessingException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		});
		
		When("^the soapMessage is sent$", () -> {
			driver.setBody(soapMessage);
			log.info("The request sent to the server is:\n" + soapMessage);
			driver.post();
			response = ApiDriver.getResp();
		});

		Then("^the following values are verified$", (DataTable data) -> {
			boolean result = false;
			Map<String, String> map = data.asMap(String.class, String.class);
			result = XmlResponseValidator.validateResponse(response, map);
			assertTrue(result);
		});
		
		Then("^the response values are verified$", (DataTable data) -> {
			boolean result = false;
			Map<String, String> map = data.asMap(String.class, String.class);
			result = XmlResponseValidator.validateSOAPResponse(response, map);
			assertTrue(result);
		});

		When("^the xml poll request is sent$", () -> {
		    // Write code here that turns the phrase above into concrete actions
			driver.xmlPoll();
			response = ApiDriver.getResp();
		});

	}
}

