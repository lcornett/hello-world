/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.notificationserver;

import com.earlywarning.authentication.emailutils.MailChecker;

import lombok.extern.log4j.Log4j2;

/**
 * A class used to verify the different messages.
 * @author cornettl
 *
 */
@Log4j2
public class MessageVerifier {
	private static String expected;
	private static String subject;
	

	/**
	 * A method to verify that an SMS message has been sent.
	 * @return True if there is evidence that the message was sent
	 * @throws InterruptedException
	 */
	public boolean smsVerifier() throws InterruptedException {
		boolean result = false;
		MailChecker checker = new MailChecker();
		
		result = checker.check(expected);
		log.info(expected + " was found.");
		return result;
	}
	
	/**
	 * Verifies the short code in an SMS Message
	 * @param expected The expected short code
	 * @return True if the short code was verified.
	 */
	public boolean verifyShortCode(int expected) {
		boolean result = false;
		
		result = subject.contains(Integer.toString(expected));
		return result;
	}
	
	public boolean verifyEmail() throws InterruptedException {
		return smsVerifier();
	}

	public static String getSubject() {
		return subject;
	}

	public static void setSubject(String subject) {
		MessageVerifier.subject = subject;
	}
	
	public static String getExpected() {
		return expected;
	}

	public static void setExpected(String expected) {
		MessageVerifier.expected = expected;
	}

}
