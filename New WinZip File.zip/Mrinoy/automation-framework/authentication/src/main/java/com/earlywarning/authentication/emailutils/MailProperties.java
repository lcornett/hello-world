/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.emailutils;

import java.util.Properties;

import com.earlywarning.authentication.startup.Env;

import lombok.extern.log4j.Log4j2;

/**
 * A class that holds the properties for accessing an email server inbox. Currently, 
 * two protocols are supported: imap and pop3. Both protocols are secure. These 
 * properties are instantiated whenever the constructor of the class is called.
 * @author cornettl
 *
 */
@Log4j2
public class MailProperties {
	private Properties properties = new Properties();
	
	public MailProperties() {
		String key = "emailProtocol";
		String protocol = "";
		
		protocol = Env.getProperty(key);
		
		switch (protocol) {
			case "imap":
				populateImapProperties();
				break;
			case "pop3":
				populatePopProperties();
				break;
			default:
				String msg = "Unknown protocol!";
				log.info(msg);
			
		}
	}
	
	public Properties getProperties() {
		return properties;
	}

	private void populateImapProperties() {
		properties.put("mail.imap.host", Env.getProperty("emailHost"));
		properties.put("mail.imap.port", "993");
		properties.put("mail.imap.starttls.enable", "true");
		properties.put("mail.store.protocol", "imaps");

	}

	private void populatePopProperties() {
		properties.put("mail.pop3.host", Env.getProperty("emailHost"));
	    properties.put("mail.pop3.port", "995");
	    properties.put("mail.pop3.starttls.enable", "true");
	    properties.put("mail.store.protocol", "pop3s");	 
	}
	
}
