/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.ccv;

import static io.restassured.RestAssured.given;

import java.net.MalformedURLException;
import java.net.URL;

import com.earlywarning.authentication.startup.Env;
import com.earlywarning.authentication.utils.CustomPropertyNamingStrategy;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;

/**
 * A class that makes the calls to the CCV application
 * @author cornettl
 *
 */
@Log4j2
public class CcvRestCalls {
	public static String host;
	
	static {
		String env = Env.getProperty("environment");
		host = Env.getProperty("ccv-"+env+"-host");
	}
	/**
	 * A call to the ccvEcho end point. A response means that the service is running.
	 * @return true if the service responds, false otherwise
	 */
	public static boolean isCcvRunning() {
		boolean result = false;
		int status = -1;
		String echo = "{\"RequestId\":\"1234567890\", \"Message\":\"This is a test message.\"}";
		
		try {
			String env = Env.getProperty("environment");
			host = Env.getProperty("ccv-"+env+"-host");
			URL ccvEcho = new URL(host+"ccvEcho");
			
			status = given().body(echo).relaxedHTTPSValidation("TLS").when().contentType(ContentType.JSON).post(ccvEcho).then().statusCode(200).extract().path("Status");
	 
			if (status == 0) 
				result = true;

		} catch (MalformedURLException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}

		
		return result;
	}
	
	/**
	 * Makes a call to the getSIC end point. 
	 * @param request The message to pass to the end point.
	 * @return An instance of the Rest Assured Response
	 */
	public static Response sendRequest(CCVRequest request) {
		ObjectMapper mapper = new ObjectMapper()
				.setPropertyNamingStrategy(new CustomPropertyNamingStrategy());
		String jsonString = null;
		Response response = null;
	try {
			jsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
			response =  sendRequest(jsonString);
		}  catch (JsonProcessingException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		return response;
	}
	
	/**
	 * Makes a call the the getSIC end point. This method uses a formated request,
	 * probably in an invalid format or with invalid values, instead of a CCVRequest
	 * class.
	 * @param request The request string
	 * @return The ReST Response message
	 */
	public static Response sendRequest(String request) {
		Response response = null;
		try {
			URL getSIC = new URL(host+"getSIC"); 
			
			log.info("Sent the following request to the server: \n" + request);

			response =
					given().
					relaxedHTTPSValidation().
				    contentType(ContentType.JSON).body(request).
				    when().
				    post(getSIC).andReturn();			

			log.info("The following response was received from the server: \n" + response.getBody().prettyPrint());
		} catch (MalformedURLException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		return response;
	}
	
	/**
	 * Makes a http POST operation to the ccvEcho end point
	 * @param request An instance of the CCVEchoRequest class.
	 * @return The ReST response from the server.
	 */
	public static Response postEcho(CCVEchoRequest request) {
		Response response = null;
		ObjectMapper mapper = new ObjectMapper().setPropertyNamingStrategy(new CustomPropertyNamingStrategy());
		String jsonString = null;
		URL ccvEcho = null;
		
		try {
			String env = Env.getProperty("environment");

			host = Env.getProperty("ccv-"+env+"-host");

			ccvEcho = new URL(host + "ccvEcho");
			jsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
			log.info("Sent the following request to the server " + ccvEcho + ": \n" + jsonString);
			
	        response =
	                    given().
	                            contentType(ContentType.JSON).body(jsonString).relaxedHTTPSValidation("TLS").
	                            when().
	                            post(ccvEcho).andReturn();
	        log.info("The following response was received from the server: \n" + response.getBody().prettyPrint());			
		} catch (MalformedURLException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (JsonProcessingException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}
	

}
