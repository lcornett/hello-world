/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.emailutils;

import java.io.IOException;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMultipart;
import org.jsoup.Jsoup;

/**
 * A class that retrieves the text in an email message. Plain text and multipart
 * message bodies are supported.
 * @author cornettl
 *
 */
public class MailReader {

	/**
	 * The method that retrieves the message body text from the message. The email folder has
	 * to remain open while this work is being performed.
	 * @param message The message to get the text from.
	 * @return THe message text
	 * @throws MessagingException
	 * @throws IOException
	 */
	public String readMail(Message message) throws MessagingException, IOException {
		String result = "";
		
		if (message.isMimeType("text/plain")) {
			result = message.getContent().toString();
		} else if (message.isMimeType("multipart/*")) {
			MimeMultipart mimeMultipart = (MimeMultipart) message.getContent();
			result = readMimeMultipart(mimeMultipart);
		} else if (message.isMimeType("text/html")) {
			result = Jsoup.parse(message.getContent().toString()).text();
		}
		

		return result;
		
	}
	
	/**
	 * A method to process a multipart message body.
	 * @param multiPart The multipart element to process.
	 * @return The text of the multipart element.
	 * @throws MessagingException
	 * @throws IOException
	 */
	private String readMimeMultipart(MimeMultipart multiPart) throws MessagingException, IOException {
		String result = "";
		
		int count = multiPart.getCount();
		
		for (int i = 0; i < count; i++) {
			BodyPart bodyPart = multiPart.getBodyPart(i);
			if (bodyPart.isMimeType("text/plain")) {
				result = result + "\n" + bodyPart.getContent();
				
			} else if (bodyPart.isMimeType("text/html")) {
				String html = (String) bodyPart.getContent();
				result = result + "\n" + Jsoup.parse(html).text();
			} else if (bodyPart.getContent() instanceof MimeMultipart) {
				result = result + readMimeMultipart((MimeMultipart)bodyPart.getContent());
			}
		}
		return result;
		
	}
}
