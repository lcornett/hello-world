/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.xml;

import lombok.Data;

/**
 * <p>A POJO that represents the body node of the Authentify XML request message.
 * This class utilizes the lombok Data annotation. This annotation provides the 
 * implementation of the getter and setter for the private property:</p><ul><li>request</li></ul>
 * <p>Additional information about this annotation may be located on the 
 * <a href="{@docRoot}/com/earlywarning/authentication/xml/package-summary.html#tags">package-info</a> page.</p>
 * @author cornettl
 *
 */
@Data
public class Body {
	private XmlRequest request;
}

