/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;

/**
 * A POJO representing the User sub-element of the Data element of the
 * Authentify JSON request.
 * This class utilizes the lombok.Data and the jackson-databind.Include 
 * annotations. At the time of creation, this class implements one property:<ul>
 * 	<li>uuid</li></ul>
 * Please see the <a href="{@docRoot}/com/earlywarning/authentication/common/package-summary.html#tags">
 * package-info</a> for the annotation details.
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_EMPTY)
public class DataUser {
	private String uuid;
}
