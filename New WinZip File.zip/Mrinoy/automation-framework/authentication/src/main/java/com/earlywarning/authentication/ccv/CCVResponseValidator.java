/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.ccv;

import java.util.Map;
import java.util.Set;

import com.earlywarning.authentication.common.ApiDriver;

import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;

/**
 * Validates the ReST response from a Call Center Verification request
 * against a set of expected values. Implements the CCVFieldConstants
 * interface which provides the JsonPath for each element to be verified.
 * @author cornettl
 *
 */
@Log4j2
public class CCVResponseValidator implements CCVFieldConstants {
	static ApiDriver driver = new ApiDriver("json", "");
	static Map<String, String> map;
	static boolean result = true;
	
	/**
	 * This method is the framework of validating the response by evaluating
	 * each element in the expected values map against the its matching element 
	 * in the ReST response.
	 * @param response The response for the request.
	 * @param map A Map of expected values.
	 * @return true if the response is successfully validated, false if not.
	 */
	public static boolean validateResponse(Response response, Map<String, String> map) {
		CCVResponseValidator.map = map;
		Set<String> keys = map.keySet();
		
		try {
			int x = 0;
			for (String key : keys) {
				switch (key) {
				case "AdditionalInfo":
					validate(response, RESPONSE_ADDITIONAL_INFO, map.get(key));
					break;
				case "Address":
					validate(response, CONFIDENCE_ADDRESS, map.get(key));
					break;
				case "Description":
						validate(response, RESPONSE_DESCRIPTION, map.get(key));
						break;
					case "Email":
						validate(response, CONFIDENCE_EMAIL, map.get(key));
						break;
					case "EventType":
						validateList(response, EVENT_TYPE, map.get(key));
						break;
					case "LastChangedDate":
						validateList(response, LAST_CHANGED_DATE, map.get(key));
						break;
					case "MCV-AdditionalInfo":
						validate(response, MCV_ADDITIONAL_INFO, map.get(key));
						break;
					case "MCV-Description":
						validate(response, MCV_DESCRIPTION, map.get(key));
						break;
					case "MCV-Status":
						validate(response, MCV_STATUS, map.get(key));
						break;
					case "MI-AdditionalInfo":
						validate(response, MI_ADDITIONAL_INFO, map.get(key));
						break;
					case "MI-Description":
						validate(response, MI_DESCRIPTION, map.get(key));
						break;
					case "MI-Status":
						validate(response, MI_STATUS, map.get(key));
						break;
					case "MobileIdentityCreatedDate":
						validate(response, MOBILE_IDENTITY_CREATED_DATE, map.get(key));
						break;	
					case "MobileIdentityTransactionId":
						validateTransactionId(response, MOBILE_IDENTITY_TRANSACTION_ID, map.get(key));
						break;
					case "MobileNumber":
						validate(response, RESPONSE_MOBILE_NUMBER, map.get(key));
						break;
					case "MobileOperatorName":
						validate(response, MOBILE_OPERATOR_NAME, map.get(key));
						break;
					case "MobileStatusTransactionId":
						validateTransactionId(response, MOBILE_STATUS_TRANSACTION_ID, map.get(key));
						break;
					case "MS-AdditionalInfo":
						validate(response, MS_ADDITIONAL_INFO, map.get(key));
						break;
					case "MS-Description":
						validate(response, MS_DESCRIPTION, map.get(key));
						break;
					case "MS-Status":
						validate(response, MS_STATUS, map.get(key));
						break;
					case "Name":
						validate(response, CONFIDENCE_NAME, map.get(key));
						break;
					case "PayfoneAlias":
						validate(response, RESPONSE_PAYFONE_ALIAS, map.get(key));
						break;
					case "RequestId":
						validate(response, RESPONSE_REQUEST_ID, map.get(key));
						break;
					case "Status":
						validate(response, RESPONSE_STATUS, map.get(key));
						break;
					case "StatusIndex":
						validate(response, STATUS_INDEX, map.get(key));
						break;
					default:
						String msg = "The element " + key + " is invalid!";
						log.warn(msg);
				}
					System.out.println(++x);	
			}
			
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		boolean status = result;
		result = true;
		
		return status;
		
	}
	
	/**
	 * A method that compares the actual value of an element against the expected value. 
	 * The static variable result is updated in this method.
	 * @param response The ReST response message.
	 * @param key The name of the element to verify the value of.
	 * @param expected The expected value of the element.
	 */
	private static void validate(Response response, String key, String expected) {
		String actual = null;
		
		actual = ApiDriver.retrieveJsonValueString(response, key);
		
		if (!expected.equals(actual)) {
			String msg = "The actual value for key " + key + " is " + actual + " and does not equal the expected value " + expected + ".";
			log.info(msg);
			updateResult(false);
		} else {
			log.info("The " + key + " element was successfully validated");
		}
		
		
	}
	
	/**
	 * Uses the result of the last comparison the update the result static instance valiable.
	 * @param status The result of the last comparison.
	 */
	private static void updateResult(boolean status) {
		if (result == true && status == false) {
			result = false;
		}
	}

	/**
	 * Used to eveluate and validate an array of values. More specifically, the eventType
	 * and lastChangedDate are eveluated using this method. The expected values are a 
	 * comma separated string.
	 * @param response The ReST response message.
	 * @param key The JsonPath of the elements to validate
	 * @param expected The expected values.
	 */
	private static void validateList(Response response, String key, String expected) {
		String actual = null;
		String[] expectedArray = null;
		String[] actualArray = null;
		String regex = ",";
		int elements = 0;
		int matches = 0;
		
		actual = ApiDriver.retrieveJsonValueString(response, key).replaceAll("\\[", "").replaceAll("\\]", "");
		actualArray = actual.split(regex);
		
		expectedArray = expected.split(regex);
		
		elements = actualArray.length;
		
		if (expectedArray.length == elements) {
			for (String element : actualArray) {
				for (String expectedElement : expectedArray) {
					if (element.trim().equals(expectedElement)) {
						matches++;
						break;
					} 
				}
			}
		}
		
		if (matches/elements != 1) {
			String msg = "The actual elements for " + key + ": " + actual + ", did not match the expected elements " + expected + ".";
			updateResult(false);
			log.info(msg);
		} else {
			log.info("The " + key + " element was successfully validated");
		}
	}
	
	/**
	 * There can be several transactionId elements in a response message. The value of 
	 * the transactionID element is a unique value to the server. What this method does
	 * is ensure the element is included in the response. Its value is not validated.
	 * @param response The ReST response message.
	 * @param key The JsonPath of the element to validate
	 * @param expected This can be any string.
	 */
	private static void validateTransactionId(Response response, String key, String expected) {
		// The expected value is irrelevant.
		String actual = null;
		
		actual = ApiDriver.retrieveJsonValueString(response, key);
		
		if (null == actual) {
			String msg = "The element " + key + " failed validation.";
			log.info(msg);
			updateResult(false);
		} else {
			String msg = "The " + key + " element was successfully validated.";
			log.info(msg);
		} 
	}
}

