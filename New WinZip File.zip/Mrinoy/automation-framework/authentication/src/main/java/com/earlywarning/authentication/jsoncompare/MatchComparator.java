/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.jsoncompare;

import java.util.ArrayList;

import com.earlywarning.authentication.common.Match;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class MatchComparator extends StringComparator {

	boolean compareMatches(ArrayList<Match> actual, ArrayList<Match> expected) {
		final String comparator = "data.dataLookup.matchResults.";
		String msg = "";
		String expectedType = "";
		String actualType = "";
		Match expectedMatch = null;
		Match actualMatch = null;
		boolean isFound = false;
		
		try {
			
			if ((null == actual) && (null == expected)) {
				msg= "The " + comparator + " element in both messages is null.";
				log.info(msg);
				return true;
			}
			
			if (actual.size() != expected.size()) {
				msg = "The actual matchResults and the expected matchResults are not the same size.";
				log.info(msg);
				return false;
			}
			
			for (int i = 0; i < expected.size(); i++) {
				expectedMatch = expected.get(i);
				expectedType = expectedMatch.getType();
				
				for (int j = 0; j < actual.size(); j++) {
					actualMatch = actual.get(j);
					actualType = actualMatch.getType();
					
					if (actualType.equals(expectedType)) {
						isFound = true;
						updateStatus(compareString(comparator + expectedType, actualMatch.getMatch(), expectedMatch.getMatch()));
						break;
					}
				}
				
				if (!isFound) {
					msg = "The expected expected match type, " + expectedType + ", was not found in the list of actual match types!";
					log.info(msg);
				} else {
					isFound = false;
				}

				}
			} catch (Exception e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		
		return status;
	}
}
