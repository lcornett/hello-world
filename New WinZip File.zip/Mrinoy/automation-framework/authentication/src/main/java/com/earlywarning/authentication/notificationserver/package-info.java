/**
 * 
 */
/**
 * <h2 id="tags">Annotations</h2>
 * <p>The following annotations are used in this package.</p>
 * <h3 id="data">The Data Annotation</h3>
 * <p>The lombok Data annotation provides the implementation for the setters and getters for the class
 * private properties as well as the 'toString()', 'hashCode()' and 'equals()' methods without having to 
 * code these methods. Because the methods are provided by the annotation and not specifically coded, the 
 * Java Doc for the class does not include these methods.</p>
 * <p>Aditional information about the annotation may be found at the <a href="https://projectlombok.org/features/Data" target="blank">Project Lombok </a> website.</p>
 * 
 * <h3 id="builder">The Builder Annotation</h3>
 * <p>The lombok Builder annotation implements the builder pattern on the classes that use it. The effect of this implementation is:</p><ul>
 * 	<li><b>Implements an all argument constructor</b> - All non final properties of the base class are treated as parameters for the constructor.</li>
 * 	<li><b>Implements a builder() method</b> - The base class's builder() method returns a builder class using the naming convention &lt;class_name&gt;Builder</li>
 * 	<li><b>Implements a Builder Class</b> - The &lt;class_name&gt;Builder class has the following attributes:<ol>
 * 		<li>Has the same private properties as the base class</li>
 * 		<li>A setter method is implemented for each of the private properties and has the same name as the property.</li>
 * 		<li>Implements a toString() method.</li>
 * 		<li>Implements a build() method. The build method returns an instance of the base class with the properties instantiated
 * 			that were set in the builder class.</li></ol></ul>
 * <p>The Builder class and annotation implemented methods do not have any Java Docs associated with them. Additional information 
 * about the Builder annotation may be found at the <a href="https://projectlombok.org/features/Builder" target="blank">Project Lombok</a> website.</p>
 * 
 * @author cornettl
 *
 */
package com.earlywarning.authentication.notificationserver;