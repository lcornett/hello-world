/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.common;

import java.util.HashMap;
import java.util.Map;

/**
 * A class to temporarily store a value from a response for use in a future request.
 * It us also used to store an entire response for comparison to a response to a 
 * subsequent request.
 * @author cornettl
 *
 */
public class StoredParams {
	private static Map<String, String> map = new HashMap<String, String>();
	
	public static void store(String key, String value) {
		map.put(key, value);
	}
	
	public static String retrieve(String key) {
		String result = "";
		
		if ((result = map.get(key)) == null) {
			return "";
		}
		return result;
		
	}
	
	public static void clear() {
		map.clear();
	}
	
	public static void remove(String key) {
		map.remove(key);
	}
}
