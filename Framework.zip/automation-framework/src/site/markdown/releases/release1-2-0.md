## Release 1.2.0 Notes
The functionality in release 1.2.0 of the authentify automation framework addresses some bugs that affect Payfone and other general framework functionality and features for OOBA and CardVerify.

### Stories

- [AM-2169 - Processing of incoming message in SOAP format](https://jira.ews.int/browse/AM-2169)

- [AM-2261 - Payfone: PreFill Blockers TCs](https://jira.ews.int/browse/AM-2261)

### Bug Fixes

- [AM-2199 - Payfone: Mobile Status: few values are missing verification fduring "Then the response equals the stored response" step.](https://jira.ews.int/browse/AM-2199)

- [AM-2201 - OOBAApps: do not poll in milliseconds, poll every 5 seconds](https://jira.ews.int/browse/AM-2201)

- [AM-2202 - OOBAApps: request has extra tags that do not belong to OOBA phone calls](https://jira.ews.int/browse/AM-2202)

- [AM-2207 - OOBAApps: element account in xml response cannot be found (same for rateCategory in RSAGenericAction and delay in Verisign](https://jira.ews.int/browse/AM-2207)

- [AM-2213 - OOBAApps testcases - db validation for multiple rows should be added](https://jira.ews.int/browse/AM-2213)

- [AM-2214 - OOBAApps: Goldman_Sachs testcase: Request should be sent to QA2 only](https://jira.ews.int/browse/AM-2214)

- [AM-2217 - Payfone: MObileStatus: move request out of environment.properties file](https://jira.ews.int/browse/AM-2217)

- [AM-2218 - OOBAApps:Verisign: ddo not allow prompts instruction screen go beyond the computer screen](https://jira.ews.int/browse/AM-2218)

- [AM-2221 - OOBAApps: extension in expected result should have lower 'x', as in database, otherwise it fails](https://jira.ews.int/browse/AM-2221)

- [AM-2222 - DataLookup_PPLE_gEOLOCATE_soap: element responseType is not implemented](https://jira.ews.int/browse/AM-2222)

- [AM-2230 - Payfone: Mobile Status: phone number field in DB not comparing properly when null](https://jira.ews.int/browse/AM-2230)

- [AM-2312 - OOBA Apps - 5-cert2s testcase](https://jira.ews.int/browse/AM-2312)

- [AM-2321 - AuthCommonFullDataLookup: Request should be sent to QA1 only](https://jira.ews.int/browse/AM-2321)

- [AM-2324 - SOAP: do not use actual soap request in feature file](https://jira.ews.int/browse/AM-2324)

- [AM-2347 - Payfone: MobileStatus: Missing "legactDeviceId" in request data.](https://jira.ews.int/browse/AM-2347)

- [AM-2352 - Payfone: MobileIdentity: Missing request data fields](https://jira.ews.int/browse/AM-2352)