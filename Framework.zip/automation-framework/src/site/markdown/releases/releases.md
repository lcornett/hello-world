##Releases
The releases of this application will be documented here. The latest release will be listed first. A link will be provided to the release notes page.

[Release 1.2.0](release1-2-0.html) February 2, 2018

[Release 1.1.0](release1-1-0.html) January 4, 2018

[Release 1.0.0](release1-0-0.html) September 25,2017