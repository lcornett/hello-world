/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.response.gui;

import java.awt.EventQueue;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 * The main class for the Response File Editor application. This class is responsible 
 * creating the application window.
 * @author cornettl
 *
 */
public class ResponseFileEditor  {
	boolean isDirty = false;
	boolean isFiltered = false;
	JFrame frmResponseFileEditor;
	JTextField txtFeature, txtScenario;
	JTextArea response;
	JComboBox<String> cboEnvironment, cboPayfoneEnv, cboContentType;
	JTable table;
	JMenuBar menuBar;
	JMenu mnFile, mnEdit, mnSearch, mnOptions, mnHelp;
	JMenuItem mntmNew, mntmOpen, mntmClose, mntmSave, mntmSaveAs, mntmExit, mntmCreate, mntmUpdate, mntmDelete,
		mntmFind, mntmSort, mntmClearFilter, mntmAbout;
	JButton btnOpen, btnSave, btnSaveAs, btnCreate, btnUpdate, btnDelete;
	EventHandler eventHandler = new EventHandler(this);	
	TableModel savedModel;
	static String currentFile;

	/**
	 * Launch the application.
	 * @param args Any command line parameters. Usually none.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ResponseFileEditor window = new ResponseFileEditor();
					window.frmResponseFileEditor.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ResponseFileEditor() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmResponseFileEditor = new JFrame();
		frmResponseFileEditor.setTitle("Response File Editor");
		frmResponseFileEditor.setResizable(false);
		frmResponseFileEditor.setBounds(100, 100, 663, 774);
		frmResponseFileEditor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmResponseFileEditor.getContentPane().setLayout(null);
		frmResponseFileEditor.addWindowListener(eventHandler);
		
		JPanel panel = new JPanel();
		panel.setBounds(27, 24, 605, 344);
		panel.setLayout(null);
		panel.setBorder(new TitledBorder(null, "Search / Filter", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		frmResponseFileEditor.getContentPane().add(panel);
		
		JLabel lblPayfoneEnvironment = new JLabel("Payfone Environment:");
		lblPayfoneEnvironment.setHorizontalAlignment(SwingConstants.TRAILING);
		lblPayfoneEnvironment.setBounds(10, 44, 118, 14);
		panel.add(lblPayfoneEnvironment);
		
		cboPayfoneEnv = new JComboBox<String>();
		cboPayfoneEnv.setToolTipText("A non editable contol that displays the Payfone Environment field of the selected record.");
		cboPayfoneEnv.setModel(new DefaultComboBoxModel<String>(new String[] {"", "staging", "prod"}));
		cboPayfoneEnv.setBounds(138, 39, 90, 20);
		panel.add(cboPayfoneEnv);
		
		JLabel lblNewLabel = new JLabel("Feature Name:");
		lblNewLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		lblNewLabel.setBounds(10, 62, 118, 20);
		panel.add(lblNewLabel);
		
		txtFeature = new JTextField();
		txtFeature.setToolTipText("A non editable text field that displays the feature field of the selected record.");
		txtFeature.setEditable(false);
		txtFeature.setBounds(138, 62, 457, 20);
		panel.add(txtFeature);
		txtFeature.setColumns(10);
		
		JLabel lblScenarioName = new JLabel("Scenario Name:");
		lblScenarioName.setHorizontalAlignment(SwingConstants.TRAILING);
		lblScenarioName.setBounds(10, 83, 118, 14);
		panel.add(lblScenarioName);
		
		txtScenario = new JTextField();
		txtScenario.setToolTipText("A non editable text box that displays the scenario field of the selected record.");
		txtScenario.setEditable(false);
		txtScenario.setBounds(138, 83, 457, 20);
		panel.add(txtScenario);
		txtScenario.setColumns(10);
		
		JLabel lblContentType = new JLabel("Content Type:");
		lblContentType.setHorizontalAlignment(SwingConstants.TRAILING);
		lblContentType.setBounds(10, 111, 118, 14);
		panel.add(lblContentType);
		
		cboContentType = new JComboBox<String>();
		cboContentType.setToolTipText("A non editable combo box that displays the contentType mfield of the selected record.");
		cboContentType.setModel(new DefaultComboBoxModel<String>(new String[] {"application/json", "text/xml"}));
		cboContentType.setBounds(138, 105, 182, 20);
		panel.add(cboContentType);
		
		JLabel lblResponse = new JLabel("Response:");
		lblResponse.setBounds(10, 128, 118, 14);
		panel.add(lblResponse);
		
		
		response = new JTextArea(5, 20);
		response.setToolTipText("A non editable text area that displays the expected response message of the selected record.");
		response.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(response);
		scrollPane.setBounds(10, 146, 585, 187);
		panel.add(scrollPane);
		
		JLabel lblNewLabel_1 = new JLabel("Environment:");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.TRAILING);
		lblNewLabel_1.setBounds(10, 19, 108, 14);
		panel.add(lblNewLabel_1);
		
		cboEnvironment = new JComboBox<String>();
		cboEnvironment.setToolTipText("Non editable field to display the environment field of the selected record.");
		cboEnvironment.setModel(new DefaultComboBoxModel<String>(new String[] {"","qa", "prod"}));
		cboEnvironment.setBounds(138, 16, 90, 20);
		panel.add(cboEnvironment);
				
		table = new JTable();
		table.setAutoCreateRowSorter(true);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
			},
			new String[] {
				"Environment", "Payfone Environment", "Feature Name", "Scenario Name", "Content Type", "Expected Response"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(170);
		table.getColumnModel().getColumn(1).setPreferredWidth(168);
		table.getColumnModel().getColumn(2).setPreferredWidth(150);
		table.getColumnModel().getColumn(3).setPreferredWidth(200);
		table.getColumnModel().getColumn(4).setPreferredWidth(200);
		table.getColumnModel().getColumn(5).setPreferredWidth(300);
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent e) {
				try {
					cboEnvironment.setSelectedItem(table.getValueAt(table.getSelectedRow(), 0));
					cboPayfoneEnv.setSelectedItem(table.getValueAt(table.getSelectedRow(), 1).toString());
					txtFeature.setText(table.getValueAt(table.getSelectedRow(),2).toString());
					txtScenario.setText(table.getValueAt(table.getSelectedRow(), 3).toString());
					cboContentType.setSelectedItem(table.getValueAt(table.getSelectedRow(), 4).toString());
					response.setText(ResponseFileProcessor.responseFormatter(table.getValueAt(table.getSelectedRow(), 5).toString()));
				} catch (Exception e1) {
					txtFeature.setText("");
					txtScenario.setText("");
					response.setText("");
					e1.printStackTrace();
				}
				
			}
		});
		
		table.addMouseListener(new MouseListener() {
			public void mousePressed(MouseEvent mouseEvent) {
				JTable table = (JTable) mouseEvent.getSource();
				if (mouseEvent.getClickCount() == 2) {
					eventHandler.doUpdate();
	
				}
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
			
		JScrollPane scrlTableScroll = new JScrollPane(table);
		scrlTableScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrlTableScroll.setBounds(27, 370, 605, 334);
		frmResponseFileEditor.getContentPane().add(scrlTableScroll);
		
		JToolBar fileBar = new JToolBar();
		fileBar.setBounds(10, 0, 227, 23);
		frmResponseFileEditor.getContentPane().add(fileBar);
		
		btnOpen = new JButton("Open");
		btnOpen.setToolTipText("Displays a File Open dialog and opens the file selected.");
		btnOpen.setIcon(new ImageIcon(ResponseFileEditor.class.getResource("/toolbarButtonGraphics/general/Open16.gif")));
		btnOpen.addActionListener(eventHandler);
		fileBar.add(btnOpen);
		
		btnSave = new JButton("Save");
		btnSave.setToolTipText("Saves the current file.");
		btnSave.setEnabled(false);
		btnSave.setIcon(new ImageIcon(ResponseFileEditor.class.getResource("/toolbarButtonGraphics/general/Save16.gif")));
		btnSave.addActionListener(eventHandler);
		fileBar.add(btnSave);
		
		btnSaveAs = new JButton("Save As");
		btnSaveAs.setToolTipText("Saves the current file with a new name. Makes the new file the current file.");
		btnSaveAs.setEnabled(false);
		btnSaveAs.setIcon(new ImageIcon(ResponseFileEditor.class.getResource("/toolbarButtonGraphics/general/SaveAs16.gif")));
		btnSaveAs.addActionListener(eventHandler);
		fileBar.add(btnSaveAs);
		
		JToolBar editBar = new JToolBar();
		editBar.setBounds(235, 0, 237, 23);
		frmResponseFileEditor.getContentPane().add(editBar);
		
		btnCreate = new JButton("Create");
		btnCreate.setToolTipText("Displays the window to add a new record to the file.");
		btnCreate.setEnabled(false);
		btnCreate.setIcon(new ImageIcon(ResponseFileEditor.class.getResource("/toolbarButtonGraphics/general/New16.gif")));
		btnCreate.addActionListener(eventHandler);
		editBar.add(btnCreate);
		
		btnUpdate = new JButton("Update");
		btnUpdate.setToolTipText("Displayes the window with the selected record for editing.");
		btnUpdate.setEnabled(false);
		btnUpdate.setIcon(new ImageIcon(ResponseFileEditor.class.getResource("/toolbarButtonGraphics/general/Edit16.gif")));
		btnUpdate.addActionListener(eventHandler);
		editBar.add(btnUpdate);
		
		btnDelete = new JButton("Delete");
		btnDelete.setToolTipText("Deletes the selected record tfrom the table.");
		btnDelete.setEnabled(false);
		btnDelete.setIcon(new ImageIcon(ResponseFileEditor.class.getResource("/toolbarButtonGraphics/general/Delete16.gif")));
		btnDelete.addActionListener(eventHandler);
		editBar.add(btnDelete);
		
		
		menuBar = new JMenuBar();
		frmResponseFileEditor.setJMenuBar(menuBar);
		
		mnFile = new JMenu("File");
		mnFile.setMnemonic(KeyEvent.VK_F);
		menuBar.add(mnFile);
		
		mntmNew = new JMenuItem("New");
		mntmNew.setMnemonic(KeyEvent.VK_N);
		mntmNew.addActionListener(eventHandler);
		mnFile.add(mntmNew);
		
		mntmOpen = new JMenuItem("Open");
		mntmOpen.setMnemonic(KeyEvent.VK_O);
		mntmOpen.addActionListener(eventHandler);
		mnFile.add(mntmOpen);
		
		mntmClose = new JMenuItem("Close");
		mntmClose.setEnabled(false);
		mntmClose.setMnemonic(KeyEvent.VK_C);
		mntmClose.addActionListener(eventHandler);
		mnFile.add(mntmClose);
		
		mntmSave = new JMenuItem("Save");
		mntmSave.setEnabled(false);
		mntmSave.setMnemonic(KeyEvent.VK_S);
		mntmSave.addActionListener(eventHandler);
		mnFile.add(mntmSave);
		
		mntmSaveAs = new JMenuItem("Save As");
		mntmSaveAs.setEnabled(false);
		mntmSaveAs.addActionListener(eventHandler);
		mnFile.add(mntmSaveAs);
		
		JSeparator separator = new JSeparator();
		mnFile.add(separator);
		
		mntmExit = new JMenuItem("Exit");
		mntmExit.setMnemonic(KeyEvent.VK_X);
		mnFile.add(mntmExit);
		mntmExit.addActionListener(eventHandler);
		
		mnEdit = new JMenu("Edit");
		mnEdit.setMnemonic(KeyEvent.VK_E);
		menuBar.add(mnEdit);
		
		mntmCreate = new JMenuItem("Create");
		mntmCreate.setEnabled(false);
		mntmCreate.setMnemonic(KeyEvent.VK_C);
		mntmCreate.addActionListener(eventHandler);
		mnEdit.add(mntmCreate);
		
		mntmUpdate = new JMenuItem("Update");
		mntmUpdate.setEnabled(false);
		mntmUpdate.setMnemonic(KeyEvent.VK_U);
		mntmUpdate.addActionListener(eventHandler);
		mnEdit.add(mntmUpdate);
		
		mntmDelete = new JMenuItem("Delete");
		mntmDelete.setEnabled(false);
		mntmDelete.setMnemonic(KeyEvent.VK_D);
		mntmDelete.addActionListener(eventHandler);
		mnEdit.add(mntmDelete);
		
		mnSearch = new JMenu("Search");
		mnSearch.setMnemonic(KeyEvent.VK_S);
		menuBar.add(mnSearch);
		
		mntmFind = new JMenuItem("Find");
		mntmFind.setEnabled(false);
		mntmFind.addActionListener(eventHandler);
		mnSearch.add(mntmFind);
		
		mntmSort = new JMenuItem("Sort");
		mntmSort.setEnabled(false);
		mntmSort.addActionListener(eventHandler);
		mnSearch.add(mntmSort);
		
		mntmClearFilter = new JMenuItem("Clear Filter");
		mntmClearFilter.addActionListener(eventHandler);
		mnSearch.add(mntmClearFilter);
		
		mnOptions = new JMenu("Options");
		mnOptions.setMnemonic(KeyEvent.VK_0);
		menuBar.add(mnOptions);
		
		mnHelp = new JMenu("Help");
		mnHelp.setMnemonic(KeyEvent.VK_H);
		menuBar.add(mnHelp);
		
		mntmAbout = new JMenuItem("About");
		mntmAbout.addActionListener(eventHandler);
		mnHelp.add(mntmAbout);
		
	}
}
