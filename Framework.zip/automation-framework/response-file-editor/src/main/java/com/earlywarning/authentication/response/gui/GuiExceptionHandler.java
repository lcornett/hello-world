/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.response.gui;

import javax.swing.JOptionPane;

/**
 * A class that displays any Exception encountered. This is being used because 
 * there is not log.
 * @author cornettl
 *
 */
public class GuiExceptionHandler {
	
	/**
	 * THe method to display any Exception
	 * @param e An instance of a Throwable class
	 */
	public static void handleException(Throwable e) {
		String message = e.getClass().getName();
		message += "\n" + e.getLocalizedMessage(); 
		
		JOptionPane.showMessageDialog(null, message);
	}
}
