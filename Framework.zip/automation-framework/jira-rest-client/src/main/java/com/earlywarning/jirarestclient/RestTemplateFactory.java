package com.earlywarning.jirarestclient;

import org.apache.http.HttpHost;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * A class to used get an instance of the RestTemplate class. This class
 * is required to instantiate the Importer and Exporter classes.
 * @author cornettl
 *
 */
@Component
public class RestTemplateFactory implements FactoryBean<RestTemplate>, InitializingBean {
	RestTemplate restTemplate;

	public void afterPropertiesSet() throws Exception {
		HttpHost host = new HttpHost("https://jira.ews.int/rest/raven/1.0/export/test", 443, "https"); // this may have to be revisited
		restTemplate = new RestTemplate( new HttpComponentsClientHttpRequestFactoryBasicAuth(host));
		
	}

	public RestTemplate getObject() throws Exception {
		
		return restTemplate;
	}

	public Class<?> getObjectType() {
		
		return RestTemplate.class;
	}

	public boolean isSingleton() {
		return true;
	}
	
	
}
