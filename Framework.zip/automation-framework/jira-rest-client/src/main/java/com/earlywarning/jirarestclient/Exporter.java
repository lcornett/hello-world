/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.jirarestclient;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

/**
 * <p>A class to get the Tests/Test Sets from Jira-Xray.</p>
 * <p>This class has two properties that are instantiated by the 
 * Spring Framework:</p><ul>
 * 	<li>host</li>
 * 	<li>endpoint</li></ul>
 * <p>The values for these properties are in the application.properties
 * file. The endpoint property is the exportEndpoint property in the file.</p>
 * @author cornettl
 *
 */
@Slf4j
public class Exporter {
	private RestTemplateFactory factory;
	private String fileType;
	String outputDir = ".." + File.separator + "features";

	
	@Autowired
	HeaderCreator creator;
	
	@Value("${host}")
	String host;
	
	@Value("${exportEndpoint}")
	String endpoint;
	
	
	/**
	 * Constructor. 
	 * @param factory an instance of the RestTemplateFactory class.
	 */
	public Exporter (RestTemplateFactory factory) {
		this.factory = factory;
	}
		
	/**
	 * Executes the request to get the feature files. If more than one feature
	 * file exists, it will be in a file named FeatureBundle.zip. A single 
	 * feature will be placed in the features directory. The zip file will be 
	 * unzipped into the features directory. The FeatureBundle.zip will then be 
	 * deleted.
	 * @param issues A single string with a semicolon delimited list of Jira issues
	 * @throws Exception An instance of the Exception class
	 */
	public void executeRequest(String issues) throws Exception {
		URI uri = null;
		HttpHeaders headers = null;
		org.springframework.http.HttpStatus statusCode = null;
		String keys = "?keys="+issues;
		Map<String, String> headerMap = new HashMap<String, String>();
			
		try {
			clearFeatures();
			uri = new URI(host+endpoint+keys);
			ResponseEntity<byte[]> response = null;
			
			
			headerMap.put("Authorization", creator.encodeCreds());
			
			headers = creator.createHeaders(headerMap);
		
			RestTemplate template = factory.getObject();
			response = template.exchange(uri, HttpMethod.GET, new HttpEntity<byte[]>(headers), byte[].class);
			statusCode = response.getStatusCode();
			if (statusCode.value() == HttpStatus.SC_OK) {
				headers = response.getHeaders();
				String filename = getFileName(headers);
				fileType = filename.split("\\.")[1];
				
				// make sure output dir exists
				outputExists();
				filename =  outputDir + File.separator + filename;

				writeFile(response.getBody(), filename);
				
				if (fileType.equals("zip")) {
					unzip(filename, outputDir);
				}
			}
		} catch (URISyntaxException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	/**
	 * A method to get the file name form the headers. The file name is in the
	 * header named "Content-Disposition". If this header does not exist, the method
	 * will return null.
	 * @param headers The HttpHeaders retrieved from the response.
	 * @return The name of the file wo write.
	 */
	private String getFileName(HttpHeaders headers) {
		List<String> headerValue = null;
		String fileName = null;
		final String headername = "Content-Disposition";
		
		try {
			if (headers.containsKey(headername)) {
				headerValue = headers.get(headername);
				fileName = headerValue.get(0).substring(headerValue.get(0).indexOf("=")+2, headerValue.get(0).length()-1);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} 
		
		return fileName;		
	}
	
	/**
	 * Writes the response body to a file.
	 * @param body The body of the response.
	 * @param filename The name of the file to write to.
	 * @throws Exception 
	 */
	private void writeFile(byte[] body, String filename) throws Exception {
		
		try (FileOutputStream fos = new FileOutputStream(filename)) {
			fos.write(body);
			
			fos.flush();
			fos.close();
			
		} catch (FileNotFoundException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
			throw e;
		}
	}
	
	/**
	 * Unzips the FeatureBundle.zip file to the features directory. After unzipping the 
	 * file is deleted.
	 * @param zipFile The name of the zip file
	 * @param outputFolder The name of the folder to unzip to.
	 */
	private void unzip(String zipFile, String outputFolder) {
		byte[] buffer = new byte[1024];
		
		try {
			// create output dir if it doesn't exist
			File folder = new File(outputFolder);
			if(!folder.exists()) {
				folder.mkdir();
			}
			
			// get the zip file content
			FileInputStream fis = new FileInputStream(zipFile);
			ZipInputStream zis = new ZipInputStream(fis);
			
			// get the zip file list entry
			ZipEntry ze = zis.getNextEntry();
			
			while(ze!=null) {
				String filename = ze.getName();
				File newFile = new File(outputFolder + File.separator + filename);
				
				new File(newFile.getParent()).mkdirs();
				
				FileOutputStream fos = new FileOutputStream(newFile);
				
				int len;
				while ((len = zis.read(buffer)) > 0) {
					fos.write(buffer,  0,  len);
				}
				
				fos.close();
				ze = zis.getNextEntry();
			}
			
			zis.closeEntry();
			zis.close();
			fis.close();
			new File(zipFile).delete();
		} catch (IOException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
	}
	
	/**
	 * A method that ensures that the features directory exists
	 * before trying the write the feature files to the folder.
	 * If the folder does not exist, it will be created.
	 * @return If the dorectory exists, true otherwise false.
	 */
	private boolean outputExists() {
		boolean result = false;
		
		File dir = new File(outputDir);
		result = dir.exists(); 
		
		if(!result) {
			dir.mkdirs();
			result = true;
		}
		
		return result;
	}
	
	/**
	 * A method to remove all the files from the target directory.
	 */
	private void clearFeatures() {
		File folder = new File(outputDir);
		
		if (folder.exists()) {
			File[] files = folder.listFiles();
			for (File file : files) {
				if (!file.delete()) {
					// failed to delete the file
					log.info("Failed to delete " + file + ".");
				}
			} 
		} else {
			log.info("Cannot find the " + outputDir + " folder!");
		}
	
	}
	
}

