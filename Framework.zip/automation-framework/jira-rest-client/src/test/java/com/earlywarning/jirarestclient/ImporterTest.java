package com.earlywarning.jirarestclient;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class ImporterTest {
	private Importer importer;
	private RestTemplateFactory factory;
	
	@SuppressWarnings("unchecked")
	@Before
	public void setUp() throws Exception {
		HeaderCreator creator = mock(HeaderCreator.class);
		when(creator.encodeCreds()).thenReturn("String");
		
		ResponseEntity<String> response = mock(ResponseEntity.class);
		when(response.getStatusCode()).thenReturn(HttpStatus.OK);
		
		RestTemplate template = mock(RestTemplate.class);
		when(template.exchange(any(), any(), any(), eq(String.class))).thenReturn(response);
		
		factory = mock(RestTemplateFactory.class);
		factory.restTemplate = template;
		when(factory.getObject()).thenReturn(template);
		
		importer = new Importer(factory);	
		importer.creator = creator;
		String path = getClass().getClassLoader().getResource("sample.json").getPath().substring(1);
		importer.jsonLog = "jira-rest-client\\target\\test-classes\\sample.json";
		importer.host = "myhost";
		importer.endpoint = "https://earlywarning.com";
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testImporterNullFactory() {
		importer = new Importer(null);
		
		assertNotNull(importer);
		assertNull(importer.factory);
	}

	@Test
	public void testImporter() {
		importer = new Importer(factory);
		
		assertNotNull(importer);
	}

	@Test
	public void testExecute() throws Exception {
		importer.execute();
		assertTrue(true);
	}

	@Test(expected=IOException.class)
	public void testExecuteException() throws Exception {
		importer.jsonLog = "/logs/sample.json";
		importer.execute();
		assertTrue(true);
	}

}
