/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.xml;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Builder;
import lombok.Data;

/**
 * <p>A POJO that represents the name element of the Authentify XML 
 * request message.
 * This class utilizes the lombok Data and the lombok Builder 
 * annotations. The Data annotation provides the implementation
 * of the getters and setters for the private properties:<ul>
 * 	<li>firstName</li>
 * 	<li>lastName</li>
 * 	<li>middleName</li>
 * 	</ul>
 *  The Builder annotation provides a all argument constructor
 * as well as a &lt;class name&gt;Builder class.
 * <p>For additional information about these annotations, please see
 * <a href="{@docRoot}/com/earlywarning/authentication/xml/package-summary.html#tags">package-info</a> page.</p>
 *
 * @author cornettl
 *
 */
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Name {
	private String firstName;
	private String lastName;
    private String middleName;
}

