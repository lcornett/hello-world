/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import lombok.Data;

/**
 * A POJO that represents a row from the query on the SessionGroupData table.
 * This class utilizes the lombok.Data annotation to implement the getters 
 * and setters for the following class properties:<ul>
 * 	<li>sgid</li>
 * 	<li>tag</li>
 * 	<li>value</li>
 * 	<li>timestamp</li>
 * 	<li>sessionId</li></ul>
 * @author cornettl
 *
 */
@Data
public class SessionGroupDataRecord implements TableRecord {
	private String sgid, tag, value, timestamp;
}
