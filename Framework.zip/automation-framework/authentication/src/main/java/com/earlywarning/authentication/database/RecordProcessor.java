/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

/**
 * A class that contains methods to get a value from an Object that
 * implements the TableRecord interface. These objects are instances
 * of the following classes:<ul>
 * 	<li>SessionDataRecord</li>
 * 	<li>SessionFilesRecord</li>
 * 	<li>SessionGroupDataRecord</li>
 * 	<li>SessionInfoRecord</li>
 * 	<li>SessionInfoSoRecord</li>
 * 	<li>SessionResourcesRecord</li>
 * 	<li>VendorLinkRecord</li></ul>
 * @author cornettl
 *
 */

public class RecordProcessor {

	/**
	 * A method that retrieves a value from a property from 
	 * an instance of the SessionDataRecoed class.
	 * @param record An instance of the SessionDataRecord class.
	 * @param key The property name to get.
	 * @return The value of the property
	 */
	public String processSessionData(SessionDataRecord record, String key) {
		
		switch (key.toLowerCase()) {
			case "tag":
				return record.getTag();
			case "sessionid":
				return record.getSessionId();
			case "timestamp":
				return record.getTimestamp();
			case "value":
				return record.getValue();
		}
		
		throw new IllegalArgumentException("Key '" + key + "' not found in SessionDataRecord.");
	}
	
	/**
	 * A method that retrieves a value from a property from
	 * an instance of the SessionFilesRecord class.
	 * @param record An instance of the SessionFilesRecord class.
	 * @param key The name of the property to get.
	 * @return The value of the property
	 */
	public String processSesionFiles(SessionFilesRecord record, String key) {
		
		switch (key.toLowerCase()) {
			case "filename":
				return record.getFileName();
			case "format":
				return record.getFormat();
			case "id":
				return record.getId();
			case "length":
				return record.getLength();
			case "location":
				return record.getLocation();	
			case "processed":
				return record.getProcessed();
			case "sessionid":
				return record.getSessionId();
			case "timestamp":
				return record.getTimestamp();
			case "type":
				return record.getType();
		}
		
		throw new IllegalArgumentException("Key '" + key + "' not found in SessionFilesRecord.");
	}
	
	/**
	 * A method that retrieves a value from a property from
	 * an instance of the SessionGroupDataRecord class.
	 * @param record An instance of the SessionGroupDataRecord class.
	 * @param key The name of the property to get.
	 * @return The value of the property
	 */
	public String processGroupData(SessionGroupDataRecord record, String key) {
		
		switch (key.toLowerCase()) {
			case "sgid":
				return record.getSgid();
			case "tag":
				return record.getTag();
			case "timestamp":
				return record.getTimestamp();
			case "value":
				return record.getValue();
		}
		
		throw new IllegalArgumentException("Key '" + key + "' not found in SessionGroupDataRecord.");
	}
	
	/**
	 * A method that retrieves a value from a property from
	 * an instance of the SessionInfoRecord class.
	 * @param record An instance of the SessionInfoRecord class.
	 * @param key The name of the property to get.
	 * @return The value of the property
	 */
	public String processSessionInfo(SessionInfoRecord record, String key) {
		
		switch (key.toLowerCase()) {
			case "accountid":
				return record.getAccountId();
			case "action":
				return record.getAction();
			case "state":
				return record.getState();
			case "status":
				return record.getStatus();
		}
		
		throw new IllegalArgumentException("Key '" + key + "' not found in SessionInfoRecord.");
	}
	
	/**
	 * A method that retrieves a value from a property from
	 * an instance of the SessionInfoSoRecord class.
	 * @param record An instance of the SessionInfoSoRecord class.
	 * @param key The name of the property to get.
	 * @return The value of the property
	 */
	public String processSessionInfoSo(SessionInfoSoRecord record, String key) {
		
		switch (key.toLowerCase()) {
			case "asid":
				return record.getAsId();
			case "phonenumber":
				return record.getPhoneNumber();
			case "sessionid":
				return record.getSessionId();
			case "sessiontag":
				return record.getSessionTag();
			case "timestamp":
				return record.getTimestamp();
		}
		
		throw new IllegalArgumentException("Key '" + key + "' not found in SessionInfoSoRecord.");
	}
	
	/**
	 * A method that retrieves a value from a property from
	 * an instance of the SessionResourcesRecord class.
	 * @param record An instance of the SessionResourcesRecord class.
	 * @param key The name of the property to get.
	 * @return The value of the property
	 */
	public String processSessionResources(SessionResourcesRecord record, String key) {
		
		switch (key.toLowerCase()) {
			case "hashphone":
				return record.getHashphone();
			case "resourceid":
				return record.getResourceid();
			case "status":
				return record.getStatus();
			case "subtype":
				return record.getSubtype();
            case "typeid":
                return record.getTypeid();
            case "registrar":
                return record.getRegistrar();
            case "duration":
                return record.getDuration();
		}
		
		throw new IllegalArgumentException("Key '" + key + "' not found in SessionResourcesRecord.");
	}
	
	/**
	 * A method that retrieves a value from a property from
	 * an instance of the VendorLinkRecord class.
	 * @param record An instance of the VendorLinkRecord class.
	 * @param key The name of the property to get.
	 * @return The value of the property
	 */
	public String processVendorLink(VendorLinkRecord record, String key) {
		switch (key.toLowerCase()) {
			case "accountid":
				return record.getAccountId();
			case "externalguid":
				return record.getExternalGuid();
			case "internalguid":
				return record.getInternalGuid();
			case "phonenumber":
			case "vendorlink.phonenumber":
				return record.getPhoneNumber();
			case "soid":
				return record.getSoid();		
		}
		
		throw new IllegalArgumentException("Key '" + key + "' not found in SessionInfoRecord.");
	}

    /**
     * A method that retrieves a value from a property from
     * an instance of the ResponsiveWebRecord class.
     * @param record An instance of the ResponsiveWebRecord class.
     * @param key The name of the property to get.
     * @return The value of the property
     */
    public String processResponsiveWeb(ResponsiveWebRecord record, String key) {
        switch (key.toLowerCase()) {
            case "name":
                return record.getName();
            case "code":
                return record.getCode();
            case "status":
                return record.getStatus();
        }

        throw new IllegalArgumentException("Key '" + key + "' not found in ResponsiveWebRecord.");
    }


}
