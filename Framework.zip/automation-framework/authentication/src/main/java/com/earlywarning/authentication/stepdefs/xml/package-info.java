/**
 * 
 */
/**
 * In order to completely test the Authentify applications, the need exists tto verify the legacy implementation
 * which was written to handle XML messages as well as JSON messages. 
 * To do this, step definitions that are similar to but different from the step definitions that deal with the JSON
 * messages need to be defined. It is important to note that the tests will be the same, just the message format 
 * will be changed.
 * @author cornettl
 *
 */
package com.earlywarning.authentication.stepdefs.xml;