/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.xml;

import lombok.Data;

/**
 * A POJO that represents the header element of the AuthentXML response message. This class
 * uses the lombok Data annotation which provides the getter and setter method implementations
 * for the private properties.
 * @author cornettl
 *
 */
@Data
public class ResponseHeader {
	private String tsoid;
	private String application;
	private String account;
	private String asid;
	private String sgid;
	private String teid;
	private String replyTo;
	private String timestamp;
}
