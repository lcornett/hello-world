/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.utils;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import lombok.extern.log4j.Log4j2;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;

/**
 * A class that gets, calculates and formats dates for the framework.
 * @author cornettl
 *
 */
@Log4j2
public class DateUtils {

	/**
	 * Gets todays date in the format: yyyy-mm-dd
	 * @return Todays date.
	 */
	public static String getToday() {
		LocalDate ld = LocalDate.now();
		
		return ld.toString();
	}
	
	/**
	 * Gets the date calculated by adding the number of days specified in the parameter.
	 * The data is returned in the format: yyyy-mm-dd
	 * @param offset The number of days to add.
	 * @return The calculated date.
	 */
	public static String getDate(long offset) {
		String result = null;
		LocalDate ld = LocalDate.now();
		ld = ld.plus(offset, ChronoUnit.DAYS);
		result = ld.toString();
		return result;
		
	}
	
	/**
	 * Gets todays date in the format: yyyy-mm-dd hh:mi:ss.nnn
	 * @return Todays formatted date.
	 */
	public static String getLongToday() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
		LocalDate ld = LocalDate.now();
		LocalDateTime ldt = LocalDateTime.of(ld, LocalTime.MIDNIGHT);
		String result = ldt.format(formatter);
		return result;
	}
	
	/**
	 * Gets the current UTC date/time in the format:  yyyy-mm-dd hh:mi:ss.nnn
	 * @return The current UTC date/time.
	 */
	public static String getUTC() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyy-MM-dd HH:mm:ss.SSS");
		ZonedDateTime zdc;
		LocalDateTime ldt = LocalDateTime.now(ZoneOffset.UTC);
		zdc = ldt.atZone(ZoneId.of("UTC"));
		ldt = LocalDateTime.from(zdc);
		String result = ldt.format(formatter);
		return result;
	}
	
	/**
	 * Gets the current UTC date/time in the ISO8601 format
	 * @return The current UTC date/time in the ISO8601 format
	 */
	public static String getISO8601() {
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
		ZonedDateTime zdc;
		LocalDateTime ldt = LocalDateTime.now(ZoneOffset.UTC);
		zdc = ldt.atZone(ZoneId.of("UTC"));
		ldt = LocalDateTime.from(zdc);
		String result = ldt.format(formatter);
		return result;
	}

	/**
	 * Gets the current date in the format specified by the param.
	 * @param format The format to us for the date. 
	 * @return Todays date.
	 */
	public static String getFormattedToday(String format) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
		LocalDate ld = LocalDate.now();
		LocalDateTime ldt = LocalDateTime.of(ld, LocalTime.MIDNIGHT);
		String result = ldt.format(formatter);
		return result;

	}
	
	/**
	 * A method that calculates the difference between two LocalDateTime objects.
	 * and returns the difference in milliseconds.
	 * @param start The starting dateTime in ISO8601 format.
	 * @return The difference between the start time and the now time.
	 */
	public static long getDiff(String start) {
		String now = getISO8601();
		long result = 0;
		
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
			LocalDateTime dateTime = LocalDateTime.parse(now);
			LocalDateTime lesser = LocalDateTime.parse(start);
			
			System.out.println(dateTime);
			
			result = Duration.between(dateTime, lesser).toMillis();
		} catch (Exception e) {
			log.warn(e.getClass() + " " + e.getMessage());
		}
		return Math.abs(result);
	}
	
	public static void main(String[] args) {
		System.out.println(getToday());
		System.out.println(getLongToday());
		System.out.println(getDate(5));
		System.out.println(getUTC());
		System.out.println(getFormattedToday("yyyy_MM_dd"));
	}
}

