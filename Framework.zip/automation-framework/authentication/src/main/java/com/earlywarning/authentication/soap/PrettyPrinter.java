/**
 * Copyright (c) 2018 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.soap;

import java.io.ByteArrayOutputStream;

import javax.xml.soap.SOAPMessage;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

import lombok.extern.log4j.Log4j2;

/**
 * A utility class that formats a SOAP message according to the apache standard.
 * @author cornettl
 *
 */
@Log4j2
public class PrettyPrinter {
	
	/**
	 * The method of the class that performs the message formatting.
	 * @param message The message to be formatted.
	 * @return The formatted message as a string.
	 */
	public static String getPrettyMessage(SOAPMessage message) {
		try {
			TransformerFactory tff = TransformerFactory.newInstance();
			Transformer tf = tff.newTransformer();
			
			tf.setOutputProperty(OutputKeys.INDENT,	"yes");
			tf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

			Source sc = message.getSOAPPart().getContent();
			
			ByteArrayOutputStream streamOut = new ByteArrayOutputStream();
			StreamResult result = new StreamResult(streamOut);
			tf.transform(sc, result);
			
			String strMessage = streamOut.toString();
			return strMessage;
			
		}  catch (Exception e) {
	         log.error(e.getMessage());
	         log.debug(e.getMessage(), e);
	          return null;
	    }
	}

}
