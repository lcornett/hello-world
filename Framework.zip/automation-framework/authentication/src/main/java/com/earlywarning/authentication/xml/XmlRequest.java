/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.xml;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import lombok.Builder;
import lombok.Data;

/**
 * <p>A POJO representing the request element of the Authentify XML request message.
 * This class uses the lombok Data annotation which provides the getters and setters
 * for the private property</p><ul><li>data</li>
 * <li>action</li>
 * <li>delay</li></ul>
 * <p>For additional information about the annotation, please see the 
 * <a href="{@docRoot}/com/earlywarning/authentication/xml/package-summary.html#tags">package-info</a> page.</p>
 *
 * @author cornettl
 *
 */
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class XmlRequest {
	@JacksonXmlProperty(localName="data xmlns:dat=\"http://xml.authentify.net/CommonDataSchema.xml\"", isAttribute=true)
	private RequestData data;
	private String action;
    private String delay;
}

