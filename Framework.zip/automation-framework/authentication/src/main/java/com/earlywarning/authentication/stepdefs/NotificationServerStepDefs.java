/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.stepdefs;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import com.earlywarning.authentication.applogs.LogValidator;
import com.earlywarning.authentication.applogs.LoggerMapper;
import com.earlywarning.authentication.applogs.MsLogParser;
import com.earlywarning.authentication.common.ApiDriver;
import com.earlywarning.authentication.common.StoredParams;
import com.earlywarning.authentication.notificationserver.MessageVerifier;
import com.earlywarning.authentication.notificationserver.Request;
import com.earlywarning.authentication.notificationserver.RequestCreator;
import com.earlywarning.authentication.startup.Env;
import com.earlywarning.authentication.utils.DateUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.DataTable;
import cucumber.api.java8.En;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;

/**
 * This class contains the step definitions that are unique to the NotificationServer feature.
 * This does not mean that these step definitions cannot be used in other contexts, just that
 * thgey were developed for the NotificationServer feature. 
 * The step definitions implemented are listed below:
 * <table class="memberSummary" border="0" cellpadding="3" cellspacing="0" summary="Test">
 * <caption><span>Notification Server Step Definitions</span><span class="tabEnd">&nbsp;</span></caption>
 * <tr>
 * <th class="colFirst" scope="col">Step Definition</th>
 * <th class="colOne" scope="col">Usage</th>
 * <th class="colLast" scope="col">Description</th></tr>
 * <tbody>
 * <tr class="altColor">
 * <td class="colFirst"><code>Given the notification request has the values</code></td>
 * <td class="colOne">Creates a JSON request specific to the Notification Server. The fields for this request may be found in the Java Docs for the
 * com.earlywarning.authentication.notificationserver.RequestCreator class</td>
 * <td class="colLast"><div class="block">This step definition uses a data table that contains the message elements and thrie values to create the message.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Given the following notification request</code></td>
 * <td class="colOne">The message is sandwiched between three quotes (e.g., """ message """). The sets of quotes may be on their own line.</td>
 * <td class="colLast"><div class="block">This step definition accepts a preformatted JSON message.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Given the current date/time is stored.</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">Gets the current date/time in UTC format and stores it for future use.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>When the notification request is sent</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">Sends the notification request to the endpoint.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>When the notification request is sent for http status</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">Sends the notification request. Allows the http status to be captured and compared to an
 * expected status.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then the https status is &lt;number&gt;</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">Gets the actual http status and compares it to an expected status.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then verify the SMS is delivered</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">Executes the code that verifies the SMS message was delivered. See the MessageVerifier.smsVerifier() method.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then verify the SMS is not delivered</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">Executes the same code as above but performs different assertion</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then verify the http status is &lt;number&gt;</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">Verifies the http status.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then verify the response status = &lt;number&gt;</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">Verifies the message response status.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then verify the response clientContext = &lt;string&gt;</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">Gets the clientContext from the response and compares it the the parameter.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then verify the email was delivered</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">Verifies the email was delivered by checking the inbox.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then verify the message server log values;</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">Uses a data table containing the field names and their values. If the field is the clientContext only the length of the value is validated.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then verify message server log response status = &lt;number&gt;</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">Verifies the response status of the POST message is equal to the expected value</div></td>
 * </tr>

 * </tbody></table>
 *
 * @author cornettl
 *
 */
@Log4j2
public class NotificationServerStepDefs implements En {
	private static Request request;
	private static ApiDriver apiDriver;
	private static ObjectMapper mapper = new ObjectMapper();
	private static String jsonRequest;
	
	public NotificationServerStepDefs() {
		Given("^the notification request has the values$", (DataTable data) -> {
			Map<String, String> map = data.asMap(String.class, String.class);
			request = RequestCreator.createRequest(map);			
		});
		
		Given("^the following notification request$", (String json) -> {
		    jsonRequest = json;

		});
		
		Given("^the current date/time is stored$", () -> {
			String utc = DateUtils.getUTC();
			StoredParams.store("date", utc);
			//throw new PendingException();
		});
		
		When("^the notification request is sent$", () -> {
			String jsonString = null;
			String contentType = "application/json";
			String environment = Env.getProperty("environment");
			String url = Env.getProperty(environment+"NotificationEndpoint");
			apiDriver = new ApiDriver(contentType, url);
			
			try {
				if (null == jsonRequest) {
					jsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
				} else {
					jsonString = jsonRequest;
					jsonRequest = null;
				}
				log.info("The request being sent is:\n" + jsonString);					

				apiDriver.setBody(jsonString);
				apiDriver.post();
			} catch (JsonProcessingException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		});
		
		When("^the notification request is sent for http status$", () -> {
			String jsonString = null;
			String contentType = "application/json";
			String environment = Env.getProperty("environment");
			String url = Env.getProperty(environment+"NotificationEndpoint");
			apiDriver = new ApiDriver(contentType, url);
			
			try {
				if (null == jsonRequest) {
					jsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
				} else {
					jsonString = jsonRequest;
					jsonRequest = null;
				}
				log.info("The request being sent is:\n" + jsonString);					

				apiDriver.setBody(jsonString);
				apiDriver.post(true);
			} catch (JsonProcessingException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		});

		
		Then("^the httpStatus is (\\d+)$", (Integer expected) -> {
			int status = ApiDriver.getHttpStatus();
			String msg = "";
			if (expected == status) {
				msg = "The actual and the expected httpStatus were " + status +".";
			} else {
				msg = "The actual status code from the server was " + status + ". The expected code was " + expected + ".";
			}
			log.info(msg);
			assertTrue(expected == ApiDriver.getHttpStatus());
		});

		Then("^verify the SMS is delivered$", () -> {
		    MessageVerifier mv = new MessageVerifier();
		    try {
				assertTrue(mv.smsVerifier());
			} catch (InterruptedException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		    
		});
		
		Then("^verify the SMS is not delivered$", () -> {
			String step = "Then verify the SMS is not delivered.";
		    String msg = step + " is a manual step and cannot be automated at this time.";
		    log.info(msg);
		    
		    MessageVerifier mv = new MessageVerifier();
		    try {
				assertFalse(mv.smsVerifier());
			} catch (InterruptedException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}

		});


		Then("^verify short code on device is (\\d+)$", (Integer shortCode) -> {
		    MessageVerifier mv = new MessageVerifier();
		    assertTrue(mv.verifyShortCode(shortCode));
		    
		});

		Then("^verify httpStatus is (\\d+)$", (Integer httpStatus) -> {
			String msg = "";
			boolean result = false;
			
			if (httpStatus == ApiDriver.getHttpStatus()) {
				msg = "The actual and expected http statusCode is " + httpStatus + ".";
				result = true;
			} else {
				msg = "The actual httpStatus is " + ApiDriver.getHttpStatus() + " and the expected httpStatus is" + httpStatus + ".";
				
			}
			
			log.info(msg);
			assertTrue(result);
		});

		Then("^verify response status = \"([^\"]*)\"$", (String expectedStatus) -> {
			boolean result = false;
			String msg = "";
			Response response = ApiDriver.getResp();
			String actualStatus = ApiDriver.retrieveJsonValueString(response, "status");
			
			if (actualStatus.equals(expectedStatus)) {
				result = true;
				msg = "The value of status element in the response and the expected value are both " + expectedStatus +".";
			} else {
				msg = "The actual status element value is " + actualStatus +". The expected value is "  + expectedStatus + ".";
			}
			log.info(msg);
			assertTrue(result);
		});

        Then("^verify response clientContext = \"([^\"]*)\"$", (String expectedStatus) -> {
            boolean result = false;
            String msg = "";
            Response response = ApiDriver.getResp();
            String actualStatus = ApiDriver.retrieveJsonValueString(response, "clientContext");

            if (actualStatus.equals(expectedStatus)) {
                result = true;
                msg = "The value of clientContext element in the response and the expected value are both " + expectedStatus +".";
            } else {
                msg = "The actual clientContext element value is " + actualStatus +". The expected value is "  + expectedStatus + ".";
            }
            log.info(msg);
            assertTrue(result);
        });

		When("^verify the email was delivered$", () -> {
			
			MessageVerifier mv = new MessageVerifier();
			try {
				assertTrue(mv.verifyEmail());
			} catch (InterruptedException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);			}
		});
		
		Then("^verify the message server log values$", (DataTable arg1) -> {
			Map<String, String> map = arg1.asMap(String.class, String.class);
			
			assertTrue(new LogValidator().validatePost(map));
		});
		
		Then("^verify message server log response status = (\\d+)$", (Integer status) -> {
		    assertTrue(new LogValidator().validatePostResponseStatus(status));
		});

		
	}

}
