/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.ccv;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/**
 * A POJO that represents the MobileIdentityMatshConfidence object of the CCVResponse.
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_EMPTY)
public class MobileIdentityMatchConfidence {
	private String name;
	private String address;
	private String email;
}
