/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

/**
 * This is an Interface for the POJOs of the database package  to inherit. This 
 * interface identifies no functionality or properties but is solely for the 
 * purpose of grouping all of the table record classes together.
 * @author cornettl
 *
 */
public interface TableRecord {
	
}
