/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import com.earlywarning.authentication.common.ApiDriver;
import com.earlywarning.authentication.common.Request;
import com.earlywarning.authentication.startup.Env;
import com.earlywarning.authentication.stepdefs.CommonStepDefs;
import lombok.extern.log4j.Log4j2;

import java.sql.*;
import java.util.ArrayList;

/**
 * A class that querries the database and creates a HashMap out of the ResultSet.
 * The HashMap can then be used to validate the test case using the DataValidator.
 * @author cornettl
 *
 */
@Log4j2
public class ResultSetCreator {
	private String teid;
	
	/**
	 * No argument constructor for the class
	 */
	public ResultSetCreator() {
		
	}
	
	/**
	 * A one argument constructor for the class. The argument for this
	 * constructor comes from the Rest response. If the response is JSON
	 * the argument is the ewSID, if XML the argument is the teid.
	 * @param teid The appropriate identifier from the response.
	 */
	public ResultSetCreator(String teid) {
		this.teid = teid;
	}
	
	/**
	 * The method to get a result set. This takes an argument based on the
	 * system that is being tested. (Currently only 'Payfone' is supported.
	 * @return A map of the result set. This only has the data for the query 1 of the workbook test cases.
	 */
	public ArrayList<TableRecord> getResultSet() {
		Connection conn = null;
		String sessionId = null;	
		String sgid = null;
		String sessionIdQuery = "select sessionId, sgid from sessioninfo where teid = '" + teid + "'"; 
		String[] querries = Query.QUERY1.getStatements();
		ResultSet rs = null;
		PreparedStatement stmt = null;
		ArrayList<TableRecord> records = new ArrayList<TableRecord>();
	
		
		try {
			conn = DataSource.getInstance(DatabaseMapper.getDatabase()).getBds().getConnection();
			rs = execute(conn, sessionIdQuery);
			if (rs.next()) {
				sessionId = rs.getString("sessionId");
				sgid = rs.getString("sgid");
			} else {
				return null;
			}
			
			for (String query : querries) {
				int start = query.indexOf("from")+5;
				int end = query.indexOf(" ", start);
				String tableName = query.substring(start, end);
				if (query.contains("sessionid")) {
					stmt = conn.prepareStatement(query);
					stmt.setString(1, sessionId);
					rs = stmt.executeQuery();
				} else if (query.contains("sgid")) {
					stmt = conn.prepareStatement(query);
					stmt.setString(1, sgid);
					rs = stmt.executeQuery();

				}
				while (rs.next()) {
					switch (tableName.toLowerCase()) {
						case "sessiondata":
							SessionDataRecord data = new SessionDataRecord();
							data.setTag(rs.getString("tag"));
							data.setValue(rs.getString("value"));
							data.setTimestamp(rs.getString("timestamp"));
							data.setSessionId(rs.getString("SessionID"));
							records.add(data);
							break;
						case "sessionfiles":
							SessionFilesRecord files = new SessionFilesRecord();
							files.setId(rs.getString("ID"));
							files.setFileName(rs.getString("fileName"));
							files.setLocation(rs.getString("location"));
							files.setFormat(rs.getString("format"));
							files.setLength(rs.getString("length"));
							files.setType(rs.getString("type"));
							files.setProcessed(rs.getString("processed"));
							files.setTimestamp(rs.getString("timestamp"));
							files.setSessionId(rs.getString("SessionID"));
							records.add(files);
							break;	
						case "sessiongroupdata":
							SessionGroupDataRecord groupData = new SessionGroupDataRecord();
							groupData.setSgid(rs.getString("sgid"));
							groupData.setTag(rs.getString("tag"));
							groupData.setValue(rs.getString("value"));
							groupData.setTimestamp(rs.getString("timestamp"));
							records.add(groupData);
							break;
						case "sessioninfo":
							SessionInfoRecord record = new SessionInfoRecord();
							record.setState(rs.getString("state"));
							record.setStatus(rs.getString("status"));
							record.setAction(rs.getString("action"));
							record.setAccountId(rs.getString("accountId"));
							records.add(record);
							break;
						case "sessioninfoso":
							SessionInfoSoRecord infoSo = new SessionInfoSoRecord();
							infoSo.setAsId(rs.getString("asID"));
							infoSo.setPhoneNumber(rs.getString("phoneNumber"));
							infoSo.setSessionId(rs.getString("SessionID"));
							infoSo.setTimestamp(rs.getString("timestamp"));
							infoSo.setSessionTag(rs.getString("SessionTag"));
							records.add(infoSo);
							break;
						case "sessionresources":
							SessionResourcesRecord resources = new SessionResourcesRecord();
							resources.setResourceid(rs.getString("resourceid"));
							resources.setStatus(rs.getString("status"));
							resources.setHashphone(rs.getString("hashphone"));
							resources.setSubtype(rs.getString("subtype"));
                            resources.setTypeid(rs.getString("typeid"));
                            resources.setRegistrar(rs.getString("registrar"));
                            resources.setDuration(rs.getString("duration"));
							records.add(resources);
							break;
					}		
				}
			}
			
		} catch (SQLException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		}
		return records;
	}
	
	/**
	 * A method to get the vendorlink data from the database.
	 * @return A map of the result set. This only has the data for the query 2 of the workbook test cases
	 */
	public ArrayList<TableRecord> getVendorLinkData() {

		
		String phoneNumber = null;
		String internalGuid = null;
		ResultSet rs = null;
		PreparedStatement stmt = null;
		Connection conn = null;
		String query = null;
		ArrayList<TableRecord> localResultSet = new ArrayList<TableRecord>();
		String contentType = ApiDriver.getResp().contentType();
		
		if (contentType.contains("json")) {
			phoneNumber = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), "data.phoneNumber");
			internalGuid = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), "data.ewDeviceId");
		} else if (contentType.contains("xml")) {
			phoneNumber = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//phoneNumber/text()");
			internalGuid = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//ewDeviceId/text()");
		}
		
		if (phoneNumber.isEmpty() && (!internalGuid.isEmpty())) {
			query = "select * from vendorlink where internalGUID = '" + internalGuid +"'";
		} else if ((!phoneNumber.isEmpty()) && (!internalGuid.isEmpty())) {
			query = "select * from vendorlink where phoneNumber = '" + phoneNumber + "' and internalGuid = '" + internalGuid + "'";
		}
		
		try {
			conn = DataSource.getInstance(DatabaseMapper.getDatabase()).getBds().getConnection();

			stmt = conn.prepareStatement(query);
			
			rs = stmt.executeQuery();

			while (rs.next()) {
				VendorLinkRecord vendorLink = new VendorLinkRecord();
				vendorLink.setInternalGuid(rs.getString("InternalGUID"));
				vendorLink.setSoid(rs.getString("SOID"));
				vendorLink.setAccountId(rs.getString("AccountID"));
				vendorLink.setPhoneNumber(rs.getString("phoneNumber"));
				vendorLink.setExternalGuid(rs.getString("ExternalGUID"));
				localResultSet.add(vendorLink);
			}	
		} catch (SQLException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		}
		
		return localResultSet;		

	}

    /**
     * A method to get the ResponsiveWeb data from the database.
     * @return A map of the result set. This only has the data for the query 1 of the workbook test cases
     */
    public ArrayList<TableRecord> getResponsiveData() {

        String userId = "";
        String environment = Env.getProperty("environment");
        Request request = CommonStepDefs.getRequest();
        userId =request.getUser().getUserId();

        ArrayList<TableRecord> localResultSet = new ArrayList<TableRecord>();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Connection conn = null;
        String query = null;

        if(!userId.isEmpty()){
            query = "select * from DeviceUsers where Name = N'" + userId +"' order by DateModified desc";
        }

        try {
            Thread.sleep(1000);
            if(environment.equals("qa")){
                conn = DataSource.getInstance("register01").getBds().getConnection();
                stmt = conn.prepareStatement(query);
                rs = stmt.executeQuery();
            }
            if(environment.equals("prod")){
                conn = DataSource.getInstance("register").getBds().getConnection();
                stmt = conn.prepareStatement(query);
                rs = stmt.executeQuery();
            }
            if(environment.equals("dev")){
                conn = DataSource.getInstance("register05").getBds().getConnection();
                stmt = conn.prepareStatement(query);
                rs = stmt.executeQuery();
            }


            ResponsiveWebRecord responsiveWebRecord = new ResponsiveWebRecord();
               rs.next();
               responsiveWebRecord.setName(rs.getString("Name"));
               responsiveWebRecord.setStatus(rs.getString("Status"));
               responsiveWebRecord.setCode(rs.getString("Code"));
               localResultSet.add(responsiveWebRecord);

        } catch (SQLException e) {
            log.error(e.getMessage());
            log.debug(e.getMessage(), e);
        } catch (Exception e) {
            log.error(e.getMessage());
            log.debug(e.getMessage(), e);
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
                log.error(e.getMessage());
                log.debug(e.getMessage(), e);
            }
        }
        return localResultSet;

    }
	
	
	/**
	 * A method the execute the query provided on the connection provided.
	 * @param conn A valid database connection.
	 * @param query The query to execute.
	 * @return The query's ResultSet
	 */
	private ResultSet execute(Connection conn, String query) {	
		ResultSet rs = null;
		
		try {
			Statement stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
		} catch (SQLException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		return rs;

	}

	/**
	 * @return the teid
	 */
	public String getTeid() {
		return teid;
	}

	/**
	 * @param teid the teid to set
	 */
	public void setTeid(String teid) {
		this.teid = teid;
	}
	
	
	

}
