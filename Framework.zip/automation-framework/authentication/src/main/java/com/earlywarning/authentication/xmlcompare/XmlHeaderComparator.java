/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.xmlcompare;

import com.earlywarning.authentication.jsoncompare.StringComparator;
import com.earlywarning.authentication.xml.ResponseHeader;

/**
 * A class that compares the values of similar elements between two
 * header elements in an AuthentXml response message.
 * @author cornettl
 *
 */
class XmlHeaderComparator extends StringComparator {
	
	/**
	 * A method to compare the values of header elements that are expected to be the same.
	 * The elements that are not expected to be the same, such as the teid or the timestamp
	 * elements are not compared.
	 * @param expected An instance of the ResponseHeader class
	 * @param actual An instance of the ResponseHeader class
	 * @return true if the headers match, false otherwise
	 */
	public boolean compare(ResponseHeader expected, ResponseHeader actual) {
		String actualValue;
		String expectedValue;		
		String[] keys = {"tsoid", "asid", "application", "account"};
		
		try {
			for (String key : keys) {
				switch (key) {
					case "account":
						expectedValue = expected.getAccount();
						actualValue = actual.getAccount();
						updateStatus(compareString(key, expectedValue, actualValue));
						break;
					case "application":
						expectedValue = expected.getApplication();
						actualValue = actual.getApplication();
						updateStatus(compareString(key, expectedValue, actualValue));
						break;
					case "asid":
						expectedValue = expected.getAsid();
						actualValue = actual.getAsid();
						updateStatus(compareString(key, expectedValue, actualValue));
						break;
					case "tsoid":
						expectedValue = expected.getTsoid();
						actualValue = actual.getTsoid();
						updateStatus(compareString(key, expectedValue, actualValue));
						break;						
				}
			}
		} finally {
			
		}
		return status;
	}
}
