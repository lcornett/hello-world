/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.xmlcompare;

import com.earlywarning.authentication.jsoncompare.StringComparator;
import com.earlywarning.authentication.xml.XmlStatus;

/**
 * A class that compares the status element of an AuthentXML response message.
 * @author cornettl
 *
 */
class XMLStatusComparator extends StringComparator {
	
	/**
	 * The method that implements the comparison of the status element of two
	 * AuthentXML response messages.
	 * @param expected The element to compare to.
	 * @param actual The element to compare.
	 * @return true if the element values match, false otherwise.
	 */
	public boolean compare(XmlStatus expected, XmlStatus actual) {
		String expectedValue = expected.getStatusCode();
		String actualValue = actual.getStatusCode();
		updateStatus(compareString("statusCode", expectedValue, actualValue));		
		
		return status;
	}
}
