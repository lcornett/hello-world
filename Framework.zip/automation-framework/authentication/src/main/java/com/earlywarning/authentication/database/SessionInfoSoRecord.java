/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import lombok.Data;

/**
 * A POJO that represents a row of data from the query on the SessionInfoSo table.
 * This class utilizes the lombok.Data annotation which provides the implementation
 * of the getters and setters for the following class proerties:<ul>
 * 	<li>phoneNumber</li>
 * 	<li>asID</li>
 * 	<li>sessionTag</li>
 * 	<li>timestamp</li>
 *  <li>sessionId</li></ul>
 * @author cornettl
 *
 */
@Data
public class SessionInfoSoRecord implements TableRecord {
	private String phoneNumber, asId, sessionTag, timestamp, sessionId;
}
