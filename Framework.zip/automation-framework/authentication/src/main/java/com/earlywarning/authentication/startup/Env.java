/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.startup;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.earlywarning.authentication.utils.FileFinder;

import lombok.extern.log4j.Log4j2;

/**
 * A class that reads in the environment.properties file and keeps those properties available
 * for future use. All the methods of this class are static.
 * @author cornettl
 *
 */
@Log4j2
public class Env {
	private static Properties props = new Properties();
	private static String propsFile; 
	
	/**
	 * Loads the environment.properties and the data&configuration.properties files
	 */
	static {
		if (props.isEmpty()) {
			propsFile = FileFinder.find("environment.properties");
			try {	
				InputStream in = new FileInputStream(propsFile);
				props.load(in);
				in.close();
				
				propsFile = FileFinder.find("config-data.properties");
				in = new FileInputStream(propsFile);
				props.load(in);
				in.close();
				setEnvironment();
			} catch (IOException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			} 
		}
	}
	 
	/**
	 * A method to return a property value.
	 * @param key The property to get.
	 * @return The property value.
	 */
	public static String getProperty(String key) {
		String value = null;
		
		try {
			value = props.getProperty(key);
		} catch (NullPointerException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		return value;
	}
	
	/**
	 * Sets the environment property if the command line parameter is 
	 * used to start the framework. If the environment wasn't passed in
	 * on the command line, the value if the environment.properties 
	 * file is used.
	 */
	private static void setEnvironment() {
		String key = "env";
		String value = null;
		
		value = System.getProperty(key);
		
		if (value != null) {
			props.setProperty("environment", value);
		}
	}

    private static Properties prompts = new Properties();
    private static String promptsFile;

    /**
     * Loads the prompts.properties file
     */
    static {
        if (prompts.isEmpty()) {
            promptsFile = FileFinder.find("prompts.properties");
            try {
                InputStream in = new FileInputStream(promptsFile);
                prompts.load(in);
                in.close();
            } catch (IOException e) {
                log.error(e.getMessage());
                log.debug(e.getMessage(), e);
            }
        }
    }

    /**
     * Gets a prompt for a passed in value.
     * @param key The name of the prompt to get.
     * @return The value of the property
     */
    public static String getPrompt(String key) {
        String value = null;

        try {
            value = prompts.getProperty(key);
        } catch (NullPointerException e) {
            log.error(e.getMessage());
            log.debug(e.getMessage(), e);
        }
        return value;
    }

}