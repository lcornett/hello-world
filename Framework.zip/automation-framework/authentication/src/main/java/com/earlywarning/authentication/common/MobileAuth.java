/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

/**
 * The original class that performed a MobileAuth. All of the values are hard coded. 
 * This class replaced by the Cucumber step definitions and the other classes in this
 * package.
 * 
 * @author cornettl
 *
 */
@Deprecated
public class MobileAuth {
	 	ApiDriver apidriver;
	    String redirectURL;

	    @Before
	    public void setup() {
	        apidriver = new ApiDriver("application/json", "https://transp2.authentify.net/s2s/platform"); //"https://transp2.authentify.net/s2s");"https://qa.authentify.com/s2s/platform"
	    }


	    @Test
	    public void mobileLookup_Verify_Success() throws MalformedURLException, UnsupportedEncodingException {


	        /**
	         * Mobile Auth Start XML Request
	         */

	        String body =
//	                "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"
//	                        + "<AuthentXML xmlns=\"http://xml.authentify.net/MessageSchema.xml\" version=\"1.0\">"
//	                        + "<header>"
//	                        + "<tsoid>Authentify_Test</tsoid>"
//	                        + "<licenseKey>5a7f3790-3d9d-464e-a9da-70fee8f45244</licenseKey>"
//	                        + "<application>mobileLookupProd</application>"
//	                        + "<account>QATest</account>"
//	                        + "<asid>Authentify_QA_Test</asid>" 
//	                        + "</header>"
//	                        + "<body>"
//	                        + "<request>"
//	                        + "<action>mobileAuthStart</action>"
//	                        + "<data>"
//	                        + "<dataLookup>"
//	                        + "<mobileNetworkOperator>T-Mobile</mobileNetworkOperator>"
//	                        + "<deviceIp></deviceIp>"
//	                        + "<FinalTargetUrl>https://authentify.com/mobileAuthFinish</FinalTargetUrl>"
//	                        + "<consentCollectedDate>2015-11-19</consentCollectedDate>"
//	                        +"<consentTransactionId>b000101</consentTransactionId>"
//	                        +"<consentDescription>Nataliya</consentDescription>"
//	                        + "</dataLookup>"
//	                        + "<namedData>"
//	                        + "<dataItem name=\"returnlegacydeviceid\">false</dataItem></namedData>"
//	                        + "</data>"
//	                        + "</request>"
//	                        + "</body>"
//	                        + "</AuthentXML>";
	        	"{"
	        		+ "\"clientId\": \"Authentify_Test\","
	        		+ "\"license\": \"5a7f3790-3d9d-464e-a9da-70fee8f45244\","
	        		+ "\"app\": \"mobileLookupProd\","
	        		+ "\"clientAccctId\": \"QATest\","
	        		+ "\"clientContext\": \"Authentify_QA_TEST\","
	        		+ "\"event\": \"mobileAuthStart\","
	        		+ "\"data\": {"
	        		+ "\"dataLookup\": {"
	        		+ "\"mobileNetworkOperator\": {\"value\": \"Verizon\"},"
	        		+ "\"deviceIp\": {\"value\": \"\"},"
	        		+ "\"FinalTargetUrl\": {\"value\": \"https://authentify.com/mobileAuthFinish\"},"
	        		+ "\"consentCollectedDate\": {\"value\": \"2015-11-19\"},"
	        		+ "\"consentTransactionId\": {\"value\": \"b000101\"},"
	        		+ "\"consentDescription\": {\"value\": \"Got verbal approval from Nataliya Ripinskaya\"},"
	        		+ "\"namedData\": {"
	        		+ "\"dataItem\": {"
	        		+ "\"name\": \"returnlegacydeviceid\","
	        		+ "\"value\": \"false\""
	        		+ "}}}}}";


	        /**
	         * Sending the authStart XML request to the infrastructure and perform polling and retrieve the Redirect Target URL
	         */

	        apidriver.setBody(body);
	        apidriver.post();
	        Response Resp = apidriver.poll();
//	        redirectURL = apidriver.retrieveXMLvaluefromTag(Resp, "dat:RedirectTargetUrl");
	        JsonPath jsonPath = new JsonPath(Resp.asString());
	        redirectURL = jsonPath.getString("data.dataLookup.RedirectTargetUrl");
	        System.out.println(redirectURL);

	        /**
	         * Sends a get request with the redirectURL to payfone and gets the vfp data (Done by getvfp function) and
	         * appends the vfp data to the below authfinish request
	         */


	        body =
//	                "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"
//	                        + "<AuthentXML xmlns=\"http://xml.authentify.net/MessageSchema.xml\" version=\"1.0\">"
//	                        + "<header>"
//	                        + "<tsoid>Authentify_Test</tsoid>"
//	                        + "<licenseKey>5a7f3790-3d9d-464e-a9da-70fee8f45244</licenseKey>"
//	                        + "<application>mobileLookupProd</application>"
//	                        + "<account>QATest</account>"
//	                        + "<asid>Authentify_QA_Test</asid>"
//	                        + "</header>"
//	                        + "<body>"
//	                        + "<request>"
//	                        + "<action>mobileAuthFinish</action>"
//	                        + "<data>"
//	                        + "<phoneNumber>6364398468</phoneNumber>"
//	                        + "<dataLookup>"
//	                        + "<vfp>"+ getvfp().replace("\"","")+"</vfp>"
//	                        + "</dataLookup>"
//	                        + "<namedData>"
//	                        + "<dataItem name=\"returnlegacydeviceid\">false</dataItem></namedData>"
//	                        + "</data>"
//	                        + "</request>"
//	                        + "</body>"
//	                        + "</AuthentXML>";
	        "{"
	        	  + "\"clientId\": \"Authentify_Test\","
	        	  + "\"license\": \"5a7f3790-3d9d-464e-a9da-70fee8f45244e\","
	        	  + "\"app\": \"mobileLookupProd\","
	        	  + "\"clientAcctId\": \"QATest\","
	        	  + "\"clientContext\": \"Authentify_QA_TEST\","
	        	  + "\"event\": \"mobileAuthFinish\","
	        	  + "\"data\": {"
	        	  + "\"dataLookup\": {"
	        	  + "\"vfp\": {\"value\":\"" + getvfp() + "\"},"
	        	  + "\"namedData\": {"
	        	  + "\"dataItem name\": \"returnlegacydeviceid\","
	        	  + "\"value\": \"false\""
	        	  + "}}}}";

	        /**
	         * Sends the Authfinish request to the infrastructure with the received vfp data from payfone, perfoms polling and gets the response XML
	         */

	        apidriver.setBody(body);
	        apidriver.post();
	        Resp = apidriver.poll();
	        System.out.println(Resp);






	}

	    @After
	    public void TearDown(){
	        apidriver = null;
	    }

//	    public boolean sendMessage(String payload) {
//	    }
//	    
	    	
	    public String newvfp(){
	    	apidriver.reset();
	    	try{
	    	URL url = new URL(redirectURL + "&r=f");
	    	apidriver.setUrl(url.toString());
	    	String output = apidriver.get();
	    	return output.replace("{\"vfp\":\"","").replace("\"}","");
	    	}catch(MalformedURLException e){
	    		e.printStackTrace();
	    		return "";
	    	}
	    }
	    
	    public String getvfp(){
	        String vfp;
	        try {

	            URL url = new URL(redirectURL + "&r=f");
	            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	            conn.setRequestMethod("GET");
	            conn.setRequestProperty("Accept", "application/json");
	            conn.connect();
	            if (conn.getResponseCode() != 200) {
	                throw new RuntimeException("Failed : HTTP error code : "
	                        + conn.getResponseCode());
	            }

	            BufferedReader br = new BufferedReader(new InputStreamReader(
	                    (conn.getInputStream())));

	            String output;
	            System.out.println("Output from Server .... \n");
	            while ((output = br.readLine()) != null) {
	                System.out.println(output);
	                vfp = output.replace("{\"vfp\":\"","").replace("\"}","");
	                System.out.println(vfp);
	                return vfp;
	            }

	            conn.disconnect();

	        } catch (MalformedURLException e) {

	            e.printStackTrace();


	        } catch (IOException e) {

	            e.printStackTrace();

	        }
	        return null;
	    }
	    public static void main(String[] args) {
	        RestAssured.given().contentType("application/json").post("http://device.ews.payfone.com/mobileauth/2014/07/01/deviceAuthenticate?vfp=4e4468684e6a5577597a5974597a55314e433030597a51314c546c694e4755744d4459774e6d49314f4749344d575133664442384d4877773aac347a4515f7e8a113b4168915c085b0b87615dd7d07ad6076dd4d5087ec2ff5&r=f").then().log().all();
	    }

	}


