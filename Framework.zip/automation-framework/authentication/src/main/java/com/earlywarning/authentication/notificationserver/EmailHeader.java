/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.notificationserver;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Builder;
import lombok.Data;

/**
 * A POJO that represents the emailHeader element of the Request message.
 * @author cornettl
 *
 */
@Data
@Builder
@JsonInclude(Include.NON_NULL)
public class EmailHeader {
	private String sender;
	private String destination;
	private String replyTo;
	private String subject;
	private String emailType;
	private String message;
}
