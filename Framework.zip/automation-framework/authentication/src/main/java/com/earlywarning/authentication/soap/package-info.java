/**
 * 
 */
/**
 * This package contains the clases required to create and format a SOAP request
 * @author cornettl
 *
 */
package com.earlywarning.authentication.soap;