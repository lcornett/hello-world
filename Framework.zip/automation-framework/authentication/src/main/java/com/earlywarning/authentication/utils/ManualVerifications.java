/**
 * Copyright (c) 2018 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.utils;

import javax.swing.JOptionPane;

import lombok.extern.log4j.Log4j2;

/**
 * A class that provides interactivity to the automation framework.
 * This is done by displaying a dialog box to the user so the user
 * can verify a condition, usually on a mobile device.
 * @author cornettl
 *
 */
@Log4j2
public class ManualVerifications {
	static int counter = 0;

	/**
	 * A method that shows a confirmDialog to the user. The option 
	 * selected is logged. If the Cancel button is selected, the user
	 * is prompted for a try again. This can only be done a maximum 
	 * of three times
	 * @param message The message to display in the dialog.
	 * @return The int value of the option chosen.
	 */
	public static int showYesNoMessage(String message) {
		int result = -1;
		result = JOptionPane.showConfirmDialog(null, message);
		
		if (result == 0) {
			log.info("The message " + message + " was verified.");
		} else if (result == 1) {
			log.info("The message " + message + " was not verified.");			
		} else if (result == 2) {
			if (tryAgain() && counter < 3) {
				counter++;
				showYesNoMessage(message);
			}
		}
		return result;
	}

	/**
	 * A method that is called when the user selects the cancel button from
	 * the main dialog. A dialog is displayed asking the user to try again.
	 * @return true if OK, false otherwise.
	 */
	private static boolean tryAgain() {
		boolean result = false;
		int selection = JOptionPane.showConfirmDialog(null, "Invalid selection! Try Again?");
		
		if (selection == 0) {
			result = true;
		}
		
		return result;
	}
}
