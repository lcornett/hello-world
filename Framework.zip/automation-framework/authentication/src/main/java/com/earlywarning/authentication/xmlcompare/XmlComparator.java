/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.xmlcompare;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.earlywarning.authentication.xml.AuthentXmlResponse;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import lombok.extern.log4j.Log4j2;

/**
 * A class that compares two XML formatted strings.
 * @author cornettl
 *
 */
@Log4j2
public class XmlComparator {

	/**
	 * A method that performs a comparison of two XML formatted strings. No details of the comparison
	 * are output. JUst equals or not.
	 * @param expected The expected string to compare to.
	 * @param actual The string being compared.
	 * @return true if the strings are the same, false otherwise
	 */
	public static boolean compareXml(String expected, String actual) {
		boolean result = false;
		String msg = null;
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		dbf.setCoalescing(true);
		dbf.setIgnoringElementContentWhitespace(true);
		dbf.setIgnoringComments(true);
		
		try {
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document expectedDoc = db.parse(new ByteArrayInputStream(expected.getBytes()));
			expectedDoc.normalizeDocument();
			
			Document actualDoc = db.parse(new ByteArrayInputStream(actual.getBytes()));
			actualDoc.normalizeDocument();
			
			result = expectedDoc.isEqualNode(actualDoc);
			
			if (result == true) {
				msg = "The response equals the stored response.";
			} else {
				msg = "The response does not equal the stored response!";
			}
			
			System.out.println(expectedDoc.getFirstChild().getNodeName());
			System.out.println(expectedDoc.getFirstChild().getTextContent());
			log.info(msg);
			return result;
			
		} catch (ParserConfigurationException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (SAXException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (IOException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		return false;	
	}
	
	/**
	 * A method that compares two XML formatted strings representing a response to an
	 * AuthentXML message. This comparison is performed element by element. Elements that
	 * are not expected to be the same are not compared.
	 * @param expected A string representing the expected response.
	 * @param actual A string representing the actual response.
	 * @return true if the element values match, false otherwise.
	 */
	public static boolean compareElements(String expected, String actual) {
		boolean result = false;
		XmlResponseComparator comparator = new XmlResponseComparator();
		JacksonXmlModule module = new JacksonXmlModule();
		module.setDefaultUseWrapper(false);
		XmlMapper mapper = new XmlMapper(module);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		mapper.enable(SerializationFeature.INDENT_OUTPUT);
		
		try {
			AuthentXmlResponse expectedResponse = mapper.readValue(expected, AuthentXmlResponse.class);
			AuthentXmlResponse actualResponse = mapper.readValue(actual, AuthentXmlResponse.class);
			
			result = comparator.compareResponse(expectedResponse, actualResponse);
		} catch (IOException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		return result;
	}
}
