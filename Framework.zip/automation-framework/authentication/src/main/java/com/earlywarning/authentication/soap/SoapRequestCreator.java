/**
 * Copyright (c) 2018 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.soap;

import java.util.Map;
import java.util.Set;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import com.earlywarning.authentication.startup.Env;

import lombok.extern.log4j.Log4j2;

/**
 * A class that creates an Authentify request in SOAP format. The soap request appears to be dissimilar 
 * to the AuthentXML message in content.
 * <p>This class uses SAAJ to implement the SOAP message. 
 * @author cornettl
 *
 */
@Log4j2
public class SoapRequestCreator {
	private SOAPFactory soapFactory;
	private SOAPMessage message;
	private SOAPPart soapPart;
	private SOAPEnvelope envelope;
	private SOAPHeader header;
	private SOAPHeaderElement authentication;
	private SOAPBody body;
	private SOAPBodyElement bodyElement;
	
	// elements that have child elements
	private SOAPElement subject;
	private SOAPElement address;
	private SOAPElement namedDataElement;
	private SOAPElement asid;
	
	/**
	 * A method that adds the data elements to the SOAP message. The element names or attribute
	 * names are passed in with their data in a HashMap created from a Data Table. Only the 
	 * elements that are speciried will be included in the message.
	 * @param map The element/attribute names and values.
	 * @return The formatted SOAP message
	 */
	public SOAPMessage createSoapMessage(Map<String, String> map) {
		Set<String> keys = map.keySet();
		setup();
		
		try {
			for (String key : keys) {
				switch (key) {
					case "account":
						SOAPElement account = authentication.addChildElement(getChildName(key));
						account.addTextNode(map.get(key));
						break;
					case "action":	
						SOAPElement action = bodyElement.addChildElement(getChildName(key));
						action.addTextNode(map.get(key));
						break;
					case "amount":
						if (namedDataElement == null) {
							createNamedData();
						}
						SOAPElement dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "amount1":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "amount2":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "amount3":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "amount4":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "amount5":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "application":
						SOAPElement application = authentication.addChildElement(getChildName(key));
						application.addTextNode(map.get(key));
						break;
					case "asid":
						if (subject == null) {
							createSubject();
						}
						asid = subject.addChildElement(getChildName(key));
						asid.addTextNode(map.get(key));
						break;
					case "beneficiary_name":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "channel":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "confirmNumber":
						SOAPElement confirmNumber = bodyElement.addChildElement(getChildName(key));
						confirmNumber.addTextNode(map.get(key));
						break;
					case "country_code_digits":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "currency":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "currency1":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "destCountry":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "eventType":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "fraction":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "fraction1":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "fraction2":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "fraction3":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "fraction4":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "fraction5":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "language":
						if (subject == null) {
							createSubject();
						}
						SOAPElement language = subject.addChildElement(getChildName(key));
						language.addTextNode(map.get(key));
						break;
					case "messageText":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "partialAccountNumber":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "partialSortCode":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "paymentType":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "phoneNumber":
						SOAPElement phoneNumber = bodyElement.addChildElement(getChildName(key));
						phoneNumber.addTextNode(map.get(key));
						break;
					case "phone_number_digits":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "pinNumber":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "postalCode":
						if (address == null) {
							createAddress();
						}
						SOAPElement postalCode = address.addChildElement(getChildName(key));
						postalCode.addTextNode(map.get(key));
						break;
					case "redirectURL":
						SOAPElement redirectURL = bodyElement.addChildElement(getChildName(key));
						redirectURL.addTextNode(map.get(key));
						break;
					case "to_account_digits":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "transactionType":
						if (namedDataElement == null) {
							createNamedData();
						}
						dataItem = namedDataElement.addChildElement(getChildName("dataItem"));
						dataItem.setAttribute("name", key);
						dataItem.addTextNode(map.get(key));
						break;
					case "tsoid":
						SOAPElement tsoid = authentication.addChildElement(getChildName(key));
						tsoid.addTextNode(map.get(key));
						break;
					default:
						log.error("The data key " + key + " isn't implemented!");
				}
			}
		} catch (SOAPException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} 
		
		return message;
	}
	
	/**
	 * A method that creates an empty SOAP message, adds the authentify namespace,
	 * creates the SOAPHeaderElement and adds it to the header and creates the 
	 * SOAPBodyElement and adds it to the body. Also the licenseKey element is created 
	 * by reading the license key from the environment.properties file and added to 
	 * the header.
	 */
	void setup() {
		try {
			soapFactory = SOAPFactory.newInstance();
			MessageFactory messageFactory = MessageFactory.newInstance();
			message = messageFactory.createMessage();
			
			// retrieve different parts
			soapPart = message.getSOAPPart();
			envelope = message.getSOAPPart().getEnvelope();
			header = envelope.getHeader();
			body = envelope.getBody();
			
			// add namespace declaration
			envelope.addNamespaceDeclaration("aut", "http://xml.authentify.net/AuthentifyService/");
			
			// add header element
			Name authName = soapFactory.createName("authentication", "aut", "http://xml.authentify.net/AuthentifyService/");
			authentication = message.getSOAPHeader().addHeaderElement(authName);
			
			// add body element
			Name requestData = soapFactory.createName("RequestData", "aut", "http://xml.authentify.net/AuthentifyService/");
			bodyElement = body.addBodyElement(requestData);
			
			// addd the license key
			String env = Env.getProperty("environment");
			String license = Env.getProperty(env + "License");
			Name childName = soapFactory.createName("licenseKey");
			SOAPElement licenseKey = authentication.addChildElement(childName);
			licenseKey.addTextNode(license);
		} catch (SOAPException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}

	}
	
	/**
	 * A utility method that creates an instance of the Name class for the element
	 * being created.
	 * @param key The name of the element.
	 * @return An instance of the Name class for the element name passed in.
	 */
	Name getChildName(String key) {
		Name childName = null;
		
		try {
			childName = soapFactory.createName(key);
		} catch (SOAPException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		return childName;
	}
	
	/**
	 * Creates a subject element. The subject element does not have any data associated 
	 * with it. There may be several child elements which require that the subject element 
	 * exist. The child elements check for the existance of the subject element and if it
	 * does not exist, it is created. The subject element is an instance variable.
	 */
	void createSubject() {
		try {
			subject = bodyElement.addChildElement(getChildName("subject"));
		} catch (SOAPException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
	}
	
	/**
	 * A method to create the address element. The address element contains no data
	 * but does have child elements. When these child elements are created, the existance
	 * of the address is checked. If the element does not exist, it is created. Then the 
	 * child element is added to it. The address element is an instance variable and is 
	 * a child element of the subject element.
	 */
	void createAddress() {
		try {
			if (null == subject) {
				createSubject();
			}
			address = subject.addChildElement(getChildName("address"));
		} catch (SOAPException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
	}
	
	/**
	 * A method to create the namedData element. The namedData element does not have
	 * any data of it own but does have child elements. When these child elements are
	 * created the existance of the namedData element is checked. If the element does
	 * not exist it is created and the child element is added to it. The nammedData
	 * element is an instance variable.
	 */
	void createNamedData() {
		try {
			namedDataElement = bodyElement.addChildElement(getChildName("namedData"));
		} catch (SOAPException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
	}

}
