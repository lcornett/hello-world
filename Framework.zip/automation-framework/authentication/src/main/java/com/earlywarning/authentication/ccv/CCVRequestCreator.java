/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.ccv;

import java.util.Map;
import java.util.Set;

import lombok.extern.log4j.Log4j2;

/**
 * A class that constructs an Authentify Call Center Verification 
 * JSON message. The message is constructed by using the CCVRequestBuilder,
 * MatchEmailAttributeKeyBuilder, MatchNameAttributeKeyBuilder and the 
 * MatchAddressAttributeKeyBuilder classes. Please see the 
 * <a href="{@docRoot}/com/earlywarning/authentication/ccv/package-summary.html#tags">
 * package-info</a> page for information about how these classes are derived.
 * <p>It also implements the CCVFieldConstants interface which provides normalization
 * of the element names.</p>
 * 
 * @author cornettl
 *
 */
@Log4j2
public class CCVRequestCreator implements CCVFieldConstants {
	static CCVRequest.CCVRequestBuilder requestBuilder = CCVRequest.builder();
	static MatchEmailAttributeKey.MatchEmailAttributeKeyBuilder emailBuilder = null;
	static MatchNameAttributeKey.MatchNameAttributeKeyBuilder nameBuilder = null;
	static MatchAddressAttributeKey.MatchAddressAttributeKeyBuilder addressBuilder = null;
	
	/**
	 * The method that does the work of creating the Authentify Call
	 * Center Verification message. The message is composed form a 
	 * Map&lt;String, String&gt; having the name value pairs of the name of 
	 * the message element and its value. An element name that is not included in 
	 * the map is not included in the message. By the same token, if an empty element
	 * is desired in the message, the name is included without a value.
	 * 
	 * @param args A set of name value pairs of the elements to include in the message.
	 * @return An instance of the CCVRequest class.
	 */
	public static CCVRequest createRequest(Map<String, String> args) {
		Set<String> keys = args.keySet();
		CCVRequest request= null;
		MatchEmailAttributeKey emailKey = null;
		MatchNameAttributeKey nameKey = null;
		MatchAddressAttributeKey addressKey = null;
		MobileIdentityMatchAttribute mima = new MobileIdentityMatchAttribute();
		
		try {
			for (String key : keys) {
				switch (key) {
				case API_CLIENT_ID:
					requestBuilder.apiClientId(args.get(key));
					break;
				case CALL_ARRIVAL_TIMESTAMP:
					requestBuilder.callArrivalTimestamp(args.get(key));
					break;
				case CITY:
					if (null == addressBuilder) {
						addressBuilder = MatchAddressAttributeKey.builder();
					}
					addressBuilder.City(args.get(key));
					break;
				case CONSENT_COLLECTED_TIMESTAMP:
					requestBuilder.consentCollectedTimestamp(args.get(key));
					break;
				case CONSENT_DESCRIPTION:
					requestBuilder.consentDescription(args.get(key));
					break;
				case CONSENT_STATUS:
					requestBuilder.consentStatus(args.get(key));
					break;
				case CONSENT_TRANSACTION_ID:
					requestBuilder.consentTransactionId(args.get(key));
					break;
				case COUNTRY:
					if (null == addressBuilder) {
						addressBuilder = MatchAddressAttributeKey.builder();
					}
					addressBuilder.Country(args.get(key));
					break;
				case EMAIL_ADDRESS:
					if (null == emailBuilder) {
						emailBuilder = MatchEmailAttributeKey.builder();
					}
					emailBuilder.emailAddress(args.get(key));
					break;
				case EXTENDED_ADDRESS:
					if (null == addressBuilder) {
						addressBuilder = MatchAddressAttributeKey.builder();
					}
					addressBuilder.ExtendedAddress(args.get(key));
					break;
				case FIRST_NAME:
					if (null == nameBuilder) {
						nameBuilder = MatchNameAttributeKey.builder();
					}
					nameBuilder.FirstName(args.get(key));
					break;
				case LAST_NAME:
					if (null == nameBuilder) {
						nameBuilder = MatchNameAttributeKey.builder();
					}
					nameBuilder.LastName(args.get(key));
					break;
				case MIDDLE_NAME:
					if (null == nameBuilder) {
						nameBuilder = MatchNameAttributeKey.builder();
					}
					nameBuilder.MiddleName(args.get(key));
					break;
				case MOBILE_CALL_VERIFICATION_CHECK:
					requestBuilder.MobileCallVerificationCheck(Boolean.parseBoolean(args.get(key)));
					break;
				case MOBILE_CALL_VERIFICATION_DID:
					requestBuilder.mobileCallVerificationDID(args.get(key));
					break;
				case MOBILE_IDENTITY_CHECK:
					requestBuilder.MobileIdentityCheck(Boolean.parseBoolean(args.get(key)));
					break;
					
				case MOBILE_NUMBER:
					requestBuilder.mobileNumber(args.get(key));
					break;
				case MOBILE_STATUS_CHECK:
					requestBuilder.MobileStatusCheck(Boolean.parseBoolean(args.get(key)));
					break;
				case PAYFONE_ALIAS:
					requestBuilder.payfoneAlias(args.get(key));
					break;
				case POSTAL_CODE:
					if (null == addressBuilder) {
						addressBuilder = MatchAddressAttributeKey.builder();
					}
					addressBuilder.PostalCode(args.get(key));
					break;
				case REGION:
					if (null == addressBuilder) {
						addressBuilder = MatchAddressAttributeKey.builder();
					}
					addressBuilder.Region(args.get(key));
					break;
				case REQUESTID:
					requestBuilder.requestId(args.get(key));
					break;
				case STREET_ADDRESS:
					if (null == addressBuilder) {
						addressBuilder = MatchAddressAttributeKey.builder();
					}
					addressBuilder.StreetAddress(args.get(key));
					break;
				default:
					String msg = "The element " + key + " was not found!";
					log.warn(msg);
				}				
			}
			
			// put it all together
			if (null != emailBuilder) {
				emailKey = emailBuilder.build();
				mima.setMatchEmailAttributeKey(emailKey);
			}
			
			if (null != nameBuilder) {
				nameKey = nameBuilder.build();
				mima.setMatchNameAttributeKey(nameKey);
			}
			
			if (null != addressBuilder) {
				addressKey = addressBuilder.build();
				mima.setMatchAddressAttributeKey(addressKey);
			}
			
			requestBuilder.mobileIdentityMatchAttribute(mima);
			request = requestBuilder.build();	
			return request;
		} finally {
			emailBuilder = null;
			nameBuilder = null;
			addressBuilder = null;
			requestBuilder = CCVRequest.builder();
		}

	}
	
}

