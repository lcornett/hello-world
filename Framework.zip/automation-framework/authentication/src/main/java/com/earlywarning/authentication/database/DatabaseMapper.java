/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.earlywarning.authentication.common.ApiDriver;
import com.earlywarning.authentication.utils.FileFinder;

import lombok.extern.log4j.Log4j2;
/**
 * The DatabaseMapper class gets the latest response form the ApiDriver class and 
 * retrieves the replyTo element from the response. The host name in the replyTo
 * element is mapped to a database name. 
 * 
 *  @author cornettl
 *
 */
@Log4j2
public class DatabaseMapper {
	private static Properties dbMap = new Properties();
	private static String propsFile;
	
	static {
		
		if (dbMap.isEmpty()) {
			propsFile = FileFinder.find("dbmap.properties");
			try {	
				InputStream in = new FileInputStream(propsFile);
				dbMap.load(in);
				in.close();
			} catch (IOException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			} 
		}

	}
	
	/**
	 * Retrieves the replyTo element from the last response. Isolates the host name and gets the 
	 * database name from the map based on the host name.
	 * @return The database name
	 * @throws Exception If the response is null or the replyTo element is not in the response
	 */
	public static String getDatabase() throws Exception {		
		String key = "replyTo";
		String url = null;
		String contentType = null;
		
		try {
			contentType = ApiDriver.getResp().contentType();
			
			if (contentType.contains("json")) {
				url = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), key);
			} else if (contentType.contains("xml")) {
				url = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//" + key + "/text()");
			}
			url = url.substring(8,25);
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
			throw e;
		}
		
		return dbMap.getProperty(url);
	}
}
