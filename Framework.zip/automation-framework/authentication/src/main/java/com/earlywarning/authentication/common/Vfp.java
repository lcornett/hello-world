/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/**
 * A POJO representing the vfp element of the Authentify JSON request
 * message. This class utilizes the lombok Data and the jackson 
 * JsonInclude annotations. The Data annotation provides the implementation
 * of the setter and getter for the private property:<ul><li>value</li></UL>
 * For additionl information about the annotations, please see the
 * <a href="{@docRoot}/com/earlywarning/authentication/common/package-summary.html#tags">
 * package-info</a> page.
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_EMPTY)
public class Vfp {
	private String value;
}
