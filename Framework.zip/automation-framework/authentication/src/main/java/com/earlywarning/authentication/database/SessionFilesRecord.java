/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import lombok.Data;

/**
 * A POJO that represents a row for the query on the SessionFiles table.
 * This class uses the lombok.Data annotation for the implementation of
 * the getters and setters for the following class properties:<ul>
 * 	<li>id</li>
 *  <li>fileName</li>
 *  <li>location</li>
 *  <li>format</li>
 *  <li>length</li>
 *  <li>type</li>
 *  <li>processed<li>
 *  <li>timestamp</li>
 *  <li>sessionId</li></ul>
 * @author cornettl
 *
 */
@Data
public class SessionFilesRecord implements TableRecord {
	private String id, fileName, location, format, length, type, processed, timestamp, sessionId;
}
