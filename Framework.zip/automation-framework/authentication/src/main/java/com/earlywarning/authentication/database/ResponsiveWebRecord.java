/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 *
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 *
 */
package com.earlywarning.authentication.database;

import lombok.Data;

/**
 * A POJO that represents a row of data from the query on the ResponsiveWebTable table.
 * This class utilizes the lombok.Data annotation for the implementation of the
 * getters and setters of the following class properties:<ul>
 * 	<li>Name</li>
 * 	<li>Code</li>
 * 	<li>Status</li></ul>
 *
 */

@Data
public class ResponsiveWebRecord implements TableRecord{
    private String Name, Code, Status;
} 