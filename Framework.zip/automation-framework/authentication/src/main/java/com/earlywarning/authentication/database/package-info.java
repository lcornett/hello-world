/**
 * 
 */
/**
 * This package contains the classes to required connect to the databases for Authentify and return the results of the queries.
 * Implemented are classes that represent a row of a result set for each of the queries for seven different tables, the interface
 * that all of the database row records implement as well as the DataSource, and the Data Validator. Also included are utility classes
 * that tie all of the other classes together.
 * 
 * @author cornettl
 *
 */
package com.earlywarning.authentication.database;