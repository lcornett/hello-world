/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.xmlcompare;

import com.earlywarning.authentication.jsoncompare.StringComparator;
import com.earlywarning.authentication.xml.ResponseBody;
import com.earlywarning.authentication.xml.XmlResult;

/**
 * A class that compares the values of the elements contained in the 
 * ResponseBody class.
 * @author cornettl
 *
 */
class XmlBodyComparator extends StringComparator {
	
	/**
	 * Compares the values of the elements of a ResponseBody class. 
	 * @param expected The ResponseBody to compare to.
	 * @param actual The ResponseBody to compare.
	 * @return true if the response bodies match, false otherwise.
	 */
	public boolean compare(ResponseBody expected, ResponseBody actual) {
		String[] keys = {"body"};
		
		for (String key : keys) {
			switch (key) {
				case "body":
					XmlResultComparator comparator = new XmlResultComparator();
					XmlResult expectedResult = expected.getResult();
					XmlResult actualResult = actual.getResult();
					updateStatus(comparator.compare(expectedResult, actualResult));
					break;
			}
		}
		
		return status;
	}
}
