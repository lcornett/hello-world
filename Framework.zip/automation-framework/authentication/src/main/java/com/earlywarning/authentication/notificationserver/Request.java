/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.notificationserver;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Builder;
import lombok.Data;

/**
 * <p>A POJO That represents the Authentify request for the notification server.</p>
 * <p>This class utilizes the lombok Data, lombok Builder and the jackson JsonInclude
 * annotations. The Data annotation provides the implementation for the getters 
 * and setters for the private properties:</p><ul>
 * 	<li>clientAcctId</li>
 * 	<li>clientContext</li>
 *  <li>clientId</li>
 *  <li>clientSessionId</li>
 *  <li>dataStore</li>
 *  <li>event</li>
 *  <li>license</li>
 *  <li>messageType</li>
 *  <li>smsHeader</li>
 *  <li>userId</li>
 *  <li>emailHeader</li></ul>
 * <p>The Builder annotation provides the implementation of the Builder pattern for this class.</p>
 * <p>For additional information about these annotations, please see the 
 * <a href="{@docRoot}/com/earlywarning/authentication/notificationserver/package-summary.html#tags">
 * package-info</a> page.
 * @author cornettl
 *
 */
@Data
@Builder
@JsonInclude(Include.NON_NULL)
public class Request {
	private String clientAcctId;
	private String clientContext;
	private String clientId;
	private String clientSessionId;
	private boolean dataStore;
	private String event;
	private String license;
	private String licenseKey;
	private String messageType;
	private SmsHeader smsHeader;
	private String userId;
	private String dateBegin;
	private Integer numDays;
	private Integer maxRecords;
	private String msgIndex;
	private EmailHeader emailHeader;
}
