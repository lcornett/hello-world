/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.xml;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import lombok.Builder;
import lombok.Data;

/**
 * <p>A POJO that represents the data element of the Authentify XML request message.
 * This class utilizes the lombok Data and the lombok Builder annotations. The 
 * Data annotation provides the implementation of the getter and setter methods
 * for the private properties:</p><ul>
 * 	<li>phoneNumber</li>
 * 	<li>confirmNumber</li>
 * 	<li>language</li>
 * 	<li>VID</li>
 * 	<li>name</li>
 * 	<li>address</li>
 * 	<li>namedData</li>
 * 	<li>legacyDeviceId</li>
 * </ul>
 * <p>The Builder annotation provides an all argument constructor and a &lt;class name&gt;
 * Builder class. For additional information about these annotations see the
 * <a href="{@docRoot}/com/earlywarning/authentication/xml/package-summary.html#tags">package-info</a> page.</p>
 *
 * @author cornettl
 *
 */
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class RequestData {
	@JacksonXmlProperty(localName="xmlns:dat=\"http://xml.authentify.net/CommonDataSchema.xml\"", isAttribute=true)
	private final String xmlns = "";
	
	@JacksonXmlProperty(localName="dat:phoneNumber")
	private String phoneNumber;

    @JacksonXmlProperty(localName="dat:confirmNumber")
    private String confirmNumber;

    @JacksonXmlProperty(localName="dat:language")
    private String language;

    @JacksonXmlProperty(localName="dat:VID")
    private String VID;
	
	@JacksonXmlProperty(localName="dat:namedData")
	private NamedData namedData;

	private String legacyDeviceId;
	private String ewDeviceId;
	private XmlDataLookup dataLookup;
}

