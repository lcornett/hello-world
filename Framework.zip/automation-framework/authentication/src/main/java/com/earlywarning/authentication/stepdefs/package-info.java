/**
 * <p>This package is a collection of all the Cucumber Step Definition files relating to the 
 * following Jira projects:<ul>
 * 	<li>Authentication M &amp; E</li>
 * 	<li>Authentify Platform Test Repository</li>
 * </ul>
 * <h2>Step Definitions</h2>
 * <p>The step definitions are implemented in the step definition files. Finding the step definition
 * that is needed may be a daunting task if you have to look through many files to find what you are 
 * looking for. Then, if what you are looking for has not been implemented, frustration could set in.</p>
 * <p>To alleviate this, the step definitions should be listed here. This listing is solely to assist the 
 * author of feature files. The Step Definitions are divided into groups that represent the step definition
 * files (i.e., Common Step Definitions, Data Lookup Step Definitions, etc.)
 * <table class="memberSummary" border="0" cellpadding="3" cellspacing="0" summary="Test">
 * <caption><span>Common Step Definitions</span><span class="tabEnd">&nbsp;</span></caption>
 * <tr>
 * <th class="colFirst" scope="col">Step Definition</th>
 * <th class="colOne" scope="col">Usage</th>
 * <th class="colLast" scope="col">Description</th></tr>
 * <tbody>
 * <tr class="altColor">
 * <td class="colFirst"><code>Given the request has the value &lt;string&gt; = &lt;string&gt;</code></td>
 * <td class="colOne">Create a JSON Message. Used to create a message element by element.</td>
 * <td class="colLast"><div class="block">This step definition allows the user to create a valid JSON request with the tag and value identified. The tag used must be one of the tags implemented in the RequestCreator class.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Given the request has the values</code></td>
 * <td class="colOne">Create a JSON Message. Uses a data table to create the message. This is the preferred method.</td>
 * <td class="colLast"><div class="block">This step definition allows the user to create a valid JSON request with the tag and value identified. The tag used must be one of the tags implemented in the RequestCreator class.</div></td>
 * </tr> 
 * <tr class="altColor">
 * <td class="colFirst"><code>Given the following json request</code></td>
 * <td class="colOne">Uses a pre-formatted JSON message. Allows the user to input an invalid JSON message</td>
 * <td class="colLast"><div class="block">This step definition allows the user to input a preformatted JSON message instead of building a JSON message. This allows using an invalid JSON message. The format of this step definition is as follows:
 * Given the following json request """ &lt;Invalid JSON message&gt; """
 * This step definition requires the triple quotes around the invalid JSON message.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>When the request is sent</code></td>
 * <td class="colOne">Posts the JSON request to the endpoint for the environment.</td>
 * <td class="colLast"><div class="block">This step definition uses the 'environment.properties' file to populate the rest endpoint and post the message created in the Given step to that endpoint.</div></td>
 * </tr> 
 * <tr class="altColor">
 * <td class="colFirst"><code>When the request is sent to responsive web</code></td>
 * <td class="colOne">Posts the JSON request to the Responsive Web endpoint for the environment.</td>
 * <td class="colLast"><div class="block">This step definition uses the 'environment.properties' file to populate the responsive web endpoint. The message is then posted to that endpoint.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>When the json request is sent to the responsive web</code></td>
 * <td class="colOne">Posts a pre-formatted JSON request to the endpoint for the environment.</td>
 * <td class="colLast"><div class="block">This step definition is similar to the above except that it posts the preformatted JSON message to the endpoint.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>When the poll request is sent</code></td>
 * <td class="colOne">This step definition is obsolete. Polling is automatic now.</td>
 * <td class="colLast"><div class="block">This step definition is used when it is expected that the response has a status code of 7000 (Session in Progress). In this case, the system polls the server until a final response is received.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst"><code>When I send a request with the vfp</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">A message having the vfp element is created and the message is sent to the appropriate endpoint.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>When the request is sent to the redirectedUrl</code></td>
 * <td class="colOne">This step definition is obsolete.</td>
 * <td class="colLast"><div class="block">This step definition doesn't do anything useful at this time. It needs to be revisited. It isn't used.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then the response element &lt;string&gt; = &lt;string&gt;</code></td>
 * <td class="colOne">Works with both JSON and XML responses. Requires a complete path to the element.</td>
 * <td class="colLast"><div class="block">This step definition is used to verify a single element is a response</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then the response redirectTargetUrl is not empty</code></td>
 * <td class="colOne">Works with both JSON and XML. </td>
 * <td class="colLast"><div class="block">This step definition verifies that the redirectTargetUrl element of the response message is included and populated. It isn't used.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then I send the request to get the vfp</code></td>
 * <td class="colOne">This is used only in mobileAuth and works only with JSON.</td>
 * <td class="colLast"><div class="block">Creates the message to get the vfp.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then the &lt;string&gt; tag is not in the final response</code></td>
 * <td class="colOne">Works with both JSON and XML. The full path of the element is required.</td>
 * <td class="colLast"><div class="block">Verifies that the specified element is not in the final response.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then the &lt;string&gt; tag is in the final response</code></td>
 * <td class="colOne">Works with both JSON and XML. The full path of the element is required.</td>
 * <td class="colLast"><div class="block">Verifies that the specified element is in the final response.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then store the &lt;string&gt;</code></td>
 * <td class="colOne">Works with both JSON and XML. The full path of the element is required.</td>
 * <td class="colLast"><div class="block">Stores the value of the specified element for use in another scenario.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then store the response</code></td>
 * <td class="colOne">Works with both JSON and XML.</td>
 * <td class="colLast"><div class="block">Stores the entire response for use in another scenario.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then the response equals the stored response</code></td>
 * <td class="colOne">Works with both JSON and XML.</td>
 * <td class="colLast"><div class="block">Compares the current response to the stored response.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then the http status code is &lt;number&gt;</code></td>
 * <td class="colOne">Works with both JSON and XML.</td>
 * <td class="colLast"><div class="block">Verifies that the httpStatus equals the expected httpStatus.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then the JSON elements are verified</code></td>
 * <td class="colOne">Works with JSON only</td>
 * <td class="colLast"><div class="block">Uses a data table to list the JSON elements and their expected values to validate the actual JSON result.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then compare the &lt;string&gt; with the stored &lt;string&gt;</code></td>
 * <td class="colOne">Works with both JSON and XML. The full path of the element is required</td>
 * <td class="colLast"><div class="block">Compares a stored value with the actual returned value of an element. This implies that the values match.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then the actual &lt;String&gt; does not equal the stored &lt;String&gt;</code></td>
 * <td class="colOne">Works with both JSON and XML. The full path of the element is required.</td>
 * <td class="colLast"><div class="block">Compares the value of an element with the stored value of that element.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then verify from log &lt;String&gt; = from database &lt;String&gt;</code></td>
 * <td class="colOne">Works with both JSON and XML.</td>
 * <td class="colLast"><div class="block">Gets a value from Payfone response in the SessionProcessor log and compares it to a value in the database. The value from the SessionProcessor log must be a JSON Path (e.g., Response.PayfoneAlias).</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then verify from log &lt;String&gt; = from result &lt;String&gt;</code></td>
 * <td class="colOne">Works with both JSON and XML.</td>
 * <td class="colLast"><div class="block">Gets a value from Payfone response in the SessionProcessor log and compares it to a value in the ews Response. Both value must be a JSON Path (e.g., Response.PayfoneAlias). .</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then verify from log &lt;String&gt; = &lt;String&gt;</code></td>
 * <td class="colOne">Works with both JSON and XML.</td>
 * <td class="colLast"><div class="block">Gets a value from Payfone response in the SessionProcessor log and compares it to a value. The value from the SessionProcessor log must be a JSON Path (e.g., Response.PayfoneAlias).</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then verify the following database fields</code></td>
 * <td class="colOne">Works with both JSON and XML.</td>
 * <td class="colLast"><div class="block">This step definition requires a data table as a parameter and is used to perform database validation.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then verify the following vendorLink table fields</code></td>
 * <td class="colOne">Works with both JSON and XML.</td>
 * <td class="colLast"><div class="block">Similar to the above except the database validates against the vendorLink table.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then verify in log request &lt;String&gt; = &lt;String&gt;</code></td>
 * <td class="colOne">Works with both JSON and XML.</td>
 * <td class="colLast"><div class="block">The step definition looks through the SessionProcessor log to retrieve the value of an element in the request to Payfone. The first string variable must be a JSON Path. The second string variable may be an absolute value or a 'get&lt;field&gt;'.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then verify from log against the database</code></td>
 * <td class="colOne">Works with both JSON and XML.</td>
 * <td class="colLast"><div class="block">Verifies multiple values from the Payfone response against the database. This step definition uses a data table to pass in the keys for both the SessionProcessor log and the database.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then verify from log values</code></td>
 * <td class="colOne">Works with both JSON and XML.</td>
 * <td class="colLast"><div class="block">a step that verifies multiple values from the logged Payfone response against their corresponding absolute value. This step used a DataTable for the JsonPath and the absolute value.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then verify from log request values</code></td>
 * <td class="colOne">Works with both JSON and XML.</td>
 * <td class="colLast"><div class="block">Looks through the SessionProcessor log to get the Payfone request where the request id matches the ewSID of the current response. Validates the values in the Payfone request against expected values. This step definition uses a data table.</div></td>
 * </tr> 
 * <tr class="altColor">
 * <td class="colFirst"><code>Then verify from log against the result </code></td>
 * <td class="colOne">Works with both JSON and XML.</td>
 * <td class="colLast"><div class="block">Verifies multiple values from the Payfone response to values in the ews response. A data table is used containing the payfone response keys and the ews response keys (i.e., | payfoneResponseKey | ewsResponseKey |).</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>When the request is sent to cardverify</code></td>
 * <td class="colOne">Posts the JSON request to the Card Verify endpoint for the environment.</td>
 * <td class="colLast"><div class="block">This step definition uses the 'environment.properties' file to populate the card verify endpoint. The message is then posted to that endpoint.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then verify correct result</code></td>
 * <td class="colOne">Works with both JSON and XML.</td>
 * <td class="colLast"><div class="block">Reads the responses.json file to get the expected result for the scenario and the environment. The user then can specify which field from the expected result to compare to the corresponding field in the actual result. This is done via a data table.</div></td>
 * </tr>
 *  <tr class="rowColor">
 * <td class="colFirst"><code>And the database &lt;String&gt; is not equal stored database &lt;String&gt;</code></td>
 * <td class="colOne">Works with JSON only.</td>
 * <td class="colLast"><div class="block">Compares the database value of an element with the stored database value of that element.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst">{@code Then verify from log <String> = <String> = from result <String> = <String>}</td>
 * <td class="colOne">Works with both JSON and XML.</td>
 * <td class="colLast"><div class="block">Performs a double validation. It takes the form of if key = value and key = value.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst">{@code When the request is sent for status code}</td>
 * <td class="colOne">Works only with JSON.</td>
 * <td class="colLast"><div class="block">Sende the current request to the specified end point and does not validate the response http status is 200. If the response http status code is not 200, the step does not fail.</div></td>
 * </tr> 
 * <tr class="altColor">
 * <td class="colFirst">{@code Then verify the log element <string> length is <number>}</td>
 * <td class="colOne">Works only with JSON</td>
 * <td class="colLast"><div class="block">Compares the named log element's length to the expected length passed in as parameter.</div></td>
 * </tr>

 * </tbody>
 * </table>
 * 
 * <table class="memberSummary" border="0" cellpadding="3" cellspacing="0" summary="Test">
 * <caption><span>DataLookup Step Definitions</span><span class="tabEnd">&nbsp;</span></caption>
 * <tr>
 * <th class="colFirst" scope="col">Step Definition</th>
 * <th class="colOne" scope="col">Usage</th>
 * <th class="colLast" scope="col">Description</th></tr>
 * <tbody>
 * <tr class="altColor">
 * <td class="colFirst"><code>Given the datalookup request has the following data</code></td>
 * <td class="colOne">Works only for XML messages</td>
 * <td class="colLast"><div class="block">This step definition requires a DataTable as an argument. A DataTable takes the format
| &lt;name of tag&gt; | &lt;value of tag&gt; |</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Given the following SOAP message</code></td>
 * <td class="colOne">Works only with XML messages.</td>
 * <td class="colLast"><div class="block">This step definition allows the user to input a preformatted SOAP message instead of building a SOAP message. The format of this step definition is as follows:
Given the following SOAP message """ &lt;valid SOAP message&gt; """ This step definition requires the triple quotes around the SOAP message.</div></td>
 * </tr> 
 * <tr class="altColor">
 * <td class="colFirst"><code>Given the xml request has the following data</code></td>
 * <td class="colOne">Works only for XML messages.</td>
 * <td class="colLast"><div class="block">Creates an xml request</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>When I send a xml request with the vfp</code></td>
 * <td class="colOne">Works only for XML messages.</td>
 * <td class="colLast"><div class="block">A message having the vfp element is created and the message is sent to the appropriate endpoint.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Given the following SMS message</code></td>
 * <td class="colOne"></td>
 * <td class="colLast">This step definition constructs an SMS message</td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Given display the message</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">This step definition will display the SMS message as an argument in a popup window</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Given reply to the sms</code></td>
 * <td class="colOne"></td>
 * <td class="colLast">This step definition will prompt the user to input the reply SMS. (ex: AuthQA HELP).</td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Given the user location is</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">This step definition will specify the location of the user.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Given store transaction id</code></td>
 * <td class="colOne"></td>
 * <td class="colLast">This step definition stores the transaction id (e.g., teid for xml, ewSID for json) for use in subsequent tests.</td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Given store confirmation number</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">This step definition stores the confirmation number <i>What is a confirmation number?</i></div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Given store sgid</code></td>
 * <td class="colOne"></td>
 * <td class="colLast">This step definition stores the sgid for use in subsequent tests.</td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Given store VID</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">This step definition stores the VID</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Given store application</code></td>
 * <td class="colOne"></td>
 * <td class="colLast">This step definition stores the name of the application.</td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Given clear the stored entry</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">This step definition clears the stored entry. The key for entry is the input argument.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>When the xml poll request is sent</code></td>
 * <td class="colOne">Used with XML only</td>
 * <td class="colLast">Constructs an XML poll request and repeatedly sends it to the endpoint untill a response other that statusCode 7000 (Session in Progress) is received.</td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>When the sms is sent</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">This step definition posts the SMS message to the server.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>When the request is posted to the service</code></td>
 * <td class="colOne">Works only for XML messages. The containing class sets the endpoint.</td>
 * <td class="colLast"><div class="block">Sets the body of the message to the created xml message and posts the message to the endpoint contained in the 'environment.properties' file.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>When the soapMessage is sent</code></td>
 * <td class="colOne">Works only with XML messages.</td>
 * <td class="colLast"><div class="block">Sets the body of the message to the passed in SOAP message and posts the message to the endpoint.</div></td>
 * </tr> 
 * <tr class="altColor">
 * <td class="colFirst">{@code  When the soap request is posted to <string> with cert}</td>
 * <td class="colOne">Works only for XML messages.</td>
 * <td class="colLast"><div class="block">Sets the body of the message to the created soap message and posts the message to the endpoint that is passed in and then returns the endpoint to its default.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then the following values are verified</code></td>
 * <td class="colOne">Works only for XML messages.</td>
 * <td class="colLast"><div class="block">This step definition requires a DataTable as an argument. A DataTable takes the format
| &lt;name of tag&gt; | &lt;expected value of tag&gt; | </div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then the response values are verified</code></td>
 * <td class="colOne">Works only with XML messages.</td>
 * <td class="colLast"><div class="block">The same as the above definition except the values are verified in the SOAP message.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then the &lt;string&gt; element is not in the message</code></td>
 * <td class="colOne">Works only for XML messages.</td>
 * <td class="colLast"><div class="block">Looks for the named element in the response message. If found, the step fail</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then verify if the length of the element &lt;string&gt; is &lt;number&gt;</code></td>
 * <td class="colOne">Works with XML and JSON messages.</td>
 * <td class="colLast"><div class="block">Retrieves the value of the key mentioned and verifies that the length of the value is equal to the expected length.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then verify the value for the dynamic field &lt;string&gt;</code></td>
 * <td class="colOne">Works for both XML and JSON messages.</td>
 * <td class="colLast"><div class="block">Verifies that the value of the field matches the expected format. This only works with the fields:<ul>
 * 	<li>timestamp</li>
 * 	<li>timestampRequest</li>
 * 	<li>timestampLineAlloc</li>
 * 	<li>timestampConnect</li>
 * 	<li>replyTo</li></ul></div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then verify the sms</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">Displays a dialog to the user to validate that the user received the SMS message on their phone.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then verify the prompts</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">This step definition will display a set of prompts to the user. The user will validate whether or not all 
 * of the prompts were heard.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst"><code>Then verify the if the file exists</code></td>
 * <td class="colOne">This works with both XML and JSON messages</td>
 * <td class="colLast"><div class="block">A file name is constructed from the teid and then the existance of that file is checked.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then the &lt;string&gt; element is in the message</code></td>
 * <td class="colOne"></td>
 * <td class="colLast"><div class="block">Verifies the specified element is in the message.</div></td>
 * </tr>
 * <tr class="altColor">
 * <td class="colFirst">{@code Given a soap message contains the following data}</td>
 * <td class="colOne">Creates a message in a soap envelope.</td>
 * <td class="colLast"><div class="block">A SOAP message is constructed from the supplied data table.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst">{@code When the request is posted to <string>}</td>
 * <td class="colOne">Works only for XML</td>
 * <td class="colLast"><div class="block">Changes the ApiDriver instance's url valiable to the value that was passed in, sets the body of the message, posts the message to the url and then changes the url back to the original endpoint</div></td>
 * </tr> 
 * <tr class="altColor">
 * <td class="colFirst">{@code Then verify caller id is <string>}</td>
 * <td class="colOne">For use on Mobile Device</td>
 * <td class="colLast"><div class="block">Displays a dialog box with the expected caller id for the user to verify.</div></td>
 * </tr> 
 * <tr class="rowColor">
 * <td class="colFirst">{@code Then verify prompt <string> is heard}</td>
 * <td class="colOne">Displays a dialog to the user</td>
 * <td class="colLast"><div class="block"> Displays a dialog box to the user and asks the user to verify the prompt.</div></td>
 * </tr> 
 * 
 * </tbody>
 * </table>
 * 
 * 
 * 
 * <table class="memberSummary" border="0" cellpadding="3" cellspacing="0" summary="Test">
 * <caption><span>Notification Server Step Definitions</span><span class="tabEnd">&nbsp;</span></caption>
 * <tr>
 * <th class="colFirst" scope="col">Step Definition</th>
 * <th class="colOne" scope="col">Usage</th>
 * <th class="colLast" scope="col">Description</th></tr>
 * <tbody>
 * <tr class="altColor">
 * <td class="colFirst"><code>Given the notification request has the values</code></td>
 * <td class="colOne">Works only for JSON Notification Server messages.</td>
 * <td class="colLast"><div class="block">This step definition requires a DataTable as an argument. A DataTable takes the format
| &lt;name of tag&gt; | &lt;value of tag&gt; |</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Given the following notification request</code></td>
 * <td class="colOne">Works only with JSON Notification Server messages.</td>
 * <td class="colLast"><div class="block">This step definition allows the user to input a preformatted Notification Server message instead of message. The format of this step definition is as follows:
Given the following notification request """ &lt;valid notification server message&gt; """ This step definition requires the triple quotes around the message.</div></td>
 * </tr> 
 * <tr class="altColor">
 * <td class="colFirst"><code>Given the current date/time is stored</code></td>
 * <td class="colOne">Works for both JSON and XML messages</td>
 * <td class="colLast"><div class="block">Gets the current date/time and stores it.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>When the notification request is sent</code></td>
 * <td class="colOne">Works only with JSON Notification Server messages.</td>
 * <td class="colLast"><div class="block">Sends the message to the notification server endpoint.</div></td>
 * </tr> 
 * <tr class="altColor">
 * <td class="colFirst"><code>When the notification request is sent for http status</code></td>
 * <td class="colOne">Works for only the JSON Notification Server request</td>
 * <td class="colLast"><div class="block">Continues processing if the htpStatus code is not 200. Normally, if the httpStatus code is not 200, the test fails and processing stops.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then the httpStatus is &lt;number&gt;</code></td>
 * <td class="colOne">Works with both Json and XML messages.</td>
 * <td class="colLast"><div class="block">Matches the last httpStatus code against the expected code.</div></td>
 * </tr> 
 * <tr class="altColor">
 * <td class="colFirst"><code>Then verify the SMS is delivered</code></td>
 * <td class="colOne">Works for only the JSON Notification Server request</td>
 * <td class="colLast"><div class="block">Verifies that the sent SMS message is delivered. Special confifuration is required for the verification.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then verify the SMS is not delivered</code></td>
 * <td class="colOne">Works for only the JSON Notification server request</td>
 * <td class="colLast"><div class="block">Similar to the above but a negative instance.</div></td>
 * </tr> 
 * <tr class="altColor">
 * <td class="colFirst"><code>Then verify short code on device is &lt;number&gt;</code></td>
 * <td class="colOne">Works for only the JSON Notification Server request</td>
 * <td class="colLast"><div class="block">Verifies the SMS message short code. Special confifuration is required for the verification.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst"><code>Then verify response status = &lt;String&gt;</code></td>
 * <td class="colOne">Works for only a JSON request</td>
 * <td class="colLast"><div class="block">Compares the expected status to the actual status</div></td>
 * </tr> 
 * <tr class="altColor">
 * <td class="colFirst"><code>When verify the email was delivered</code></td>
 * <td class="colOne">Works for only the JSON Notification Server request</td>
 * <td class="colLast"><div class="block">Verifies the sent email was delivered. Special configuration is required.</div></td>
 * </tr>
 * <tr class="rowColor">
 * <td class="colFirst">{@code Then verify the message server log values}</td>
 * <td class="colOne">works for both json and xml</td>
 * <td class="colLast"><div class="block">Uses a data table containing the field names and their values. If the field is the clientContext, only the length of the value is validated.</div></td>
 * </tr> 
 * <tr class="altColor">
 * <td class="colFirst">{@code Then verify message server log response status = <number>}</td>
 * <td class="colOne">Works JSON or XML</td>
 * <td class="colLast"><div class="block">Verifies the response status of the POST message is equal to the expected value.</div></td>
 * </tr>
 * </tbody>
 * </table>
 * <p>The Step Definition files use Java 8 lambdas. Java 8 lambdas were chosen because they 
 * provide a cleaner look (no annotations), 
 * and provide an understandable and more concise approach to implementing step 
 * definitions. There is one drawback however. The traditional method of implementing 
 * step definitions used annotated methods. This made each step definition easier to 
 * find in the IDE. The lambdas are all implemented in the constructor of the class
 * so they are not displayed in the class outline in the IDE.</p>
 * <p>To facilitate locating the appropriate step definition the following approach
 * is used: 
 * <ul>
 * 	<li>The Step Definitions will be grouped into classes according to their functions.</li>
 * 	<li>Step definitions will be grouped by their cucumber keyword.</li>
 * 	<li>Step definitions will be described in the order they appear in the class in
 * 		that classes JavaDoc.</li>
 * </ul>
 * <h3>DataTable</h3>
 * <p>The DataTable for the step definitions takes the following format:<br></p><code>
 * 	| &lt;text&gt; | &lt;text&gt; | </code>
 * <p>There can be as many columns and rows as needed. However when creating a rest message name value 
 * pairs are used.</p> 
 *  
 * @author cornettl
 *
 */
package com.earlywarning.authentication.stepdefs;