/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.common;

import com.earlywarning.authentication.startup.Env;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/**
 * A POJO that represents the Authentify JSON request message.
 * This class utilizes the lombok Data and the jackson JsonInclude
 * annotations. The Data annotation implements the setters and getters
 * for the private properties:<ul>
 * 	<li>clientId</li>
 * 	<li>license</li>
 * 	<li>app</li>
 * 	<li>clientAcctId</li>
 * 	<li>clientContext</li>
 * 	<li>event</li>
 * 	<li>data</li>
 * 	<li>user</li></ul>
 * For additional information about the annotations, please see the
 * <a href="{@docRoot}/com/earlywarning/authentication/common/package-summary.html#tags">
 * package-info</a> page.
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_EMPTY)
public class Request {
	private String clientId = "Authentify_Test"; // default value
	private String license = Env.getProperty(Env.getProperty("environment") + "License");
	private String app = "mobileLookupProd"; // default value
	private String clientAcctId = "QATest"; // default value
	private String clientContext = "Authentify_QA_TEST"; // default value
	private String event;
	private com.earlywarning.authentication.common.Data data;
	private User user;
}
