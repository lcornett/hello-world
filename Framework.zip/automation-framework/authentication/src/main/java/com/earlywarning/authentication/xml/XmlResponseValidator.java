/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.xml;

import java.util.Map;
import java.util.Set;

import com.earlywarning.authentication.common.ApiDriver;
import com.earlywarning.authentication.common.StoredParams;

import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;

/**
 * A class that facilitates validation of Rest Response messages in XML format.
 * @author cornettl
 *
 */
@Log4j2
public class XmlResponseValidator implements XmlLookupConstants {
	private static boolean result = true;

	/**
	 * The primary method of the class. it iterates through the map and checks
	 * the response actual values against the expected values. The XmlLookupConstants
	 * class is used to provide the xPath for the element being checked. 
	 * @param response The Response message.
	 * @param map A Map of exxpected responses.
	 * @return true of the all the responses match the expected, false otherwise.
	 */
	public  static boolean validateResponse(Response response, Map<String, String> map) {
		boolean status = true;
		Set<String> keys = map.keySet();
		String regex = "^get[A-Za-z]+";

		try {
			keys.forEach((key) -> {
				switch (key) {
					// keys beginning with A
	                case "account":
	                    validate(response, ACCOUNT, map.get(key));
	                    break;
	                case "action":
	                    validate(response, ACTION, map.get(key));
	                    break;
                    case "application":
                        validate(response, APPLICATION, map.get(key));
                        break;
					case "areaCode":
						String areaCode = "";
						
						if (map.get(key).matches(regex)) {
							areaCode = StoredParams.retrieve("demoNumber").substring(0, 3);
						} else {
							areaCode = map.get(key);
						}
						validate(response, AREA_CODE, areaCode);
						break;
                    case "asid":
                        validate(response, ASID, map.get(key));
                        break;
                        
                    // keys beginning with B
					case "businessIndicator":
						validate(response, BUSINESS_INDICATOR, map.get(key));
						break;
					case "businessNameMatch":
						validate(response, BUSINESS_NAME_MATCH, map.get(key));
						break;
						
					// keysbeginning with C
                    case "confirmNumber":
                        String confirmNumberRegex = "getStoredValue";
                        String confirmNumber="";
                        if(map.get(key).matches(confirmNumberRegex)){
                            confirmNumber=StoredParams.retrieve("confirmationNumber");
                        }
                        validate(response, CONFIRMNUMBER, confirmNumber);
                        break;
                    case "confirmnumberdtmf":
                        validate(response, CONFIRMNUMBERDTMF, map.get(key));
                        break;
                    case "countryCode":
						validate(response, COUNTRY_CODE, map.get(key));
						break;						
					case "currentPhoneType":
						validate(response, CURRENT_PHONE_TYPE, map.get(key));
						break;
						
						// keys beginning with D
						
						// keys beginning with E
					case "exchange":
						String exchange = "";
						
						if (map.get(key).matches(regex)) {
							exchange = StoredParams.retrieve("demoNumber").substring(3, 6);
						} else {
							exchange = map.get(key);
						}
						validate(response, EXCHANGE, exchange);
						break;
					case "exchangeTypeCode":
						validate(response, EXCHANGE_TYPE_CODE, map.get(key));
						break;		
						
					// keys beginning with F
					case "firstNameMatch":
						validate(response, FIRST_NAME_MATCH, map.get(key));
						break;
						
					// keys beinning with G
					case "geolocationLatitude":
						validate(response, GEOLOCATION_LATITUDE, map.get(key));
						break;
					case "geolocationLongitude":
						validate(response, GEOLOCATION_LONGITUDE, map.get(key));
						break;
					case "geolocationName":
						validate(response, GEOLOCATION_NAME, map.get(key));
						break;
					case "geolocationPostalCode":
						validate(response, GEOLOCATION_POSTAL_CODE, map.get(key));
						break;
					case "geolocationProvinceName":
						validate(response, GEOLOCATION_PROVINCE_NAME, map.get(key));
						break;
						
					// keys beginning with H
						
					// keys beginning with I
					case "isLandline":
						validate(response, IS_LANDLINE, map.get(key));
						break;
						
					// keys beginning with J
						
					// keys beginning with K
						
					// keys beginning with L
					case "landlineIndicator":
						validate(response, LANDLINE_INDICATOR, map.get(key));
						break;
                    case "language":
                        validate(response, LANGUAGE, map.get(key));
                        break;
					case "lastNameMatch":
						validate(response, LAST_NAME_MATCH, map.get(key));
						break;
						
					// keys beginning with M
					case "messageText":
						validate(response, MESSAGE_TEXT, map.get(key));
						break;
						
					// keys beginning with N
					case "number":
						String number = "";
						
						if (map.get(key).matches(regex)) {
							number = StoredParams.retrieve("demoNumber").substring(6);
						} else {
							number = map.get(key);
						}
						validate(response, NUMBER, number);
						break;						
					case "numberPortability":
						validate(response, NUMBER_PORTABILITY, map.get(key));
						break;
						
					// keys beginning with O
                    case "orderConfirmation":
                        validate(response, ORDERCONFIRMATION, map.get(key));
                        break;
					case "originalCarrier":
						validate(response, ORIGINAL_CARRIER, map.get(key));
						break;
					case "originalPhoneType":
						validate(response, ORIGINAL_PHONE_TYPE, map.get(key));
						break;
						
					// keys beginning with P
					case "phoneToPostalDistance":
						validate(response, PHONE_TO_POSTAL_DISTANCE, map.get(key));
						break;
					case "populationDensity":
						validate(response, POPULATION_DENSITY, map.get(key));
						break;
					case "portedCarrier":
						validate(response, PORTED_CARRIER, map.get(key));
						break;
					case "postalCodeMatch":
						validate(response, POSTAL_CODE_MATCH, map.get(key));
						break;
						
                    case "postalCode":
                        validate(response, POSTALCODE, map.get(key));
                        break;
    					
                    // keys beginning with Q

                    // keys beginning wiht R
                    case "rateCategory":
                        validate(response, RATECATEGORY, map.get(key));
                        break;
					case "registeredCarrierName":
						validate(response, REGISTERED_CARRIER_NAME, map.get(key));
						break;
                    case "responseType":
                        validate(response, RESPONSETYPE, map.get(key));
                        break;
						
					// keys beginning with S
					case "statusCode":
						validate(response, STATUS_CODE, map.get(key));
						break;
					case "streetAddressMatch":
						validate(response, STREET_ADDRESS_MATCH, map.get(key));
						break;
                    case "streetAddress":
                        validate(response, STREET_ADDRESS, map.get(key));
                        break;
                    case "States":
                        validate(response, STATES, map.get(key));
                        break;
                        
                    // keys beginning with T
                    case "tsoid":
                        validate(response, TSOID, map.get(key));
                        break;
                        
                    // keys beginning with U
                        
                    // keys beginning with V

                    // keys beginning with W
                        
                    // keys beginning with X

                    // keys beginning with Y

                    // keys beginning with Z
					case "zipExchangeDistance":
						validate(response, ZIP_EXCHANGE_DISTANCE, map.get(key));
						break;
					default:
						log.info("The element " + key + " was not found!");
						
				}
			});
		} finally {
			status = result;
			result = true;
		}
		
		return status;	
	}


    /**
     * This method returns the xPath for the element.
     * The XmlLookupConstants class is used to provide the xPath for the element being checked.
     * @param key the element who's path is returned
     * @return true of the all the responses match the expected, false otherwise.
     */
    public static String getXmlKey(String key){
        String xmlKey="";
        switch (key) {
            case "timestamp":
                xmlKey = TIMESTAMP;
                break;
            case "replyTo":
                xmlKey = REPLYTO;
                break;
            case "timestampRequest":
                xmlKey = TIMESTAMPREQUEST;
                break;
            case "timestampLineAlloc":
                xmlKey = TIMESTAMPLINEALLOC;
                break;
            case "timestampConnect":
                xmlKey = TIMESTAMPCONNECT;
                break;
            case "rateCategory":
                xmlKey = RATECATEGORY;
                break;
            default:
                log.info("The element " + key + " was not found!");

        }
        return xmlKey;
    }
	/**
	 * A method that validates the actual values of a SOAP response against the expected values.
	 * This method does not use the XmlLookupConstants to provide the xPath for the elements. 
	 * The xPath value is hardcoded in this method for the elements of interest. If the elements
	 * of the SOAP response to validate are increased, the XmlLookupConstants may be indicated.
	 * @param response The response to the request.
	 * @param map A map of expected values for the named elements.
	 * @return True if the response is validated, false otherwise
	 */
    /*
     * After looking at this method I believe it is not necessary. The validateResponse
     * method should work quite well. I am going to deprecate this method. If I'm wrong,
     * remove the annotation
     */
    @Deprecated
	public static boolean validateSOAPResponse(Response response, Map<String, String> map) {
		boolean status = true;
		Set<String> keys = map.keySet();

		try {
			for (String key : keys) {
				switch (key) {
		        	// keys beginning with A
	                case "asid":
	                    validate(response, ASID, map.get(key));
	                    break;

		        	// keys beginning with B
	                case "businessIndicator":
	                    validate(response, BUSINESS_INDICATOR, map.get(key));
	                    break;
                    case "businessNameMatch":
                        validate(response, BUSINESS_NAME_MATCH, map.get(key));
                        break;


		        	// keys beginning with C
                    case "callForwardDetected":
                        validate(response, CALL_FORWARD_DETECTED, map.get(key));
                        break;
		        
		        	// keys beginning with D
		        
		        	// keys beginning with E
		        
		        	// keys beginning with F
                    case "firstNameMatch":
                        validate(response, FIRST_NAME_MATCH, map.get(key));
                        break;

                    // keys beginning with G
                    case "geolocationLatitude":
                        validate(response, GEOLOCATION_LATITUDE, map.get(key));
                        break;
                    case "geolocationLongitude":
                        validate(response, GEOLOCATION_LONGITUDE, map.get(key));
                        break;
                    case "geolocationName":
                        validate(response, GEOLOCATION_NAME, map.get(key));
                        break;
                    case "geolocationPostalCode":
                        validate(response, GEOLOCATION_POSTAL_CODE, map.get(key));
                        break;
                    case "geolocationProvinceName":
                        validate(response, GEOLOCATION_PROVINCE_NAME, map.get(key));
                        break;

 
                    // keys beginning with H
                        
                    // keys beginning with I
                        
                    // keys beginning with J
                        
                    // keys beginning with K
                        
                    // keys beginning with L
                    case "language":
                        validate(response, LANGUAGE, map.get(key));
                        break;
                    case "lastNameMatch":
                        validate(response, LAST_NAME_MATCH, map.get(key));
                        break;

                    // keys beginning with M
                        
                    // keys beginning with N
                    case "numberPortability":
                        validate(response, NUMBER_PORTABILITY, map.get(key));
                        break;

                    // keys beginning with O
                    case "origCarrier":
                        validate(response, ORIGINAL_CARRIER, map.get(key));
                        break;
 
                    // keys beginning with P
                    case "phoneToPostalDistance":
                        validate(response, PHONE_TO_POSTAL_DISTANCE, map.get(key));
                        break;
                    case "phoneType":
                        validate(response, PHONE_TYPE, map.get(key));
                        break;
                    case "populationDensity":
                        validate(response, POPULATION_DENSITY, map.get(key));
                        break;
                    case "portedCarrier":
                        validate(response, PORTED_CARRIER, map.get(key));
                        break;
                    case "postalCode":
                        validate(response, POSTALCODE, map.get(key));
                        break;

                    // keys beginning with Q
                        
                    // keys beginning with R
                    case "registeredCarrierName":
                        validate(response, REGISTERED_CARRIER_NAME, map.get(key));
                        break;
                    case "responseType":
                    	validate(response, RESPONSETYPE, map.get(key));
                    	break;
  
                    // keys beginning with S                        
					case "statusCode":
						validate(response, "//statusCode/text()", map.get(key));
						break;
                    case "streetAddress":
                        validate(response, STREET_ADDRESS, map.get(key));
                        break;
                        
                    // keys beginning with T
                        
                    // keys beginning with U
                        
                    // keys beginning with V
                        
                    // keys beginning with X
                        
                    // keys beginning with Y
                        
                    // keys beginning with Z
					case "zipExchangeDistance":
                        validate(response, "//zipExchangeDistance/text()", map.get(key));
                        break;

					default:
					log.info("The element " + key + " is not implemented.");
				}
			}
		} finally {
			status = result;
			result = true;
		}
		return status;
	}
	
	/**
	 * A method to validate that the named element is not in the XML response message.
	 * @param response The final response from the original request.
	 * @param element THe element that should not exist.
	 * @return True if the 
	 */
	public static boolean validateNoElement(Response response, String element) {
		boolean result = false;
		String msg = "";
		
		result = ApiDriver.hasXmlElement(response, element);
		
		if (result) {
			msg = "The element " + element + " was found in the response.";
			result = false;
		} else {
			msg = "The element " + element + " was not in the response.";
			result = true;
		}
		
		log.info(msg);
		return result;	
	}


    /**
     * A method to validate that the named element is not in the XML response message.
     * @param response The final response from the original request.
     * @param element THe element that should not exist.
     * @return True if the
     */
    public static boolean validateAttribute(Response response, String element) {
        boolean result = false;
        String msg = "";

        result = ApiDriver.hasXmlAttribute(response, element);

        if (result) {
            msg = "The element " + element + " was found in the response.";
            result = true;
        } else {
            msg = "The element " + element + " was not in the response.";
            result = false;
        }

        log.info(msg);
        return result;
    }

	/**
	 * A method to compare the actual with the expected and update the 
	 * result property of the class. The key to get the actual value
	 * being compared is used.
	 * @param response The message response
	 * @param key The key used to validate. 
	 * @param expected The expected value
	 */
	private static void validate(Response response, String key, String expected) {
		String actual = null;
		
		actual = ApiDriver.retrieveXMLvaluefromTag(response, key);
		
		if (!expected.equals(actual)) {
			String msg = "The actual value for key " + key + " is " + actual + " and does not equal the expected value " + expected + ".";
			log.info(msg);
			updateResult(false);
		} else {
			log.info("The " + key + " element was successfully validated");
		}
		
		
	}
	
	/**
	 * Updates the result property.
	 * @param status The status of the last comparison.
	 */
	private static void updateResult(boolean status) {
		if (result == true && status == false) {
			result = false;
		}
	}
}

