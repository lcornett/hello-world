/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.xmlcompare;

import com.earlywarning.authentication.jsoncompare.StringComparator;
import com.earlywarning.authentication.xml.XmlEventType;

/**
 * A class that compares the elements of the EventType element of the 
 * AuthentXML response message.
 * @author cornettl
 *
 */
class XmlEventTypeComparator extends StringComparator {

	/**
	 * The method that performs the comparison of two XmlEventTypes.
	 * @param expected The object to compare to.
	 * @param actual The object to compare.
	 * @return true if the elements match, false if not.
	 */
	public boolean compare(XmlEventType[] expected, XmlEventType[] actual) {
		String actualValue = null;
		String expectedValue = null;
		
		for (int i = 0; i < expected.length; i++) {
			XmlEventType expectedType = expected[i];
			XmlEventType actualType = actual[i];
			
			actualValue = actualType.getEventType();
			expectedValue = expectedType.getEventType();
			updateStatus(compareString("EventType", expectedValue, actualValue));
			
			expectedValue = expectedType.getLastChangeDate();
			actualValue = actualType.getLastChangeDate();
			updateStatus(compareString("lastChangeDate", expectedValue, actualValue));
			
		}
		return status;
	}
}
