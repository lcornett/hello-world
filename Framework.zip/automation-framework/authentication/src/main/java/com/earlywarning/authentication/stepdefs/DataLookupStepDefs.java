/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.stepdefs;

import com.earlywarning.authentication.applogs.LoggerMapper;
import com.earlywarning.authentication.common.ApiDriver;
import com.earlywarning.authentication.common.StoredParams;
import com.earlywarning.authentication.database.DataValidator;
import com.earlywarning.authentication.soap.PrettyPrinter;
import com.earlywarning.authentication.soap.SoapRequestCreator;
import com.earlywarning.authentication.startup.Env;
import com.earlywarning.authentication.utils.ManualVerifications;
import com.earlywarning.authentication.xml.AuthentXML;
import com.earlywarning.authentication.xml.XmlRequestCreator;
import com.earlywarning.authentication.xml.XmlResponseValidator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import cucumber.api.DataTable;
import cucumber.api.java8.En;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;

import javax.swing.*;
import java.io.File;
import java.util.Map;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * <p>A cucumber Step Definition class using Java 8 lambdas. These step definitions
 * act on messages described in the com.earlywarning.authentication.xml package and 
 * were originally implemented to test the Authentify DataLookup feature. The step 
 * definitions contained in this class are described below.</p>
 * 
 * <p>The 'Given' Step Definitions.<ol>
 * <li><code>Given the datalookup request has the following data</code> - This step definition requires a DataTable as
 * 		an argument. A DataTable takes the format <br> | &lt;name of tag&gt; | &lt;value of tag&gt; | <br>
 * 		Again this step definition allows the user to create a valid XML request using the tags identified.</li>
 * <li><code>Given the xml request has the following values</code> - This step definition requires a DataTable as
 * 		an argument. A DataTable takes the format <br> | &lt;name of tag&gt; | &lt;value of tag&gt; | <br>
 * 		Again this step definition allows the user to create a valid XML request using the tags identified.</li>
 * 	<li><code>Given the following SOAP message</code> - This step definition allows the user to input a preformatted
 * 		SOAP message instead of building a SOAP message. The format of this step definition is as follows:<br>
 * 		<code>Given the following SOAP message
 * 			  """
 * 				&lt;valid SOAP message&gt;
 * 			  """
 * 		</code>This step definition requires the triple quotes around the SOAP message.</li>
 * 	<li>{@code Given a soap message contains the following data} - Creates a SOAP message from the Data Table.</li>
 * </ol>
 * <p>The 'When' Step Definitions.<ol>
 * 	<li><code>When the request is posted to the service</code> - Sets the body of the message to the
 * 		created xml message and posts the message to the endpoint contained in the 'environment.properties'
 * 		file.</li>
 * 	<li>{@code When the request is posted to <string>} - Sets the ApiDriver instance's url to the parameter
 * 		passed in, after setting the body of the message, posts the message to that endpoint.</li>
 * 	<li><code>When the soapMessage is sent</code> - Sets the body of the message to the passed in SOAP 
 * 		message and posts the message to the endpoint.</li>
 * 	<li>{@code When the soap request is posted to <string> with cert} - Posts the soapMessage to the named endpoint
 * 		along with the certificate for authentication, and then sets the endpoint back to the default for the class.</li></ol>
 * <p>The 'Then' Step Definitions.<ol>
 * 	<li><code>Then the following values are verified</code> -  This step definition requires a DataTable as
 * 		an argument. A DataTable takes the format <br> | &lt;name of tag&gt; | &lt;expected value of tag&gt; | <br>
 * 		The values of the named elements are compared against the expected values.</li>
 * 	<li><code>Then the response values are verified</code> - The same as the above definition except the 
 * 		values are verified in the SOAP message.</li>
 * 	<li><code>Then the &lt;string&gt; element is not in the message</code> - Looks for the named element in the response
 * 		message. If found, the step fails.</li>
 * 	<li><code>When the xml poll request is sent</code> - Constructs an XML poll request and sends it the the endpoint
 * 		until a response other than statusCode 7000 (Session in Progress) is received.</li>
 * 	<li><code>Then the element is not in the message</code> - Check if the element mentioned is NOT present in the response.</li>
 * 	<li><code>Then the element is in the message</code> - Check if the element mentioned is present in the response.</li>
 * 	<li><code>Then the attribute is in the message</code> - Check if the attribute mentioned is present in the xml response.</li>
 * 	<li><code>And verify if the length of the element</code> - Retrieves the value of the key mentioned. Verifies if the
 * 	    length of the value string is the same as the expected length.</li>
 * 	<li><code>And verify the value for the dynamic field</code> - Retrieves the value of the key mentioned. Verifies if the
 * 	    value satisfies the properties that element.</li>
 * 	<li><code>Then verify the sms</code> - This stepdef is to check if the user has received the sms. User will press "Yes"
 * 	    if he has received an sms.Else he will press "No".</li>
 * 	<li><code>Given the following sms message</code> - This stepdef is to construct an sms message.</li>
 * 	<li><code>When the sms is sent</code> - This stepdef will post the sms message to the server.</li>
 * 	<li><code>Given display the message</code> - This stepdef will display the string passed as an argument in a pop up window.</li>
 * 	<li><code>Given reply to the sms</code> - This stepdef will ask the user to input the reply SMS. Ex: AuthQa HELP.</li>
 * 	<li><code>Given the user location is</code> - This stepdef will specify the location of the user.</li>
 * 	<li><code>The remove the sms number stored</code> - This stepdef is to clear the phonenumber for sms, which has been
 * 	    previously use.</li>
 * 	<li><code>Then verify the prompts</code> - This stepdef will display a set of prompts for the testcase, so that the
 * 	    user can verify if heard the same set of prompts.</li>
 * 	<li><code>And verify if the file exists</code> - This stepdef will verify if the file in the configured path exists.
 * 	          If the file is not found the stepdef fails.</li>
 * 	 <li><code>Given store transaction id</code> - This stepdef stores the transaction id, teid or the ewSid</li>
 * 	 <li><code>Given store confirmation number</code> - This stepdef stores the confirmation number</li>
 * 	 <li><code>Given store sgid</code> - This stepdef stores the sgid</li>
 * 	 <li><code>Given store VID</code> - This stepdef stores the VID</li>
 * 	 <li><code>When I send a xml request with the vfp</code> - A message having the vfp element is created and the message
 * 		is sent to the appropriate endpoint.</li>
 * 	 <li><code>Given store application</code> - This stepdef stores name of the application</li>
 * 	 <li><code>Given clear the stored entry</code> - This stepdef clears the stored entry. The key for the entry is the input arg</li>
 *	<li>{@code Then verify caller id is <string>} - This is used expressly for verifying caller id on a mobile device.</li>
 *	<li>{@code Then verify prompt <string> is heard} - Displays a dialog box to the user and asks the user to verify the prompt.</li>
 *
 * 	 </ol>
 * 	
 * @author cornettl
 *
 */
@Log4j2
public class DataLookupStepDefs implements En {
	protected static AuthentXML request;
	private static String environment = Env.getProperty("environment");
	private static String endpoint = Env.getProperty(environment + "XmlEndpoint");
	private static ApiDriver driver = new ApiDriver("application/xml", endpoint);

    private static String endpointSms = Env.getProperty(environment + "SmsEndpoint");
    private static ApiDriver driverSms = new ApiDriver("application/x-www-form-urlencoded", endpointSms);


	private static XmlMapper mapper = new XmlMapper();
	private static Response response;
	private static String soapMessage;
    private static String httpMessage;

	
	/**
	 * This constructor contains all of the Step Definition lambdas. It is not intended to 
	 * be used by the automation developer.
	 */
	public DataLookupStepDefs() {
		Given("^the datalookup request has the following data$", (DataTable data) -> {
			Map<String, String> map = data.asMap(String.class, String.class);
			request = XmlRequestCreator.createRequest(map);
		});
		
		Given("^the xml request has the following values$", (DataTable data) -> {
			Map<String, String> map = data.asMap(String.class, String.class);
			request = XmlRequestCreator.createRequest(map);
		});

        When("^I send a xml request with the vfp$", () -> {

            String xmlString = null;

            try {
                request = XmlRequestCreator.createXmlVfpRequest(CommonStepDefs.getVfp());
                xmlString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
                log.info("The vfpRequest is " + xmlString);
                
                driver.setContentType("text/xml");
                driver.setBody(mapper.writeValueAsString(request));
                driver.post();
            } catch (JsonProcessingException e) {
                log.info(e.getMessage());
                log.debug(e.getMessage(), e);
            }
        });


        Given("^the following SOAP message$", (String soapMessage) -> {
            //get phone number from config
            if(soapMessage.contains("<phoneNumber>getConfiguration</phoneNumber>")){
                String environment = Env.getProperty("environment");
                String number = Env.getProperty(environment + "PrimaryPhone");
                soapMessage = soapMessage.replace("getConfiguration", number);
                StoredParams.store("phoneNumber",number);
            }
			DataLookupStepDefs.soapMessage = soapMessage;
		});

		Given("^a SOAP message contains the following data$", (DataTable data) -> {
			Map<String, String> map = data.asMap(String.class, String.class);
			SoapRequestCreator creator = new SoapRequestCreator();
			
			soapMessage = PrettyPrinter.getPrettyMessage(creator.createSoapMessage(map));
		});
		
		When("^the request is posted to the service$", () -> {
			try {
				mapper.enable(SerializationFeature.INDENT_OUTPUT);
				String body = mapper.writeValueAsString(request);
				
				driver.setContentType("text/xml");
				driver.setBody(body);
				log.info("The request sent to the server is:\n" + body);
				driver.post();
				response = ApiDriver.getResp();
			} catch (JsonProcessingException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		});
		
		When("^the request is posted to \"([^\"]*)\"$", (String url) -> {
			try {
				mapper.enable(SerializationFeature.INDENT_OUTPUT);
				String body = mapper.writeValueAsString(request);
				
				driver.setContentType("text/xml");
				driver.setUrl(url);
				driver.setBody(body);
				log.info("The request sent to the server is:\n" + body);
				driver.post();
				response = ApiDriver.getResp();
				driver.setUrl(endpoint);
			} catch (JsonProcessingException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		});
		
		When("^the soap request is posted to \"([^\"]*)\" with cert$", (String url) -> {
			try {
				driver.setContentType("text/xml");
				driver.setUrl(url);
				driver.setBody(soapMessage);
				log.info("The request sent to the server is:\n" + driver.body);
				driver.postWithCert();
				response = ApiDriver.getResp();
				driver.setUrl(endpoint);
			} finally {
				
			}
		});

		
		When("^the soapMessage is sent$", () -> {
			driver.setBody(soapMessage);
			log.info("The request sent to the server is:\n" + soapMessage);
			
			driver.setContentType("text/xml");
			driver.post();
			response = ApiDriver.getResp();
		});

        When("^the soap poll request is sent$", (String soapPollMsg) -> {
            //driver.setBody(soapPollMsg);
            //log.info("The request sent to the server is:\n" + soapPollMsg);
            driver.setContentType("text/xml");
        	driver.soapPoll(soapPollMsg);
            response = ApiDriver.getResp();
        });


		Then("^the following values are verified$", (DataTable data) -> {
			boolean result = false;
			Map<String, String> map = data.asMap(String.class, String.class);
			result = XmlResponseValidator.validateResponse(response, map);
			assertTrue(result);
		});
		
		Then("^the response values are verified$", (DataTable data) -> {
			boolean result = false;
			Map<String, String> map = data.asMap(String.class, String.class);
			result = XmlResponseValidator.validateSOAPResponse(response, map);
			assertTrue(result);
		});

		When("^the xml poll request is sent$", () -> {
			driver.xmlPoll();
			response = ApiDriver.getResp();
		});
		
		Then("^the \"([^\"]*)\" element is not in the message$", (String tag) -> {
			boolean result = false;
			response = ApiDriver.getResp();
			result = XmlResponseValidator.validateNoElement(response, tag);
			assertTrue(result);

		});

        Then("^the \"([^\"]*)\" element is in the message$", (String tag) -> {
            boolean result = false;
            response = ApiDriver.getResp();
            result = XmlResponseValidator.validateNoElement(response, tag);
            assertFalse(result);

        });

        Then("^the \"([^\"]*)\" attribute is in the xml message$", (String tag) -> {
            boolean result = false;
            response = ApiDriver.getResp();
            result = XmlResponseValidator.validateAttribute(response, tag);
            assertTrue(result);

        });

        And("^verify if the length of the element \"([^\"]*)\" is (\\d+)$", (String arg, Integer arg1) -> {
            boolean result = false;

            result = DataValidator.validateValueLength(arg, arg1);
            assertTrue(result);

        });

        And("^verify the value for the dynamic field \"([^\"]*)\"",(String arg) -> {
            log.info("The element is \"" + arg + "\"");

            boolean result = false;
            result = DataValidator.validateDynamicField(arg);
            assertTrue(result);

        });

        Then("^verify the sms$", (String smsReceived) -> {
            boolean result = false;
            String logMsg = null;

            String message = "Please verify if you have received the following code and sms: \"" + smsReceived + " \" ";
            int reply = JOptionPane.showConfirmDialog(null, message, "", JOptionPane.YES_NO_OPTION);
            if (reply == JOptionPane.YES_OPTION) {
                logMsg = "User received SMS";
                log.info(logMsg);
                result = true;
            } else {
                logMsg = "User did not receive SMS";
                log.info(logMsg);
                result = false;
            }

            assertTrue(result);


        });

        Given("^the following sms message$", (String httpMessage) -> {
            boolean isContains = false;
            String smsMessage = "";

            if (httpMessage.contains("smsfrom=getStoredInput")) {
                String phoneNumber = "";
                phoneNumber = StoredParams.retrieve("phonenumberForSMS");
                if (phoneNumber.equals("")) {
                    int limit = 5;
                    for (int i = 0; i < limit; i++) {
                        phoneNumber = JOptionPane.showInputDialog("Please enter the phone number for sms delivery");
                        StoredParams.store("phonenumberForSMS", phoneNumber);

                        String input = "The entered number is " + phoneNumber + ". Do you want to enter again (yes/no)?";
                        int reply = JOptionPane.showConfirmDialog(null, input, "", JOptionPane.YES_NO_OPTION);
                        if (reply == JOptionPane.YES_OPTION) {
                            //do nothing. loop back
                        } else {
                            break;   //no retry
                        }

                    }
                }

                smsMessage = httpMessage.replace("getStoredInput", phoneNumber);
                log.info(smsMessage);

            }
            else if(httpMessage.contains("smsfrom=getUserInput")){
                String env = Env.getProperty("environment");
                String phoneNumber = Env.getProperty(env + "NotificationDestination");
                smsMessage = httpMessage.replace("getUserInput", phoneNumber);
                log.info(smsMessage);

            }



            DataLookupStepDefs.httpMessage = smsMessage;
        });

        When("^the sms is sent$", () -> {
            driverSms.setBody(httpMessage);
            log.info("The request sent to the server is:\n" + httpMessage);
            driverSms.post();
            response = ApiDriver.getResp();
        });

        Given("^display the message$", (String message) -> {

            StoredParams.store("displayMessage", message);
            JOptionPane.showMessageDialog(null, message);
        });

        Given("^reply to the sms$", (String message) -> {

            String reply = JOptionPane.showInputDialog(message);
            //env = qa OR prod
            boolean sendSms = false;
            if(environment.matches("qa")) {
                if ((reply.matches("AuthQa HELP")) || (reply.matches("AuthQa STOP")) || (reply.matches("AuthQa ARRET")) || (reply.matches("AuthQa AIDE"))) {
                    sendSms = true;
                }
            }
            else if (environment.matches("prod")){
                if((reply.matches("HELP")) || (reply.matches("STOP")) || (reply.matches("ARRET")) || (reply.matches("AIDE"))) {
                    sendSms = true;
                }


            }

            assertTrue(sendSms);

        });

        Given("^the user location is$", (String message) -> {

            StoredParams.store("userLocation", message);

        });

        Then("^remove the sms number stored$", () -> {
            StoredParams.remove("phonenumberForSMS");
        });

        Then("^verify the prompts$", (String source) -> {

            //search for the prompts
            boolean found = false;
            boolean findKeys = false;
            boolean res = false;
            int result=0;
            do {
                String input = new String(source);
                found = input.contains("Prompts");
                if (found) {
                    //parse the prompts here
                    int pos = input.indexOf("Prompts");
                    String promptList = input.substring(pos + 10);
                    input = input.replace(promptList, "");
                    String[] prompts = promptList.split("\n");

                    //replace the prompts with the actual strings
                    String prompt = "";
                    for (int i = 0; i < prompts.length; i++) {
                        prompt = Env.getPrompt(prompts[i].trim());
                        prompts[i] = prompts[i] + ":" + prompt;
                    }
                    String newPromptList = String.join("\n", prompts);
                    //log.info(newPromptList);
                    input = input + newPromptList;
                    log.info(input);

                }

                //replace values if any. keys are within %%
                findKeys = input.contains("%");
                if(findKeys) {
                    //parse the keys
                    // find all occurrences of %
                    int[] pos = new int[input.length()];
                    int count = 0;
                    System.out.println(input);
                    System.out.println(input.length());
                    for (int i = 0; i<input.length(); i++) {
                        char c = input.charAt(i);
                        if(c=='%') {
                            pos[count] = i;
                            count++;
                        }
                    }
                    System.out.println(count);
                    System.out.println("pos.length = " + pos.length);
                    for(int i = 0;i<count;i=i+2){
                        String key = input.substring(pos[i]+1, pos[i+1]);
                        //get value
                        String value = StoredParams.retrieve(key);
                        System.out.println(value);
                        //replace the key with value in the actual string
                        input = input.replace("%"+key+"%", value);
                    }
                }

                log.info(input);
                String message = input;

                String[] options = {"PASS", "FAIL", "RETRY"};//0=PASS,1=FAIL,2=RETRY

                result = JOptionPane.showOptionDialog(null, message, "Verify the below prompts by clicking a button",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

                //PASS: set the flag
                if (result == 0) {
                    res = true;
                }
                //FAIL: user has to input the reason for failure
                if (result == 1) {
                    String reason = JOptionPane.showInputDialog("Reason for Failure?");
                    log.info("The reason for failure entered by the user is: " + reason );
                }

                //RETRY
                if (result == 2) {
                    //display the stored message
                    String displayMessage = StoredParams.retrieve("displayMessage");
                    JOptionPane.showMessageDialog(null, displayMessage);

                    try {
                        mapper.enable(SerializationFeature.INDENT_OUTPUT);
                        String body = mapper.writeValueAsString(request);
                        driver.setBody(body);
                        log.info("The request sent to the server is:\n" + body);
                        driver.post();
                        response = ApiDriver.getResp();
                    } catch (JsonProcessingException e) {
                        log.error(e.getMessage());
                        log.debug(e.getMessage(), e);
                    }

                }
            }while(result==2);

            assertTrue(res);
        });

        Then("^verify if the file exists in the path \"([^\"]*)\"$", (String filePath) -> {

            boolean result = false;

            String ewSid = "";
            String teid = "";
            String contentType = "";

            try {
                contentType = ApiDriver.getResp().contentType();

                if (contentType.contains("json")) {
                    ewSid = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), "ewSID");
                } else if (contentType.contains("xml")) {
                    teid = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//teid/text()");
                }
            } catch (Exception e) {
                log.error(e.getMessage());
                log.debug(e.getMessage(), e);
            }

                LoggerMapper mapper = new LoggerMapper();
                String logger = mapper.getLogger();
                log.info("logger = " + logger);
                String[] str = logger.split("\\\\");

                String absoluteFilePath = "\\\\" +str[2] + filePath;

                String application = StoredParams.retrieve("application");

                if ((application.matches("BioCapture"))) {
                    absoluteFilePath = absoluteFilePath + "BioCapture\\recordings\\";
                    log.info(absoluteFilePath);
                    File dir = new File(absoluteFilePath);
                    File[] filesList = dir.listFiles();
                    for (File file : filesList) {
                        if (file.isFile()) {
                            String fileName = file.getName();
                            if (fileName.contains(teid)) {
                                log.info(fileName + ": File exists");
                                result = true;
                            }

                        }
                    }

                }
                else if ((application.matches("BioVerify")) ) {
                    absoluteFilePath = absoluteFilePath + "BioVerify\\recordings\\";
                    log.info(absoluteFilePath);
                    File dir = new File(absoluteFilePath);
                    File[] filesList = dir.listFiles();
                    for (File file : filesList) {
                        if (file.isFile()) {
                            String fileName = file.getName();
                            if (fileName.contains(teid)) {
                                log.info(fileName + ": File exists");
                                result = true;
                            }

                        }
                    }

                }else {

                    String fileName = "";
                    if (contentType.contains("json")) {
                        fileName = absoluteFilePath + "Name." + ewSid + ".wav";
                    } else if (contentType.contains("xml")) {
                        fileName = absoluteFilePath + "Name." + teid + ".wav";
                    }

                    File f = new File(fileName);
                    if (f.exists()) {
                        log.info(fileName + ": File exists");
                        result = true;
                    } else {
                        log.info(fileName + ": File not found");
                    }

                }

            assertTrue(result);

        });

        Given("store transaction id$", () -> {

            String ewSid = "";
            String teid = "";
            String contentType = "";

            try {
                contentType = ApiDriver.getResp().contentType();

                if (contentType.contains("json")) {
                    ewSid = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), "ewSID");
                } else if (contentType.contains("xml")) {
                    teid = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//teid/text()");
                }
            } catch (Exception e) {
                log.error(e.getMessage());
                log.debug(e.getMessage(), e);
            }

            if (!(teid.matches(""))) {
                StoredParams.store("teid", teid);
                log.info("the teid is = " + teid);
            }
            if (!(ewSid.matches(""))) {
                StoredParams.store("ewSid", ewSid);
                log.info("the ewSid is = " + ewSid);
            }
        });

        Given("store confirmation number$", () -> {
            String confirmationNumber = "";
            String contentType = "";

            try {
                contentType = ApiDriver.getResp().contentType();

                if (contentType.contains("json")) {
                    confirmationNumber = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), "confirmNumber");
                } else if (contentType.contains("xml")) {
                    confirmationNumber = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//confirmNumber/text()");
                }
            } catch (Exception e) {
                log.error(e.getMessage());
                log.debug(e.getMessage(), e);
            }

            if(!(confirmationNumber.matches(""))) {
                StoredParams.store("confirmationNumber", confirmationNumber);
            }

        });
        Then("store application$", () -> {
            String application = "";
            String contentType = "";

            try {
                contentType = ApiDriver.getResp().contentType();

                if (contentType.contains("json")) {
                    application = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), "application");
                } else if (contentType.contains("xml")) {
                    application = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//application/text()");
                }
            } catch (Exception e) {
                log.error(e.getMessage());
                log.debug(e.getMessage(), e);
            }

            if(!(application.matches(""))) {
                StoredParams.store("application", application);
            }

        });

        Given("store sgid$", () -> {
            String sgid = "";
            String contentType = "";

            try {
                contentType = ApiDriver.getResp().contentType();

                if (contentType.contains("json")) {
                    sgid = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), "sgid");
                } else if (contentType.contains("xml")) {
                    sgid = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//sgid/text()");
                }
            } catch (Exception e) {
                log.error(e.getMessage());
                log.debug(e.getMessage(), e);
            }

            if (!(sgid.matches(""))) {
                StoredParams.store("sgid", sgid);

            }

        });

        Given("store VID$", () -> {
            String VID = "";
            String contentType = "";

            try {
                contentType = ApiDriver.getResp().contentType();

                if (contentType.contains("json")) {
                    VID = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), "VID");
                } else if (contentType.contains("xml")) {
                    VID = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//VID/text()");
                }
            } catch (Exception e) {
                log.error(e.getMessage());
                log.debug(e.getMessage(), e);
            }

            if (!(VID.matches(""))) {
                StoredParams.store("VID", VID);

            }

        });

        When("^the xml request is posted to a specific url", () -> {
            try {
                mapper.enable(SerializationFeature.INDENT_OUTPUT);
                String body = mapper.writeValueAsString(request);
                driver.sendXmlRequestToSpecificDestn(body);
                response = ApiDriver.getResp();
            } catch (JsonProcessingException e) {
                log.error(e.getMessage());
                log.debug(e.getMessage(), e);
            }

        });

        Given("^clear the stored entry \"([^\"]*)\"", (String arg) -> {
            log.info("The element is \"" + arg + "\"");
            StoredParams.remove(arg);

        });

        Then("^verify caller id is \"([^\"]*)\"$", (String callerId) -> {
            String message = "Verify your phone rings and the CallerId is: " + callerId + ".";
            int result = ManualVerifications.showYesNoMessage(message);
            assertTrue(0 == result);
        });

        Then("^verify prompt \"([^\"]*)\" is heard$", (String prompt) -> {
            String myprompt = Env.getPrompt(prompt);
            String message = "Verify that the following prompt is heard:\n\"" + myprompt + "\"";
            int result = ManualVerifications.showYesNoMessage(message);
            assertTrue(0 == result);
        });
	}
}

