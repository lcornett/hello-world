/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.xmlcompare;

import com.earlywarning.authentication.jsoncompare.StringComparator;
import com.earlywarning.authentication.xml.ResponseData;
import com.earlywarning.authentication.xml.XmlResult;
import com.earlywarning.authentication.xml.XmlStatus;

/**
 * A class that compares the elements of two XmlResult class instances.
 * @author cornettl
 *
 */
class XmlResultComparator extends StringComparator {

	/**
	 * A method that performs the comparison between two instances of the
	 * XmlResult class.
	 * @param expected The object to compare to.
	 * @param actual The object to compare.
	 * @return true if the elements of the objects match, false if not.
	 */
	public boolean compare(XmlResult expected, XmlResult actual) {
		String expectedValue = null;
		String actualValue = null;
		String[] keys = {"action", "data", "status"};
		
		try {
			for (String key : keys) {
				switch (key) {
					case "action":
						expectedValue = expected.getAction();
						actualValue = actual.getAction();
						updateStatus(compareString(key, expectedValue, actualValue));
						break;
					case "data":
						XmlDataComparator dataComparator = new XmlDataComparator();
						ResponseData expectedData = expected.getData();
						ResponseData actualData = actual.getData();
						updateStatus(dataComparator.compare(expectedData, actualData));
						break;
					case "status":
						XMLStatusComparator statusComparator = new XMLStatusComparator();
						XmlStatus expectedStatus = expected.getStatus();
						XmlStatus actualStatus = actual.getStatus();
						updateStatus(statusComparator.compare(expectedStatus, actualStatus));						
						break;
				}
			}
		} finally {
			
		}
		
		return status;
	}
}
