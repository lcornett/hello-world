/**
 * Copyright (c) 2018 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.soap;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import javax.xml.soap.SOAPMessage;

import org.junit.Before;
import org.junit.Test;

public class TestSoapRequestCreator {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testCreateSoapMessage() {
		Map<String, String> data = new HashMap<String, String>();
		data.put("application", "GeoLocation");
		data.put("tsoid", "Apple");
		data.put("action", "PaymentVerify");
		data.put("account", "LloydsTSB");
		data.put("asid", "QA_Test");
		data.put("postalCode", "85087");
		data.put("phoneNumber", "6189734432");
		data.put("amount", "17");
		data.put("language", "en-gb");
		data.put("partialAccountNumber", "6767");
		data.put("fraction", "0");
		data.put("currency", "GBP");
		data.put("partialSortCode", "110697");
		data.put("channel", "business");
		data.put("paymentType", "international");
		data.put("destCountry", "");
		data.put("confirmNumber", "998766");
		data.put("redirectURL", "http://ACHQINF02/push/");
		data.put("delight", "full");
		
		SoapRequestCreator creator = new SoapRequestCreator();
		SOAPMessage message = creator.createSoapMessage(data);

		assertTrue(message != null);
	}

}
