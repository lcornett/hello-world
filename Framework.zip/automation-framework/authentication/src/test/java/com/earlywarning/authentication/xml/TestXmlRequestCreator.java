/**
 * Copyright (c) 2018 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.xml;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

public class TestXmlRequestCreator {
	Map<String, String> map = new HashMap<String, String>();
	
	@Before
	public void setUp() throws Exception {
		map.put("tsoid", "Authentify_Test");
		map.put("application", "mobileLookupProd");
		map.put("account", "QATest");
		map.put("asid", "Authentify_QA_TEST");
		map.put("action", "status");
		map.put("phoneNumber", "getStatusPhone");
		map.put("legacyDeviceId", "12345");
		map.put("consentCollectedDate", "getStatusCollectedDate");
		map.put("consentTransactionId", "getStatusTransactionId");
		map.put("consentDescription", "getStatusDescription");
		map.put("returnlegacydeviceid", "false");
		
	}

	@Test
	public void testCreateRequest() throws JsonProcessingException {
		AuthentXML message = null;
		
		message = XmlRequestCreator.createRequest(map);
		XmlMapper mapper = new XmlMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);
		String request = mapper.writeValueAsString(message);
		System.out.println(request);
		assertNotNull(message);

	}

}
