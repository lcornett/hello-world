package com.earlywarning.jirarestclient;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.apache.http.entity.ContentType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class HeaderCreatorTest {
	HeaderCreator creator;
	
	@Before
	public void setUp() throws Exception {
		creator = new HeaderCreator();
		creator.password = "8FonMlnjFv2JJSpQl9fUJg==";
		creator.username = "iQ2tAbjvOUmJJSpQl9fUJg==";
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCreateHeaders() {
		String credentials = null;
		String regex = "^Basic .+=$";
		
		credentials = creator.encodeCreds();
		assertTrue(credentials.matches(regex));
	}

	@Test
	public void testEncodeCreds() {
		HttpHeaders headers = null;
		Map<String, String> headerData = new HashMap<String, String>();
		
		headerData.put("Authorization",creator.encodeCreds());
		headerData.put("Content-Type", ContentType.APPLICATION_JSON.toString());
		headers = creator.createHeaders(headerData);
		assertNotNull(headers);
	}

}
