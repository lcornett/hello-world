/**
 * Copyright (c) 2018 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.applogs;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class TestMsLogParser {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	@Ignore
	public void testParseLog() {
		MsLogParser parser = new MsLogParser();
		String[] servers = {"C:\\Development","C:\\Development"};
		parser.parseLog(servers);

	}

}
