/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.applogs;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.earlywarning.authentication.common.ApiDriver;

import io.restassured.config.JsonConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.internal.ResponseParserRegistrar;
import io.restassured.internal.RestAssuredResponseImpl;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;

public class TestLoggerMapper {

	@Before
	public void setUp() throws Exception {
		setResponse();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetLogger() {
		LoggerMapper mapper = new LoggerMapper();
		String id = mapper.getLogger();
		System.out.println(id);
		
		assertNotNull(id);
	}
	
	@Test
	public void testGetLoggerXML() {
		setXmlResponse();
		
		LoggerMapper mapper = new LoggerMapper();
		String id = mapper.getLogger();
		System.out.println(id);
		
		assertNotNull(id);
	}
	
	@ Test
	public void testGetMSLogger() {
		LoggerMapper mapper = new LoggerMapper();
		String[] loggers = mapper.getMsLogger();
		assertTrue(loggers.length == 2);
		assertTrue(loggers[0].equals("\\\\achqinf01.authentify.inc\\authentify$"));
		assertTrue(loggers[1].equals("\\\\achqsp01.authentify.inc\\authentify$"));
	}

	private void setResponse() {
		RestAssuredResponseImpl impl = new RestAssuredResponseImpl();
		Response response = null;
		String content = "{\"clientId\": \"Authentify_Test\",\"clientContext\": \"Authentify_QA_TEST\"," +
				"\"sgid\": \"d7c892fd-b139-49e7-b362-125d418e3079\",\"app\": \"mobileLookupProd\"," + 
				"\"clientAcctId\": \"QATest\",\"ewSID\": \"d3645065-ed7a-4588-88ce-4b8c03dd6e22\"," + 
				"\"replyTo\": \"https://q1.authentify.com/getSessionStatus?id=786f0e08a394fe7a1b6bb46c5d4570da2cf66e58\"," + 
				"\"timestampISO8601\": \"2017-10-10T16:14:23Z\",\"event\": \"status\",\"statusCode\": \"0\"," + 
				"\"data\": {\"dataLookup\": {\"mobileIdentityCreated\": \"4 to 6 years\",\"mobileOperatorName\": \"Verizon\"," + 
				"\"lastChangeEvents\": [{\"value\": \"DeviceChange\",\"lastChangeDate\": \"2017-01-06T21:42:54Z\"}," + 
				"{\"value\": \"SIMSwap\",\"lastChangeDate\": \"2017-01-06T21:42:54Z\"}]," + 
				"\"statusIndex\": \"e5\"},\"phoneNumber\": \"17733185771\",\"ewDeviceId\": \"5a4b230b-ca74-4cf1-9b3c-2bf08bd50026\"" + 
				"}}";
		impl.setContent(content);
		impl.setContentType("application/json");
		ResponseParserRegistrar rpr = new ResponseParserRegistrar();
		rpr.registerParser("application/json", Parser.JSON);
		impl.setRpr(rpr);
		impl.setConfig(new RestAssuredConfig().jsonConfig(new JsonConfig()));
		response = impl;
		ApiDriver.setResp(response);
	}
	
	private void setXmlResponse() {
		RestAssuredResponseImpl impl = new RestAssuredResponseImpl();
		Response response = null;
		String content = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + 
				"<AuthentXML xmlns=\"http://xml.authentify.net/MessageSchema.xml\" version=\"1.0\">" + 
				"<header><tsoid>Authentify_Test</tsoid><asid>Authentify_QA_TEST</asid><sgid>9f9b2cc4-f3ce-4036-9235-82df792a2b96</sgid>" + 
				"<application>mobileLookupProd</application><account>QATest</account><teid>431bf856-83b2-44cd-8e58-1fe3c8754739</teid>" + 
				"<replyTo>https://q1.authentify.com/s2s/default.asp?id=70e5aa4063e9396fd8e5bc4be49dbe14ffcd5771</replyTo>" + 
				"<timestamp>2017-02-20T17:13:08Z</timestamp></header><body><result><action>status</action>" + 
				"<data xmlns=\"http://xml.authentify.net/MessageSchema.xml\" xmlns:dat=\"http://xml.authentify.net/CommonDataSchema.xml\">" + 
				"<dat:dataLookup><dat:mobileIdentityCreated>4 to 6 years</dat:mobileIdentityCreated>" + 
				"<dat:mobileOperatorName>Verizon</dat:mobileOperatorName><dat:lastChangeEvents>" + 
				"<dat:EventType lastChangeDate=\"2017-01-06T21:42:54Z\">DeviceChange</dat:EventType>" + 
				"<dat:EventType lastChangeDate=\"2017-01-06T21:42:54Z\">SIMSwap</dat:EventType></dat:lastChangeEvents>" + 
				"<dat:statusIndex>e5</dat:statusIndex></dat:dataLookup><dat:phoneNumber>17733185771</dat:phoneNumber>" + 
				"<dat:ewDeviceId>5a4b230b-ca74-4cf1-9b3c-2bf08bd50026</dat:ewDeviceId></data><status><statusCode>0</statusCode>" + 
				"</status></result></body></AuthentXML>";
		impl.setContent(content);
		impl.setContentType("text/xml");
		ResponseParserRegistrar rpr = new ResponseParserRegistrar();
		rpr.registerParser("text/xml", Parser.XML);
		impl.setRpr(rpr);
		impl.setConfig(new RestAssuredConfig().jsonConfig(new JsonConfig()));
		response = impl;
		ApiDriver.setResp(response);
			
	}

}
