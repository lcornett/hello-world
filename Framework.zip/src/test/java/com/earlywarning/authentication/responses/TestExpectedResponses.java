/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.responses;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.earlywarning.authentication.applogs.ResponseSetter;
import com.earlywarning.authentication.stepdefs.EmptyStepDef;

import cucumber.api.Scenario;


public class TestExpectedResponses {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testCompareXML() {
		Scenario scenario = mock(Scenario.class);
		when(scenario.getName()).thenReturn("Verify successful MS. phoneNumber is used. ewDeviceId empty. Verify logs. AccountID=6129");
		EmptyStepDef.scenario = scenario;
		
		ResponseSetter.setXmlResponse();
		Map<String, String> map = new HashMap<String, String>();
		map.put("/AuthentXML/body/result/action", "/AuthentXML/body/result/action");
		map.put("/AuthentXML/body/result/data/dataLookup/mobileIdentityCreated", "/AuthentXML/body/result/data/dataLookup/mobileIdentityCreated");
		
		ResultComparator comp = new ResultComparator();
		assertTrue(comp.compare(map));
	}
	
	@Test
	public void testCompareJSON() {
		Scenario scenario = mock(Scenario.class);
		when(scenario.getName()).thenReturn("Verify successful MS. phoneNumber is used. ewDeviceId empty. Verify logs. AccountID=6129");
		EmptyStepDef.scenario = scenario;
		
		ResponseSetter.setResponse();
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("event", "event");
		map.put("data.dataLookup.mobileIdentityCreated", "data.dataLookup.mobileIdentityCreated");
		
		ResultComparator comp = new ResultComparator();
		assertTrue(comp.compare(map));
	}
	
	private void writeToFile(String json) throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter("responses.json"));
		writer.write(json);
		
		writer.close();
		
	}

}
