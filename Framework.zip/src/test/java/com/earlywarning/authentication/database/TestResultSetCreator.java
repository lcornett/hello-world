/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.commons.dbcp2.BasicDataSource;
import org.junit.Before;
import org.junit.Test;

import com.earlywarning.authentication.applogs.ResponseSetter;

public class TestResultSetCreator {
	
	@Before
	public void setUp() throws Exception {
		ResponseSetter.setResponse();
		
		ResultSetMetaData mockRsmd = mock(ResultSetMetaData.class);
		when(mockRsmd.getColumnName(anyInt())).thenReturn("columnName").thenReturn("column2");
		when(mockRsmd.getColumnCount()).thenReturn(3);
		
		ResultSet mockResultSet = mock(ResultSet.class);
		when(mockResultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
		when(mockResultSet.getString(anyString())).thenReturn("1234").thenReturn("Larry").thenReturn("Cornett");
		when(mockResultSet.getMetaData()).thenReturn(mockRsmd);
		
		
		
		Statement mockStatement = mock(Statement.class);
		when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);	
		
		PreparedStatement mockStmt = mock(PreparedStatement.class);
		when(mockStmt.executeQuery()).thenReturn(mockResultSet);

		Connection mockConn = mock(Connection.class);
		when(mockConn.prepareStatement(anyString())).thenReturn(mockStmt);
		when(mockConn.createStatement()).thenReturn(mockStatement);
		
		BasicDataSource mockBds = mock(BasicDataSource.class);
		when(mockBds.getConnection()).thenReturn(mockConn);

		DataSource.bds = mockBds;
	}

	@Test
	public void testResultSetCreator() {
		ResultSetCreator creator = new ResultSetCreator();
		assertNotNull(creator);
	}
	
	@Test
	public void testResultSetCreatorString() {
		String teid = "5a4b230b-ca74-4cf1-9b3c-2bf08bd50026";
		ResultSetCreator creator = new ResultSetCreator(teid);
		assertNotNull(creator);
	}

	@Test
	public void testGetResultSet() {
		String teid = "5a4b230b-ca74-4cf1-9b3c-2bf08bd50026";
		ResultSetCreator creator = new ResultSetCreator(teid);
		ArrayList<TableRecord> result = null;
		
		result = creator.getResultSet();
		assertTrue(result instanceof ArrayList<?>);
		assertTrue(result.get(0) instanceof TableRecord);
	}
	
	@Test (expected=NullPointerException.class)
	public void testGetResultSetSQLException() {
		String teid = "5a4b230b-ca74-4cf1-9b3c-2bf08bd50026";
		ResultSetCreator creator = new ResultSetCreator(teid);
		ArrayList<TableRecord> result = null;
		
		try {
			ResultSet mockResultSet = mock(ResultSet.class);
			when(mockResultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
			when(mockResultSet.getString(anyString())).thenReturn("1234").thenReturn("Larry").thenReturn("Cornett");

			Statement mockStatement = mock(Statement.class);
			when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);	
			PreparedStatement mockStmt = mock(PreparedStatement.class);
			when(mockStmt.executeQuery()).thenThrow(SQLException.class);
			
			Connection mockConn = mock(Connection.class);
			when(mockConn.prepareStatement(anyString())).thenReturn(mockStmt);
			when(mockConn.createStatement()).thenReturn(mockStatement);


			BasicDataSource mockBds = mock(BasicDataSource.class);
			when(mockBds.getConnection()).thenReturn(mockConn);

			DataSource.bds = mockBds;
			
			result = creator.getResultSet();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		assertTrue(result instanceof ArrayList<?>);
		assertTrue(result.get(0) instanceof TableRecord);
	}
	
	@Test (expected=IndexOutOfBoundsException.class)
	public void testGetResultSetException() {
		String teid = "5a4b230b-ca74-4cf1-9b3c-2bf08bd50026";
		ResultSetCreator creator = new ResultSetCreator(teid);
		ArrayList<TableRecord> result = null;
		
		try {
			ResultSet mockResultSet = mock(ResultSet.class);
			when(mockResultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
			when(mockResultSet.getString(anyString())).thenReturn("1234").thenReturn("Larry").thenReturn("Cornett");

			Statement mockStatement = mock(Statement.class);
			when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);	
			PreparedStatement mockStmt = mock(PreparedStatement.class);
			when(mockStmt.executeQuery()).thenThrow(Exception.class);
			
			Connection mockConn = mock(Connection.class);
			when(mockConn.prepareStatement(anyString())).thenReturn(mockStmt);
			when(mockConn.createStatement()).thenReturn(mockStatement);


			BasicDataSource mockBds = mock(BasicDataSource.class);
			when(mockBds.getConnection()).thenReturn(mockConn);

			DataSource.bds = mockBds;
			
			result = creator.getResultSet();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		assertTrue(result instanceof ArrayList<?>);
		assertTrue(result.get(0) instanceof TableRecord);
	}



	@Test
	public void testGetResultSetXml() {
		ResponseSetter.setXmlResponse();
		String teid = "5a4b230b-ca74-4cf1-9b3c-2bf08bd50026";
		ResultSetCreator creator = new ResultSetCreator(teid);
		ArrayList<TableRecord> result = null;
		
		result = creator.getResultSet();
		assertTrue(result instanceof ArrayList<?>);
		assertTrue(result.get(0) instanceof TableRecord);
	}

	@Test
	public void testGetVendorLinkData() {
		ResultSetCreator creator = new ResultSetCreator();
		ArrayList<TableRecord> result = null;
		
		result = creator.getVendorLinkData();
		
		assertTrue(result instanceof ArrayList<?>);
		assertTrue(result.get(0) instanceof TableRecord);
	}
	
	@Test 
	public void testGetVendorLinkDataWithSQLException() {
		ResultSetCreator creator = new ResultSetCreator();
		ArrayList<TableRecord> result = null;
		
		try {
			ResultSet mockResultSet = mock(ResultSet.class);
			when(mockResultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
			when(mockResultSet.getString(anyString())).thenReturn("1234").thenReturn("Larry").thenReturn("Cornett");

			Statement mockStatement = mock(Statement.class);
			when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);	
			PreparedStatement mockStmt = mock(PreparedStatement.class);
			when(mockStmt.executeQuery()).thenThrow(SQLException.class);
			
			Connection mockConn = mock(Connection.class);
			when(mockConn.prepareStatement(anyString())).thenReturn(mockStmt);
			when(mockConn.createStatement()).thenReturn(mockStatement);


			BasicDataSource mockBds = mock(BasicDataSource.class);
			when(mockBds.getConnection()).thenReturn(mockConn);

			DataSource.bds = mockBds;
			
			result = creator.getVendorLinkData();
			assertTrue(result.size() == 0);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
		@Test (expected=IndexOutOfBoundsException.class)
		public void testGetVendorLinkDataWithException() {
			ResultSetCreator creator = new ResultSetCreator();
			ArrayList<TableRecord> result = null;
			
			try {
				ResultSet mockResultSet = mock(ResultSet.class);
				when(mockResultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false).thenReturn(true).thenReturn(false);
				when(mockResultSet.getString(anyString())).thenReturn("1234").thenReturn("Larry").thenReturn("Cornett");

				Statement mockStatement = mock(Statement.class);
				when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);	
				PreparedStatement mockStmt = mock(PreparedStatement.class);
				when(mockStmt.executeQuery()).thenThrow(Exception.class);
				
				Connection mockConn = mock(Connection.class);
				when(mockConn.prepareStatement(anyString())).thenReturn(mockStmt);
				when(mockConn.createStatement()).thenReturn(mockStatement);


				BasicDataSource mockBds = mock(BasicDataSource.class);
				when(mockBds.getConnection()).thenReturn(mockConn);

				DataSource.bds = mockBds;
				
				result = creator.getVendorLinkData();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		
		assertTrue(result instanceof ArrayList<?>);
		assertTrue(result.get(0) instanceof TableRecord);
	}


	@Test
	public void testGetVendorLinkDataXml() {
		ResponseSetter.setXmlResponse();
		ResultSetCreator creator = new ResultSetCreator();
		ArrayList<TableRecord> result = null;
		
		result = creator.getVendorLinkData();
		
		assertTrue(result instanceof ArrayList<?>);
		assertTrue(result.get(0) instanceof TableRecord);
	}
}
