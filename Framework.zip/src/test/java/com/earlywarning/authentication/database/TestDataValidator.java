/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.earlywarning.authentication.applogs.ResponseSetter;
import com.earlywarning.authentication.common.ApiDriver;

import io.restassured.config.JsonConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.internal.ResponseParserRegistrar;
import io.restassured.internal.RestAssuredResponseImpl;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;

public class TestDataValidator {
	Response response;
	RestAssuredResponseImpl impl;
	
	
	@Before
	public void setUp() throws Exception {			
		ResultSetCreator cr = mock(ResultSetCreator.class);
		when(cr.getVendorLinkData()).thenReturn(createVendorLinkData());
		when(cr.getResultSet()).thenReturn(createData());
		DataValidator.creator = cr;
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test	
	public void testValidateData() {
		ResponseSetter.setResponse();
		Map<String, String> map = new HashMap<String, String>();
		map.put("State", "ParmsOK");
		map.put("Status", "0");
		map.put("Action", "status");
		map.put("phoneNumber", "getStatusPhone");
		map.put("asID", "Authentify_QA_TEST");
		map.put("sessionresources.Status", "0");
		map.put("resourceID", "9");
		map.put("HashPhone", "getEwDeviceId");
		map.put("SubType", "0");
		
		assertTrue(DataValidator.validateData(map));
	}
	
	@Test	
	public void testValidateDataXml() {
		ResponseSetter.setXmlResponse();
		Map<String, String> map = new HashMap<String, String>();
		map.put("State", "ParmsOK");
		map.put("Status", "0");
		map.put("Action", "status");
		map.put("phoneNumber", "getStatusPhone");
		map.put("asID", "Authentify_QA_TEST");
		map.put("sessionresources.Status", "0");
		map.put("resourceID", "9");
		map.put("HashPhone", "getEwDeviceId");
		map.put("SubType", "0");
		
		assertTrue(DataValidator.validateData(map));
	}


	@Test
	public void testValidateVendorLink() {
		ResponseSetter.setResponse();
		Map<String, String> map = new HashMap<String, String>();
		map.put("InternalGUID", "getEwDeviceId");
		map.put("phoneNumber", "getResultPhoneNumber");
		map.put("AccountID", "6129");
		map.put("SOID", "8");
		map.put("ExternalGUID", "C8DF1D0C4VK8384E2F39618E23DE91EC00MEKIOMIXT9P23117637AB91EFB4BF4B1CCFB87B802F962F6G32657AF56C48D3FA2BB70D76CD00B0B311AC4");
		
		assertTrue(DataValidator.validateVendorLink(map));
	}
	
	@Test
	public void testValidateVendorLinkXml() {
		ResponseSetter.setXmlResponse();
		Map<String, String> map = new HashMap<String, String>();
		map.put("InternalGUID", "getEwDeviceId");
		map.put("phoneNumber", "getResultPhoneNumber");
		map.put("AccountID", "6129");
		map.put("SOID", "8");
		map.put("ExternalGUID", "C8DF1D0C4VK8384E2F39618E23DE91EC00MEKIOMIXT9P23117637AB91EFB4BF4B1CCFB87B802F962F6G32657AF56C48D3FA2BB70D76CD00B0B311AC4");
		
		assertTrue(DataValidator.validateVendorLink(map));
	}

	@Test
	public void testValidateValueLengthXml() {
		ResponseSetter.setXmlResponse();
		
		assertTrue(DataValidator.validateValueLength("tsoid", 15));
	}
	
	@Test
	public void testValidateValueLengthJson() {
		ResponseSetter.setResponse();
		
		assertTrue(DataValidator.validateValueLength("clientContext", 18));
	}
	
	@Test
	public void testValidateValueLengthNoType() {
		ResponseSetter.setResponseNoContentType();
		
		assertFalse(DataValidator.validateValueLength("clientContext", 18));
	}



	@Test
	public void testGetEwDeviceIdXml() {
		
		ResponseSetter.setXmlResponse();
		assertEquals("5a4b230b-ca74-4cf1-9b3c-2bf08bd50026",DataValidator.getEwDeviceId());
	}

	@Test
	public void testGetLegacyDeviceIdJson() {
		
		ResponseSetter.setResponse();
		assertEquals("5a4b230b-ca74-4cf1-9b3c-2bf08bd50026",DataValidator.getLegacyDeviceId());
	}
	
	@Test
	public void testGetPhoneNumberXml() {
		
		ResponseSetter.setXmlResponse();
		assertEquals("17733185771",DataValidator.getPhoneNumber());
	}

	@Test
	public void testGetPhoneNumberJson() {
		
		ResponseSetter.setXmlResponse();
		assertEquals("17733185771",DataValidator.getPhoneNumber());
	}

	@Test
	public void testGetLegacyDeviceIdXml() {
		
		ResponseSetter.setXmlResponse();
		assertEquals("5a4b230b-ca74-4cf1-9b3c-2bf08bd50026",DataValidator.getLegacyDeviceId());
	}


	@Test
	public void testGetEwDeviceIdJson() {
		
		ResponseSetter.setResponse();
		assertEquals("5a4b230b-ca74-4cf1-9b3c-2bf08bd50026",DataValidator.getEwDeviceId());
	}
	
	@Test
	public void testValidateDynamicField() {
		ResponseSetter.setResponse();
		
		assertFalse(DataValidator.validateDynamicField("timestampISO8601"));
	}
	
	@Test
	public void testValidateDYnamicFieldReplyTo() {
		ResponseSetter.setResponse();
		
		assertTrue(DataValidator.validateDynamicField("replyTo"));
	}

	private void setResponse() {
		RestAssuredResponseImpl impl = new RestAssuredResponseImpl();
		String content = "{\"clientId\": \"Authentify_Test\",\"clientContext\": \"Authentify_QA_TEST\"," +
				"\"sgid\": \"d7c892fd-b139-49e7-b362-125d418e3079\",\"app\": \"mobileLookupProd\"," + 
				"\"clientAcctId\": \"QATest\",\"ewSID\": \"d3645065-ed7a-4588-88ce-4b8c03dd6e22\"," + 
				"\"replyTo\": \"https://q2.authentify.com/getSessionStatus?id=786f0e08a394fe7a1b6bb46c5d4570da2cf66e58\"," + 
				"\"timestampISO8601\": \"2017-10-10T16:14:23Z\",\"event\": \"status\",\"statusCode\": \"0\"," + 
				"\"data\": {\"dataLookup\": {\"mobileIdentityCreated\": \"4 to 6 years\",\"mobileOperatorName\": \"Verizon\"," + 
				"\"lastChangeEvents\": [{\"value\": \"DeviceChange\",\"lastChangeDate\": \"2017-01-06T21:42:54Z\"}," + 
				"{\"value\": \"SIMSwap\",\"lastChangeDate\": \"2017-01-06T21:42:54Z\"}]," + 
				"\"statusIndex\": \"e5\"},\"phoneNumber\": \"17733185771\",\"ewDeviceId\": \"5a4b230b-ca74-4cf1-9b3c-2bf08bd50026\"" + 
				"}}";
		impl.setContent(content);
		impl.setContentType("application/json");
		ResponseParserRegistrar rpr = new ResponseParserRegistrar();
		rpr.registerParser("application/json", Parser.JSON);
		impl.setRpr(rpr);
		impl.setConfig(new RestAssuredConfig().jsonConfig(new JsonConfig()));
		response = impl;
		ApiDriver.setResp(response);

	}
	
	private ArrayList<TableRecord> createVendorLinkData() {
		ArrayList<TableRecord> records = new ArrayList<TableRecord>();
		VendorLinkRecord record = new VendorLinkRecord();
		record.setAccountId("6129");
		record.setExternalGuid("C8DF1D0C4VK8384E2F39618E23DE91EC00MEKIOMIXT9P23117637AB91EFB4BF4B1CCFB87B802F962F6G32657AF56C48D3FA2BB70D76CD00B0B311AC4");
		record.setInternalGuid("5a4b230b-ca74-4cf1-9b3c-2bf08bd50026");
		record.setPhoneNumber("17733185771");
		record.setSoid("8");
		records.add(record);
		
		return records;		
	}
	
	private ArrayList<TableRecord> createData() {
		ArrayList<TableRecord> records = new ArrayList<TableRecord>();
		SessionInfoRecord record = new SessionInfoRecord();
		record.setState("ParmsOK");;
		record.setAction("status");
		record.setAccountId("6129");
		record.setStatus("0");
		records.add(record);
		
		SessionInfoSoRecord record2 = new SessionInfoSoRecord();
		record2.setAsId("Authentify_QA_TEST");
		record2.setPhoneNumber("7733185771");
		record2.setSessionTag("NULL");
		record2.setTimestamp("2017-10-10 20:22:41.487");
		records.add(record2);
		
		SessionResourcesRecord record3 = new SessionResourcesRecord();
		record3.setHashphone("5a4b230b-ca74-4cf1-9b3c-2bf08bd50026");
		record3.setResourceid("9");
		record3.setStatus("0");
		record3.setSubtype("0");
		records.add(record3);
		
		return records;				
	}

}
