## Release 1.0.0 Notes
The functionality in this release of the Authentify Cucumber Testing Framework consists of

- Step Definitions.

- An encryption utility.

- A rest client to connect to JIRA XRay.

- Scripts, both batch and linux shell, to start the execution of the framework.

### Step Definitions
The step definitions are implemented for the following features:

#### Payfone functional test suite
* ccvEcho - The endpoint that allows a user to determine if the service is running.
* Call Center Verification - Provides comprehensive information about a mobile subscriber making a call to a call center.	
* Mobile Authentication - Mobile authentication is used to verify the phone number for a given device and retrieve its payfone ID for use with future lookups.
* Mobile Status - Mobile Status is used to provide contextual attributes about a device and its owner.  This service can also be used to monitor status changes within the mobile network including phone number changes, SIM swaps, device upgrades, and ports. 
* Mobile Identity - Mobile Identity is used to check identity parameters against the ownership of record for a given mobile number.
* Mobile Number Verification - Mobile Status is used to provide contextual attributes about a device and its owner.  This service can also be used to monitor status changes within the mobile network including phone number changes, SIM swaps, device upgrades, and ports. 
* Get Intelligence - Get Intelligence is a variant of mobile status and is used to provide contextual attributes about a device and its owner. This service can also be used to monitor status changes within the mobile network including phone number changes, SIM swaps, device upgrades and ports.

#### DataLookup functional tests
* Full DataLookup -  The DataLookup application performs a reverse number lookup on the telephone number. The application is intended to return data associated with the telephone number.
* Citi Bank - This SMSDelivery application sends a text message to the user’s mobile phone number and delivers a one-time security code. The applications are intended to authenticate the user’s web session synchronizing with one-time security code that is delivered via SMS. The application also performs a check to determine if the number the SMS is to be sent to is a landline phone. Citibank will send the appropriate compliance message text in the XML request.This release made the script for synchronous to be compatible with IR 9.3.
* Green Dot - The Green Dot Mobile Check application performs a data lookup on a specified phone number to determine whether the number in question is a for a land line or a cellular telephone.
* Butterfield - Uses the TransactionVerify application places a call to the user and prompts them through a series of keypad entry sequences. The application is intended to authenticate the user’s web session synchronizing with a pin number delivered over the telephone. SOAP polling, DataLookup, CFD preferred.
* Apple Geolocate - The GeoLocate application performs an immediate retrieval of the distance in kilometers between the telephone exchange and the postal code associated with a telephone number.  The data and the comparison are then returned to the customer.

#### Responsive Web Functional tests
* Responsive Web - This interface will allow the responsive web to create a user, set a password, verify a password, and remove the user from the system.  The user in question will be an userId address and can be tied to the same user from the mobile device application.

#### Card Verification Service functional tests
* Card Verification Service - Card Verification requires the caller to provide the P2P User ID (GUID), the card CVV, and will provide a response back indicating whether the card is still good and whether the address on file for the user still matches that of the card.  The Authentify platform will utilize the Admin App CRUD service to retrieve the card and address information on file for the provided User ID.   It will then use that information   along with the CVV provided in order to call the debit service card-inquiry and provide the results of that query to the caller.

#### Notification Server Functional Tests
* Send EMail -  A new interface has been added to the AU platform to support any 
  internal EW application to send Email messages.  This page will 
  describe the interface to this new API and give the response codes 
  for the API.
* Send SMS -  A new interface has been added to the AU platform to support any 
  internal EW application to send Email messages.  This page will 
  describe the interface to this new API and give the response codes 
  for the API.
* Reporting - Step definitions for getUserSummmary and getUserMessage test cases are implemented. 

### Jira Rest Client
* The ability to access JIRA Xray via rest is included in this release. The reasons to access JIRA are to export the feature files to be executed from the tests/test sets in JIRA and to import the test results into JIRA

### Start Scripts
* The ability to start the automation framework from the command line is included in this release. There are two scripts for windows and one script for Linux or Mac. The cucumber-tests.bat script is a simple version taking no arguments. This script has to be edited for functionality. The run_cucumber_tests.bat script is more robust taking several options.

### Encryption Utility
* Included in the bin directory is a script (run_encryption_gui)to run an encryption utility. This utility is provided to encrypt certain sensitive property values that are stored in the configuration files. 