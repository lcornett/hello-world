## Release 1.1.0 Notes
The functionality in Release 1.1.0 of the Authentify Cucumber Testing Framework consists of the new features that resolve bugs that were submitted for the Mobile Status feature.

- A feature to access the database and validate the database against elements of the response. This feature was implemented to resolve bug AM-1876.

- A feature to access the SessionProcessor logs and validate elements of the response against elements of the Payfone response. This feature was implemented to resolve bug AM-1942.

- A feature to access the SessionProcessor logs and validate the elements of the request to Payfone against elements of the Authentify request. This feature was implemented to resolve bug AM-1956.

The new functionality listed above implemented 4 new Step definitions. A listing of step definitions can be found in the Java Docs stepdefs package.
The step definitions are listed for each StepDef class. 

### Bug Fixes

- [AM-1876 - Payfone:MobileStatus: Verification of database is missing during automation](https://jira.ews.int/browse/AM-1876)

- [AM-1942 - Payfone:MobileStatus: Verification of actual result values is missing by accessing logs](https://jira.ews.int/browse/AM-1942)

- [AM-1956 - Payfone:MobileStatus: TC#3 - verification that phoneNumber is used in request to payfone is missing](https://jira.ews.int/browse/AM-1956)

- [AM-1957 - Payfone:MobileStatus: Polling doesn't look right](https://jira.ews.int/browse/AM-1957) 

- [AM-1958 - Payfone:MobileStatus: TC#6 is missing verification steps as executed in TC#2](https://jira.ews.int/browse/AM-1958)

- [AM-1994 - Payfone:MobileStatus: Not able to verify ExternalGuid vs legacyDeviceId in database](https://jira.ews.int/browse/AM-1994)

- [AM-2074 - Payfone:MobileStatus: optomize accessing logs for same scenario when using same log for each step](https://jira.ews.int/browse/AM-2074)

- [AM-2084 - Payfone:MobileStatus: provide a way to map value in log to the value in a response](https://jira.ews.int/browse/AM-20840)

- [AM-2145 - Payfone:MobileStatus: Database query cannot return resourceId = 0 or multiple rows](https://jira.ews.int/browse/AM-2145)



### Stories

- [AM-2016 - OOBA: SMS Blockers: The Test cases marked as Blockers for SMS were implemented.](https://jira.ews.int/browse/AM-2016)

- [AM-2034 - Adapt framework functionality for XML as well as JSON](https://jira.ews.int/browse/AM-2034)

- [AM-2047 - Update automation framework for XML requests and responses](https://jira.ews.int/browse/AM-2047)

- [AM-2194 - Create a GUI application for editing the expected responses file.](https://jira.ews.int/browse/AM-2194)

- [AM-2197 - Create method to validate the entire expected response](https://jira.ews.int/browse/AM-2197)


