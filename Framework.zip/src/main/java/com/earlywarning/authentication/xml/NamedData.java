/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.xml;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import lombok.Builder;
import lombok.Data;

/**
 * <p>A POJO that represents the namedData element of the Authentify XML
 * request message.</p>
 * <p>This class utilizes the lombok Data and the lombok Builder annotations.
 * The Data annotation implements the getters and setters for the private property:</p><ul>
 * 	<li>messageText</li>
 * 	<li>pinNumber</li>
 * 	<li>pin</li>
 * 	<li>amount</li>
 * 	<li>exponent</li>
 * 	<li>currency</li>
 * 	<li>confirmNumberOne</li>
 * 	<li>confirmNumberTwo</li>
 * 	<li>confirmNumberThree</li>
 * 	<li>transferNumber</li>
 * 	<li>callDelay</li>
 * 	<li>num_of_retries_upon_failure</li>
 * 	<li>forwarding_number</li>
 * 	<li>event_type</li>
 * 	<li>to_account_digits</li>
 * 	<li>to_account_query_format</li>
 * 	<li>password_name</li>
 * 	<li>returnLegacyDeviceId</li>
 * </ul>. 
 * The Builder annotation provides an implementation of an
 * all argument constructor and an implementation of the &lt;class name&gt;Builder class.
 * For additional information about these annotations, please see
 * <a href="{@docRoot}/com/earlywarning/authentication/xml/package-summary.html#tags">package-info</a> page.
 *
 * @author cornettl
 *
 */
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class NamedData {
	@JacksonXmlProperty(localName="dat:dataItem name=\"messageText\"")	
	private String messageText;

    @JacksonXmlProperty(localName="dat:dataItem name=\"pinNumber\"")
    private String pinNumber;

    @JacksonXmlProperty(localName="dat:dataItem name=\"pin\"")
    private String pin;

    @JacksonXmlProperty(localName="dat:dataItem name=\"amount\"")
    private String amount;

    @JacksonXmlProperty(localName="dat:dataItem name=\"exponent\"")
    private String exponent;

    @JacksonXmlProperty(localName="dat:dataItem name=\"currency\"")
    private String currency;

    @JacksonXmlProperty(localName="dat:dataItem name=\"confirmNumberOne\"")
    private String confirmNumberOne;

    @JacksonXmlProperty(localName="dat:dataItem name=\"confirmNumberTwo\"")
    private String confirmNumberTwo;

    @JacksonXmlProperty(localName="dat:dataItem name=\"confirmNumberThree\"")
    private String confirmNumberThree;

    @JacksonXmlProperty(localName="dat:dataItem name=\"transferNumber\"")
    private String transferNumber;

    @JacksonXmlProperty(localName="dat:dataItem name=\"callDelay\"")
    private String callDelay;

    @JacksonXmlProperty(localName="dat:dataItem name=\"num_of_retries_upon_failure\"")
    private String num_of_retries_upon_failure;

    @JacksonXmlProperty(localName="dat:dataItem name=\"forwarding_number\"")
    private String forwarding_number;

    @JacksonXmlProperty(localName="dat:dataItem name=\"event_type\"")
    private String event_type;

    @JacksonXmlProperty(localName="dat:dataItem name=\"to_account_digits\"")
    private String to_account_digits;

    @JacksonXmlProperty(localName="dat:dataItem name=\"to_account_query_format\"")
    private String to_account_query_format;

    @JacksonXmlProperty(localName="dat:dataItem name=\"password_name\"")
    private String password_name;
	
	@JacksonXmlProperty(localName="dataItem name=\"returnlegacydeviceid\"")
	private String returnLegacyDeviceId;

}

