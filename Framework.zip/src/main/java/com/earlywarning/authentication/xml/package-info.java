/**
 * 
 */
/**
 * <p>Provides the classes necessary to create an Authentify xml request and an AuthentXML response messages. 
 * When creating theses classes I did not have access to a message layout document
 * so the classes in this package may be incomplete. 
 * The root element of the Authentify xml request message is AuthentXML. This is also the 
 * class name that represents that element.</p>
 * <p>In addition to the classes that are used to represent the request, classes are also provided
 * to create the request and validate the response. The XmlRequestCreator uses a Map&lt;String, String&gt;
 * as a parameter to create the request with the first string used for the element name
 * and the second string contains the element value. The XmlRequestCreator provides the context 
 * for the element. The XmlResponsevalidator also uses a Map&lt;String, String&gt; as a parameter to 
 * validate the response.</p>
 * <p>The tables below illustrate the implemented request message layout.</p>
 * <h2>AuthentXML</h2>
 * <p>This is the root element! The namespace 'http://xml.authentify.net/MessageSchema.xml' and the version is declared in the element.</p>
 * 
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>XML Element/Node</th><th>Type</th><th align="center">Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>header</td><td>node</td><td align="center">Y</td><td></td><td>The header contains many of the required values for the message.</td></tr>
 * 	<tr><td>body</td><td>node</td><td align="center">Y</td><td></td><td>The bodu of the message.</td></tr>
 * </table>
 * 
 * <h2>Header</h2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>XML Element/Node</th><th>Type</th><th align="center">Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>tsoid</td><td>string</td><td align="center">Y</td><td>Authentify_Test</td><td>This has become the clientId in the JSON message.</td></tr>
 * 	<tr><td>licenseKey</td><td>string</td><td align="center">Y</td><td></td><td>The license key is issued by Early Warning to the users of the service.A different license key is used for each Authentify environment.</td></tr>
 * 	<tr><td>application</td><td>string</td><td align="center">Y</td><td>mobileProdLookup</td><td></td></tr>
 * 	<tr><td>account</td><td>string</td><td align="center">Y</td><td>QATest</td><td>The is the same field as the clientAcctId in the JSON message</td></tr>
 * 	<tr><td>asid</td><td>string</td><td align="center">Y</td><td>Authentify_QA_Test</td><td>This is the same element as the clientContext element in the JSON message.</td></tr>
 * </table>
 * 
 * <h2>Body</h2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>XML Element/Node</th><th>Type</th><th align="center">Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>request</td><td>node</td><td align="center">Y</td><td></td><td></td></tr>
 * </table>
 * 
 * <h2>Request</h2>
 * <p>This node is implemented by the XmlRequest class. 
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>XML Element/Node</th><th>Type</th><th align="center">Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>data</td><td>node</td><td align="center">Y</td><td></td><td>This element declares the dat namespace.</td></tr>
 * </table>
 * 
 * <h2>Data</h2>
 * <p>This node is implemented by the RequestData class.</p>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>XML Element/Node</th><th>Type</th><th align="center">Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>phoneNumber</td><td>String</td><td align="center">Y</td><td></td><td></td></tr>
 * 	<tr><td>name</td><td>Node</td><td align="center">N</td><td></td><td></td></tr>
 * 	<tr><td>address</td><td>Node</td><td align="center">N</td><td></td><td></td></tr>
 * 	<tr><td>namedData</td><td>Node</td><td align="center">N</td><td></td><td></td></tr>
 * </table>
 * 
 * <h2>Name</h2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>XML Element/Node</th><th>Type</th><th align="center">Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>firstName</td><td>String</td><td align="center">Y</td><td></td><td></td></tr>
 * 	<tr><td>lastName</td><td>String</td><td  align="center">Y</td><td></td><td></td></tr>
 * </table>
 * 
 * <h2>Address</h2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>XML Element/Node</th><th>Type</th><th align="center">Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>streetAddress</td><td>String</td><td align="center">Y</td><td></td><td></td></tr>
 * 	<tr><td>postalCode</td><td>String</td><td align="center">Y</td><td></td><td></td></tr>
 * </table>
 * 
 * <h2>NamedData</h2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>XML Element/Node</th><th>Type</th><th align="center">Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>messageText</td><td>String</td><td align="center">Y</td><td></td><td></td></tr>
 * </table> 
 * 
 * <h2 id="tags">Annotations</h2>
 * <p>The following annotations are used in this package.</p>
 * <h3 id="data">The Data Annotation</h3>
 * <p>The lombok Data annotation provides the implementation for the setters and getters for the class
 * private properties as well as the 'toString()', 'hashCode()' and 'equals()' methods without having to 
 * code these methods. Because the methods are provided by the annotation and not specifically coded, the 
 * Java Doc for the class does not include these methods.</p>
 * <p>Aditional information about the annotation may be found at the <a href="https://projectlombok.org/features/Data" target="blank">Project Lombok </a> website.</p>
 * 
 * <h3 id="builder">The Builder Annotation</h3>
 * <p>The lombok Builder annotation implements the builder pattern on the classes that use it. The effect of this implementation is:</p><ul>
 * 	<li><b>Implements an all argument constructor</b> - All non final properties of the base class are treated as parameters for the constructor.</li>
 * 	<li><b>Implements a builder() method</b> - The base class's builder() method returns a builder class using the naming convention &lt;class_name&gt;Builder</li>
 * 	<li><b>Implements a Builder Class</b> - The &lt;class_name&gt;Builder class has the following attributes:<ol>
 * 		<li>Has the same private properties as the base class</li>
 * 		<li>A setter method is implemented for each of the private properties and has the same name as the property.</li>
 * 		<li>Implements a toString() method.</li>
 * 		<li>Implements a build() method. The build method returns an instance of the base class with the properties instantiated
 * 			that were set in the builder class.</li></ol></ul>
 * <p>The Builder class and annotation implemented methods do not have any Java Docs associated with them. Additional information 
 * about the Builder annotation may be found at the <a href="https://projectlombok.org/features/Builder" target="blank">Project Lombok</a> website.</p>
 * 
 * 
	
 * @author cornettl
 *
 */
package com.earlywarning.authentication.xml;