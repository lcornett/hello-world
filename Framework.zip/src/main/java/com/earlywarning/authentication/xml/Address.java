/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.xml;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Builder;
import lombok.Data;

/**
 * <p>A POJO that represents the address node of the Authentify XML request message.
 * This class utilizes the lombok Data and Builder annotations. The Data annotation
 * implements the getters and setters for the class's private properties:<ul>
 * 	<li>streetAddress</li>
 * 	<li>postalCode</li>
 * 	<li>city</li>
 * 	<li>region</li>
 * 	<li>country</li>
 * 	</ul>
 * <p>The Builder annotation implements the Builder pattern.</p>
 * <p>Additional information about these annotations may be found on the
 * <a href="{@docRoot}/com/earlywarning/authentication/xml/package-summary.html#tags">package-info</a> page.</p>
 * 	
 * @author cornettl
 *
 */
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Address {
	private String streetAddress;
	private String postalCode;
    private String city;
    private String region;
    private String country;
	
}

