/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.xml;

import lombok.Data;

/**
 * A POJO that represents the data element of the AuthentXML response message. This class
 * uses the lombok Data annotation which provides the implementation for the getter and 
 * setter methods for the private properties.
 * @author cornettl
 *
 */
@Data
public class ResponseData {
	private String phoneNumber;	
	private String ewDeviceId;
	private XmlResponseDataLookup dataLookup;

}
