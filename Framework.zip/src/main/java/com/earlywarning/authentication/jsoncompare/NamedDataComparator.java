/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.jsoncompare;

import com.earlywarning.authentication.common.NamedData;

import lombok.extern.log4j.Log4j2;

/**
 * A class that compares the values of the properties of two instances of the NamedData class.
 * @author cornettl
 *
 */
@Log4j2
class NamedDataComparator extends StringComparator {

	/**
	 * The method that compares the values of each of the properties of two instances of
	 * the NamedData class.
	 * @param actual The instance being compared.
	 * @param expected The instance being compared to.
	 * @return true if the values match, false otherwise.
	 */
	boolean compareNamedData(NamedData actual, NamedData expected) {
		final String comparator = "data.namedData.";
		String actualValue = "";
		String expectedValue = "";
		String[] elements = {"dataItem", "returnLegacyDeviceId"};
		
		try {
			
			if ((null == actual) && (null == expected)) {
				return status;
			}
			
			for (String element : elements) {
				switch (element) {
					case "dataItem":
						// I'm not sure if this is obsolete or not. Need to implement or delete when I find out.
						break;
					case "returnLegacyDeviceId":
						actualValue = actual.getReturnlegacydeviceid();
						expectedValue = expected.getReturnlegacydeviceid();
						updateStatus(compareString(comparator + element, actualValue, expectedValue));
				}
			}
			
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		return status;
	}
}
