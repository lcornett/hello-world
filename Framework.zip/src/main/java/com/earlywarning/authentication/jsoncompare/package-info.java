/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
/**
 * A package containing several classes that compare the elements of a JSON message with the corresponding elements
 * of another JSON message. Many of the classes in this package are package-private.
 * @author cornettl
 *
 */
package com.earlywarning.authentication.jsoncompare;