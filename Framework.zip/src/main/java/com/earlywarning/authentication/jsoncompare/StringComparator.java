/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.jsoncompare;

import lombok.extern.log4j.Log4j2;

/**
 * An abstract class that compares two strings and logs the result of the comparison using the 
 * field name of the values being compared.
 * @author cornettl
 *
 */
@Log4j2
public abstract class StringComparator {
	protected boolean status = true;
	
	/**
	 * A method to compare the values of two strings. This method handles the logging for the element
	 * being compared.
	 * @param key The element being compared.
	 * @param actual The value of the element being compared.
	 * @param expected	The expected value of the element.
	 * @return True if the the strings are equal, false otherwise
	 */
	protected boolean compareString(String key, String actual, String expected) {
		String msg = "";
		boolean result;
		
		if (null == actual && null == expected) {
			result = true;
		} else if (actual.equals(expected)) {
			msg = "The actual value and the expected value of the element " + key + " are the same.";
			log.info(msg);
			result = true;
		} else {
			msg = "The element " + key + "'s actual and expected are not the same. Actual = " 
					+ actual + ", Expected = " + expected + ".";
			log.info(msg);
			result = false;
		}
		return result;
	}
	
	/**
	 * A utility method to update the status with each comparison
	 * @param value The result of the last comparison.
	 */
	protected void updateStatus(boolean value) {
		if (!value) {
			status = value;
		}
	}


}
