/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.jsoncompare;

import com.earlywarning.authentication.common.CardInfo;

import lombok.extern.log4j.Log4j2;

/**
 * A class that compares the values of the properties of two instances of the CardInfo class.
 * @author cornettl
 *
 */
@Log4j2
class CardInfoComparator extends StringComparator {

	/**
	 * The method that compares the value of each of the properties of two instances of the
	 * CardInfo class.
	 * @param actual The instance to compare.
	 * @param expected The instance to compare to.
	 * @return true if the property values match, otherwise false.
	 */
	boolean compareCardInfo(CardInfo actual, CardInfo expected) {
		final String comparator = "data.cardInfo.";
		String actualValue = "";
		String expectedValue = "";
		String[] elements = {"cvv"};
		
		try {
			
			if ((null == actual) && (null == expected)) {
				return status;
			}
			
			for (String element : elements) {
				switch (element) {
					case "cvv":
						actualValue = actual.getCvv();
						expectedValue = expected.getCvv();
						updateStatus(compareString(comparator + element, actualValue, expectedValue));
				}
			}
			
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		return status;
	}
}
