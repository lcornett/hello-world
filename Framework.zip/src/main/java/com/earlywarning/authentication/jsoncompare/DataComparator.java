/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.jsoncompare;

import com.earlywarning.authentication.response.json.Data;
import com.earlywarning.authentication.response.json.DataLookup;

import lombok.extern.log4j.Log4j2;

/**
 * A class that compares two instances of the Data class.
 * @author cornettl
 *
 */
@Log4j2
class DataComparator extends StringComparator {

	/**
	 * Compares each property of the actual data element with the same property of the expected data element.
	 * @param actual The data element to compare.
	 * @param expected The data element to compare to.
	 */
	boolean compareData(Data actual, Data expected) {
		final String comparator = "data.";
		String actualValue = "";
		String expectedValue = "";
		String[] keys = {"phoneNumber", "ewDeviceId", "legacyDeviceId", "consentProvided", "dataLookup",
				"namedData", "user", "cardInfo"};
		
		try {
			
			if ((null == actual) && (null == expected)) {
				return status;
			}
			
			for (String key : keys) {
				switch (key) {
					case "phoneNumber":
						actualValue = actual.getPhoneNumber();
						expectedValue = expected.getPhoneNumber();
						updateStatus(compareString(comparator + key, actualValue, expectedValue));
						break;
					case "consentProvided":
						actualValue = actual.getConsentProvided();
						expectedValue = expected.getConsentProvided();
						updateStatus(compareString(comparator + key, actualValue, expectedValue));
						break;
					case "ewDeviceId":
						actualValue = actual.getEwDeviceId();
						expectedValue = expected.getEwDeviceId();
						updateStatus(compareString(comparator + key, actualValue, expectedValue));
						break;
					case "legacyDeviceId":
						actualValue = actual.getLegacyDeviceId();
						expectedValue = expected.getLegacyDeviceId();
						updateStatus(compareString(comparator + key, actualValue, expectedValue));
						break;
					case "dataLookup":
						DataLookupComparator dlc = new DataLookupComparator();
						DataLookup actualDataLookup = actual.getDataLookup();
						DataLookup expectedDataLookup = expected.getDataLookup();
						updateStatus(dlc.compareDataLookup(actualDataLookup, expectedDataLookup));
						break;
//					case "namedData":
//						NamedDataComparator ndc = new NamedDataComparator();
//						NamedData actualNamedData = actual.getNamedData();
//						NamedData expectedNamedData = expected.getNamedData();
//						updateStatus(ndc.compareNamedData(actualNamedData, expectedNamedData));
//						break;
//					case "user":
//						UserComparator uc = new UserComparator();
//						DataUser actualUser = actual.getUser();
//						DataUser expectedUser = expected.getUser();
//						updateStatus(uc.compareUser(actualUser, expectedUser));						
//						break;
//					case "cardInfo":
//						CardInfoComparator cic = new CardInfoComparator();
//						CardInfo actualCardInfo = actual.getCardInfo();
//						CardInfo expectedCardINfo = expected.getCardInfo();
//						updateStatus(cic.compareCardInfo(actualCardInfo, expectedCardINfo));						
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		return status;
	}

}
