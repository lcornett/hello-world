/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.applogs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

import com.earlywarning.authentication.startup.Env;
import com.earlywarning.authentication.utils.DateUtils;

import lombok.extern.log4j.Log4j2;

/**
 * A class that accesses the SessionProcessor logs and retrieves the Payfone
 * response to a query based on the teid (this is the EWS field ewSID)
 * @author cornettl
 *
 */
@Log4j2
public class LogParser {
	private static int counter = 0;
	private static int maxIterations = Integer.parseInt(Env.getProperty("maxTries").trim());
	
	/**
	 * The method that parses the log and retrieves the Payfone response. The logPath
	 * parameter is a partial parameter and requires additional processing to access the log.
	 * @param logPath The partial UNC path to the SessionProcessor log.
	 * @param teid The transaction id to look for in the log.
	 * @return A string, in JSON format, that represents the Payfone response.
	 */
	public String parseLog(String logPath, String teid) {
		File file = new File(getCurrentLog(logPath));
		String response = "{";
		BufferedReader br = null;
		long lines = 0;
		
		try {
			String regex = "\\s*\"[Rr]equestId\"\\s:\\s*\"" + teid + "\",";
			String regex2 = "\\s*\"[Ss]tatus\"\\s:\\s*\\d+,"; 
			String regex3 = " \\}";
			
			br = new BufferedReader(new FileReader(file));
			String line;
			while ((line = br.readLine()) != null) {
				lines++;
				if (line.matches(regex)) {
					response += line.trim();
					line = br.readLine();
					if (line.matches(regex2)) {
						response += line.trim();
						line = br.readLine();
						do {
							response += line.trim();
						} while (!(line = br.readLine()).matches(regex3));
							
					} else {
						response = "{";
					}
				}
			}
			response +="}";
			
			if (response.equals("{}")) {
				response = alternateResponseFormat(logPath, teid);
			}
            if (response.equals("")){
                response = alternateResponseParse(logPath, teid);
            }
            log.debug("Processed " + lines + " lines.");
			log.info("The composed response is " + response);
		} catch (FileNotFoundException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (IOException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		}

		if (response.equals("{}") && (counter < maxIterations)) {
			try {
				setCounter();
				Thread.sleep(Integer.parseInt(Env.getProperty("interval")));
				response = parseLog(logPath, teid);
			} catch (InterruptedException e) {
				log.error(e.getClass() + " " + e.getMessage());
				log.debug(e.getMessage(), e);
			}
		} else if (counter >= maxIterations) {
			return null;
		} else {
			counter = 0;
		}
		
		
		return response;		
	}
	
	/**
	 * A method that parses the SessionProcessor log and retrieves the Request portion of the Payfone
	 * transaction. 
	 * @param logPath The partial UNC path to the SessionProcessor log.
	 * @param teid The transaction id to look for in the log.
	 * @return The request part of the transaction.
	 */
	public String parseLogRequest(String logPath, String teid) {
		File file = new File(getCurrentLog(logPath));
		String response = "{";
		BufferedReader br = null;
		
		try {
			String regex = "\\s*\"RequestId\"\\s:\\s*\"" + teid + "\",";
			String regex2 = "\\s*\"ApiClientId\"\\s:\\s*\"Auth_[A-Za-z0-9]+\","; 
			String regex3 = " \\s*\\}";
			
			br = new BufferedReader(new FileReader(file));
			String line;
			while ((line = br.readLine()) != null) {
				if (line.matches(regex)) {
					response += line.trim();
					line = br.readLine();
					if (line.matches(regex2)) {
						response += line.trim();
						line = br.readLine();
						do {
							response += line.trim();
						} while (!(line = br.readLine()).matches(regex3));
							
					} else {
						response = "{";
					}
					response += "}";
					
					if (response.equals("{}") && (counter < maxIterations)) {
						try {
							setCounter();
							Thread.sleep(Integer.parseInt(Env.getProperty("interval")));
							response = parseLogRequest(logPath, teid);
						} catch (InterruptedException e) {
							log.error(e.getClass() + " " + e.getMessage());
							log.debug(e.getMessage(), e);
						}
					} else if (counter >= maxIterations) {
						return null;
					} else {
						counter = 0;
					}

					return response;
				}
			}
		} catch (FileNotFoundException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (IOException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				log.error(e.getMessage());
				log.debug(e.getMessage(), e);
			}
		}
		return response;		
	}
	

	/**
	 * A method that takes a partial log path and completes it. It does this by using
	 * the base part of the directory that contains the logs (e.g., logs_since_<todays_date>), 
	 * appends the date to the partial directory name and searches for directories that match
	 * the name. If more that one directory is found, the most recent directory is found and used
	 * as the directory to look for the file with the highest index number. After finding the file, 
	 * the absolute path of the file is returned.
	 * @param logPath The partial log path. (Obtained from the LoggerMapper)
	 * @return The absolute path of the log.
	 */
	String getCurrentLog(String logPath) {
		String directory = "logs_since_";
		String formattedDate = null;
		ArrayList<File> matches = new ArrayList<File>();
		
		File file = new File(logPath);
		
		File[] directories = file.listFiles();
		
		if (!Arrays.asList(directories).contains(directory)) {
			// get todays directory from the list of directories
			formattedDate = DateUtils.getFormattedToday("yyyy_MM_dd");
			directory += formattedDate;
		}
		for (File dir : directories) {
			String fileName = dir.getName();
			if (fileName.contains(directory)) {
				matches.add(dir);
			}
		}
		
		if (matches.size() > 1) {
			logPath = getRecentLogPath(matches);
		} else {
			logPath = matches.get(0).getAbsolutePath();
		}
		
		File[] files = null;;
		try {
			file = new File(logPath);
			files = file.listFiles(); 
			if (files.length > 1) {
				Arrays.sort(files, new Comparator<File>() {
					public int compare(File f1, File f2) {
						return Long.compare(Long.parseLong(f1.getName().substring(5, f1.getName().indexOf("."))),
								Long.parseLong(f2.getName().substring(5, f2.getName().indexOf("."))));
					}
				});
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}

  		log.info("Returning log: " + files[files.length - 1].getAbsolutePath());
		return files[files.length - 1].getAbsolutePath();
	}
	
	/**
	 * A method that converts the ArrayList of directory names to an ArrayList
	 * of directories and then sorts them by the lastModified date and returns the latest.
	 * @param matches A list of directories to process.
	 * @return The name of the last modified directory.
	 */
	private String getRecentLogPath(ArrayList<File> matches) {
		ArrayList<File> files = new ArrayList<File>();
		
		Comparator<File> comparator = Comparator.comparing(File::lastModified);
		Collections.sort(matches, comparator);
		
		return matches.get(matches.size() -1).getAbsolutePath();
	}
	

	/**
	 * A method that increments the counter for each iteration of either parseLog or
	 * parseLogRequest.
	 */
	private void setCounter() {
		
		if (counter < maxIterations) {
			counter++;
		
		}
	}
	
	/**
	 * An method to get the Payfone response from the SessionProcessor log when
	 * the logsensitive setting is off. This method is only called by the parseLog
	 * method and only when the parseLog method results in the response being "{}".
	 * @param logPath The logPath that was passed to the parseLog method.
	 * @param teid The transaction id to find. From the parseLog method.
	 * @return The Payfone response from the SessionProcessor log.
	 */
	private String alternateResponseFormat(String logPath, String teid) {
		File file = new File(getCurrentLog(logPath));
		String response = "";
		BufferedReader br = null;
		long lines = 0;
		
		try {
			String regex = "\"RequestId\":\"" + teid + "\",\"Status\"";

			
			br = new BufferedReader(new FileReader(file));
			String line;
			while ((line = br.readLine()) != null) {
				lines++;
				if (line.contains(regex)) {
					response += line.trim();
					line = br.readLine();
				}
			}		
		} catch (FileNotFoundException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (IOException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return response;
	}

    /**
     * An method to get the App CRUD service response from the SessionProcessor.
     * This method is only called by the parseLog
     * method and only when the parseLog method results in the response being "".
     * @param logPath The logPath that was passed to the parseLog method.
     * @param teid The transaction id to find. From the parseLog method.
     * @return The App CRUD service response from the SessionProcessor log.
     */
    private String alternateResponseParse(String logPath, String teid){
        File file = new File(getCurrentLog(logPath));
        String response = "{";
        BufferedReader br = null;
        long lines = 0;
        boolean check =false;

        try {
            String regex = "X-Auth-SessionId: " + teid;
            String regex2 = "Connection: close";
            String regex3 = "{";
            String regex4 = " \\}";

            br = new BufferedReader(new FileReader(file));
            String line;

            outer:
            while ((line = br.readLine()) != null) {
                lines++;
                if(check){
                    break;
                }
                if (line.matches(regex)) {
                    while((line = br.readLine()) != null){
                        if (line.matches(regex2)) {
                            while((line = br.readLine()) != null){
                                if(line.trim().equals(regex3)){
                                    line = br.readLine();
                                    do {
                                        response += line.trim();
                                    } while (!(line = br.readLine()).matches(regex4));
                                    check =true;
                                    break outer;
                                }
                            }
                        }
                    }
                }
            }
            response +="}";
            log.debug("Processed " + lines + " lines.");
            log.info("The composed response is " + response);
        } catch (FileNotFoundException e) {
            log.error(e.getMessage());
            log.debug(e.getMessage(), e);
        } catch (IOException e) {
            log.error(e.getMessage());
            log.debug(e.getMessage(), e);
        } catch (Exception e) {
            log.error(e.getMessage());
            log.debug(e.getMessage(), e);
        }
        return response;
    }

}
