/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.applogs;

import com.earlywarning.authentication.common.ApiDriver;

import io.restassured.config.JsonConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.internal.ResponseParserRegistrar;
import io.restassured.internal.RestAssuredResponseImpl;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;


/**
 * A class to retrieve an element's value from a retrieved JSON formatted string.
 * @author cornettl
 *
 */
@Log4j2
public class ValueRetriever {
	private Response response;
	
	/**
	 * The constructor for the class. This method creates a Rest Assured response
	 * from the source string and stores it in a instance variable.
	 * @param source The JSON formatted string.
	 */
	public ValueRetriever(String source) {
		// create a response from the source so that I can use the ApiDriver to get the values
		// remove the linefeeds and carriage returns from the source
		source = source.replace("\n", "").replaceAll("\r", "");
		response = createResponse(source);
	}
	
	/**
	 * A method to get the value from an element of the JSON formatted string.
	 * @param valuePath The JSON Path of the value to retrieve.
	 * @return The value of the element.
	 */
	public String getValue(String valuePath) {
		return ApiDriver.retrieveJsonValueString(response, valuePath);
	}
	
	/**
	 * A method that actually creates the Rest Assured Response from the JSON 
	 * formatted string.
	 * @param source A JSON formatted string.
	 * @return The Rest Assured Response that represents the string.
	 */
	private Response createResponse(String source) {
		
		try {
			RestAssuredResponseImpl impl = new RestAssuredResponseImpl();
			response = null;
			impl.setContent(source);
			impl.setContentType("application/json");
			ResponseParserRegistrar rpr = new ResponseParserRegistrar();
			rpr.registerParser("application/json", Parser.JSON);
			impl.setRpr(rpr);
			impl.setConfig(new RestAssuredConfig().jsonConfig(new JsonConfig()));
			response = impl;
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		return response;			
	}
}
