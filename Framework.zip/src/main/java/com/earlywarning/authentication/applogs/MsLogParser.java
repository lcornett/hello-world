/**
 * Copyright (c) 2018 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.applogs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import com.earlywarning.authentication.startup.Env;
import com.earlywarning.authentication.utils.DateUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

/**
 * A class that finds the MessageServer logs when given the servers to look 
 * for them on, and parses the log for various messages.
 * @author cornettl
 *
 */
@Log4j2
public class MsLogParser {
	private static String clientContext;
	private static File currentLog;
	private static BufferedReader currentReader;

	/**
	 * A method that looks for the post message in the message server logs
	 * @param servers The servers associated with the replyTo url
	 * @return The post message
	 */
	public String parseLog(String[] servers) {
		long threshold = Long.parseLong(Env.getProperty("threshold"))*1000;
		File log1 = new File(getFullPath(servers[0]));
		File log2 = new File(getFullPath(servers[1]));
		File[] files = {log1, log2};
		String message = "{";
		BufferedReader reader = null;
		
		try {
			String regex = "timestampISO8601";
			String regex2 = "\\s*\"event\"\\s:\\s*\"recSMS\","; 
			String regex3 = " \\}";

			outerloop:
			for (int j = 0; j < files.length; j++) {
				log.info("Processing log: " + files[j]);
				reader = new BufferedReader(new FileReader(files[j]));
				String line;
				while ((line = reader.readLine()) != null) {
					if (line.contains(regex)) {
						long diff = DateUtils.getDiff(
								line.substring(line.indexOf(":") + 1, line.length() - 1).trim().replace("\"", ""));
						if (diff > threshold) {
							continue;
						}
						message += line.trim();
						for (int i = 0; i < 3; i++) {
							line = reader.readLine();
							message += line.trim();
						}
						line = reader.readLine();
						if (line.matches(regex2)) {
							message += line.trim();
							line = reader.readLine();
							do {
								message += line.trim();
							} while (!(line = reader.readLine()).matches(regex3));
							currentLog = files[j];
							currentReader = reader;
							break outerloop;
						} else {
							message = "{";
						}
					}					
				} 
			}
			message +="}";
		} catch (Exception e) {
			log.error(e.getMessage());
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		clientContext = new ValueRetriever(message).getValue("clientContext");
		log.info("The retrieved message is:\n" + makePretty(message));
		return message;
	}
	
	/**
	 * A method that parses the Message Server log to get the response 
	 * to the POST message. When the response is found, the status is
	 * checked to ensure that it equals the expected status.
	 * @param expectedStatus The expected status for the post message.
	 * @return true if the actual status equals the expected status.
	 */
	public boolean parseResponse(int expectedStatus) {		
		boolean result = false;
		String line = null;
		String message = "{";
		String regex = " }";
		String regex1 = "ewSID";
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader(currentLog));
			
			while ((line = reader.readLine()) != null) {
				if (line.contains(clientContext)) {
					message += line.trim(); 
					if ((line = reader.readLine()).contains(regex1)) {
						message += line.trim();
						message += reader.readLine().trim();
						message += regex;
					} else {
						message = "{";
					}
				}
			}
			String status = new ValueRetriever(message).getValue("status");
			log.info("The response to the post is:\n" + makePretty(message));
			log.info("The response status is " + status + ".");
			result = Integer.parseInt(status) == expectedStatus;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
	
	/**
	 * A method that gets the full path to the log.
	 * @param path The path to the server
	 * @return The full path to the log
	 */
	private String getFullPath(String path) {
		String dir = path + "\\logs\\MessageServer\\";
		
		return new LogParser().getCurrentLog(dir);
	}
	
	/**
	 * A method that takes an unformatted JSON string and formats it.
	 * @param message The JSON string to format.
	 * @return The formatted string.
	 */
	private String makePretty(String message) {
		String pretty = null;
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			Object json = mapper.readValue(message, Object.class);
			pretty = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(json);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return pretty;
	}
}
