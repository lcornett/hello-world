/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.ccv;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/**
 * A POJO that represents the MobileIdentityMatchAttribute element of the 
 * Authentify Call Center Verification request message.
 * This class utilizes the lombok Data annotation which provides the 
 * getters and setters for the private properties:<ul>
 * 	<li>matchEmailAttributeKey</li>
 * 	<li>matchAddressAttributeKey</li>
 * 	<li>matchNameAttributeKey</li></ul>
 * For additional information about this annotation, please see the
 * <a href="{@docRoot}/com/earlywarning/authentication/ccv/package-summary.html#tags">
 * package-info</a> page.
 * 
 * @author cornettl
 *
 */
@JsonInclude(Include.NON_NULL)
@Data
public class MobileIdentityMatchAttribute {
	MatchEmailAttributeKey matchEmailAttributeKey;
	MatchAddressAttributeKey matchAddressAttributeKey;
	MatchNameAttributeKey matchNameAttributeKey;
}
