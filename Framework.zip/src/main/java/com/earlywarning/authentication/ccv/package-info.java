/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
/**
 * <p>This package contains the classes that are used to test the Call Center
 * Verification (CCV) service. The majority of the classes represent the nodes
 * of the JSON request message. The below tables illustrate the JSON request 
 * message layout.</p>
 * 
 * <h2>CCVRequest</h2>
 * This is the base request. There is no element or node named CCVRequest.
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>JSON Element/Node</th><th>Type</th><th>Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 *	<tr><td>requestId</td><td>String</td><td align="center">Y</td><td></td><td></td></tr>
 *	<tr><td>apiClientId</td><td>String</td><td align="center">Y</td><td></td><td></td></tr>
 *	<tr><td>mobileNumber</td><td>String</td><td align="center">Y</td><td></td><td></td></tr>
 *	<tr><td>MobileStatusCheck</td><td>boolean</td><td align="center">N</td><td></td><td>If omitted, assumes false.</td></tr>
 *	<tr><td>MobileCallVerificationCheck</td><td>boolean</td><td align="center">Y</td><td></td><td>If omitted, assumes false.</td></tr>
 *	<tr><td>mobileCallVerificationDID</td><td>String</td><td align="center">C</td><td></td><td>Required if the MobileCallVerificationCheck is true.</td></tr>
 *	<tr><td>callArrivalTimestamp</td><td>String</td><td align="center">N</td><td></td><td>The call date/time for UTC zone in ISO 8601 format</td></tr>
 *	<tr><td>MobileIdentityCheck</td><td>boolean</td><td align="center">N</td><td></td><td>If omitted, assumes false.</td></tr>
 *	<tr><td>mobileIdentityMatchAttribute</td><td>Node</td><td align="center">C</td><td></td><td></td></tr>
 *	<tr><td>consentStatus</td><td>String</td><td align="center">Y</td><td></td><td></td></tr>
 *	<tr><td>consentCollectedTimestamp</td><td>String</td><td align="center">Y</td><td></td><td>A date in the format yyyy-mm-dd.</td></tr>
 *	<tr><td>consentTransactionId</td><td>String</td><td align="center">Y</td><td></td><td></td></tr>
 *	<tr><td>consentDescription</td><td>String</td><td align="center">Y</td><td></td><td></td></tr>
 *	<tr><td>subClientId</td><td>String</td><td align="center">N</td><td></td><td></td></tr>
 *	<tr><td>payfoneAlias</td><td>String</td><td align="center">N</td><td></td><td></td></tr>
 * </table>
 * 
 * <h2>MobileIdentityMatchAttribute</h2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>JSON Element/Node</th><th>Type</th><th>Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>matchEmailAttributeKey</td><td>Node</td><td align="center">N</td><td></td><td></td></tr>
 * 	<tr><td>matchAddressAttributeKey</td><td>Node</td><td align="center">N</td><td></td><td></td></tr>
 * 	<tr><td>matchNameAttributeKey</td><td>Node</td><td align="center">N</td><td></td><td></td></tr>
 * </table>
 * 
 * <h2>MatchEmailAttributeKey</h2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>JSON Element/Node</th><th>Type</th><th>Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>emailAddress</td><td>String</td><td align="center">Y</td><td></td><td></td></tr>
 * </table>
 * 
 * <h2>MatchAddressAttributeKey</h2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>JSON Element/Node</th><th>Type</th><th>Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>streetAddress</td><td>String</td><td align="center">N</td><td></td><td>At least one of these elements must be present.</td></tr>
 * 	<tr><td>extendedAddress</td><td>String</td><td align="center">N</td><td></td><td>At least one of these elements must be present.</td></tr>
 * 	<tr><td>city</td><td>String</td><td align="center">N</td><td></td><td>At least one of these elements must be present.</td></tr>
 * 	<tr><td>region</td><td>String</td><td align="center">N</td><td></td><td>At least one of these elements must be present.</td></tr>
 * 	<tr><td>postalCode</td><td>String</td><td align="center">N</td><td></td><td>At least one of these elements must be present.</td></tr>
 * 	<tr><td>country</td><td>String</td><td align="center">N</td><td></td><td>At least one of these elements must be present.</td></tr>
 * </table>
 * 
 * <h2>MatchNameAttributeKey</h2>
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>JSON Element/Node</th><th>Type</th><th>Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>firstName</td><td>String</td><td align="center">N</td><td></td><td>At least one of these elements must be present.</td></tr>
 * 	<tr><td>middleName</td><td>String</td><td align="center">N</td><td></td><td>At least one of these elements must be present.</td></tr>
 * 	<tr><td>lastName</td><td>String</td><td align="center">N</td><td></td><td>At least one of these elements must be present.</td></tr>
 * </table>
 * 
 * <h2>CCVEchoRequest</h2>
 * The CCV Echo Request is a request that uses the http GET operation to verify that the CCV service
 * is online. Again, the CCVEchoRequest is not a named node but the base request.
 * <table style="width:350" border="1px" summary="">
 * 	<tr><th>JSON Element/Node</th><th>Type</th><th>Required?</th><th>Predefined Values</th><th>Definition/Notes</th></tr>
 * 	<tr><td>requestId</td><td>String</td><td align="center">Y</td><td></td><td></td></tr>
 * 	<tr><td>message</td><td>String</td><td align="center">Y</td><td></td><td></td></tr>
 * </table>
 *  
 * <h2 id="tags">Annotations</h2>
 * <p>The following annotations are used in this package.</p>
 * <h3 id="data">The Data Annotation</h3>
 * <p>The lombok Data annotation provides the implementation for the setters and getters for the class
 * private properties as well as the 'toString()', 'hashCode()' and 'equals()' methods without having to 
 * code these methods. Because the methods are provided by the annotation and not specifically coded, the 
 * Java Doc for the class does not include these methods.</p>
 * <p>Aditional information about the annotation may be found at the <a href="https://projectlombok.org/features/Data" target="blank">Project Lombok </a> website.</p>
 * 
 * <h3 id="builder">The Builder Annotation</h3>
 * <p>The lombok Builder annotation implements the builder pattern on the classes that use it. The effect of this implementation is:</p><ul>
 * 	<li><b>Implements an all argument constructor</b> - All non final properties of the base class are treated as parameters for the constructor.</li>
 * 	<li><b>Implements a builder() method</b> - The base class's builder() method returns a builder class using the naming convention &lt;class_name&gt;Builder</li>
 * 	<li><b>Implements a Builder Class</b> - The &lt;class_name&gt;Builder class has the following attributes:<ol>
 * 		<li>Has the same private properties as the base class</li>
 * 		<li>A setter method is implemented for each of the private properties and has the same name as the property.</li>
 * 		<li>Implements a toString() method.</li>
 * 		<li>Implements a build() method. The build method returns an instance of the base class with the properties instantiated
 * 			that were set in the builder class.</li></ol></ul>
 * <p>The Builder class and annotation implemented methods do not have any Java Docs associated with them. Additional information 
 * about the Builder annotation may be found at the <a href="https://projectlombok.org/features/Builder" target="blank">Project Lombok</a> website.</p>
 * 
 *  
 *  
 * @author cornettl
 *
 */
package com.earlywarning.authentication.ccv;