/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.notificationserver;

import com.earlywarning.authentication.emailutils.MailChecker;
import com.earlywarning.authentication.startup.Env;

import lombok.extern.log4j.Log4j2;

/**
 * A class used to verify the different messages.
 * @author cornettl
 *
 */
@Log4j2
public class MessageVerifier {
	private static String expected;
	private static String subject;
    private static String fromAddress;
	

	/**
	 * A method to verify that an SMS message has been sent.
	 * @return True if there is evidence that the message was sent
	 * @throws InterruptedException An instance of the InterruptedException class.
	 */
	public boolean smsVerifier() throws InterruptedException {
		boolean result = false;
		MailChecker checker = new MailChecker();
		
		result = checker.check(expected);
		log.info(expected + " was found.");
		return result;
	}
	
	/**
	 * Verifies the short code in an SMS Message. The ability to verify the short code depends on the 
	 * SMS Forwarder used. If the sms forwarder used is not supported but provides the short code, 
	 * an enhancement request should be submitted to have this method updated. This method only returns
	 * false when the sms forwarder is supported and the code does not match the expected code.
	 * @param expected The expected short code
	 * @return True unless the short code found is different than expected.
	 */
	public boolean verifyShortCode(int expected) {
		boolean result = false;
		String publisher = "";
		String msg = null;
		
		// The short code can only be verified when using an SMS Forwarder that identifies the original sender
		// Get the sms forwarder publisher from the environment.properties file
		try {
			publisher = Env.getProperty("publisher");
			switch (publisher) {
				case "psencik":
					result = subject.contains(Integer.toString(expected));
					if (result) {
						msg = "The actual and expected short code is " + expected + ".";
					} else {
						msg = "The actual short code is different than the expected code.";
					}
					break;
				default:
					 msg = "The short code cannot be verified using the SMS Forwarder from " + publisher +".";
					log.info(msg);
					result = true;

			}
		} catch (NullPointerException e) {
			// This happened because the publisher was not set. The result will be true
			msg = "The publisher property was not defined in the environment.properties file. Check the SMS Forworder on your device and identify the publisher in the properties file.";
			log.info(msg);
			result = true;
		}
		return result;
	}
	
	public boolean verifyEmail() throws InterruptedException {
		return smsVerifier();
	}

	public static String getSubject() {
		return subject;
	}

	public static void setSubject(String subject) {
		MessageVerifier.subject = subject;
	}
	
	public static String getExpected() {
		return expected;
	}

	public static void setExpected(String expected) {
		MessageVerifier.expected = expected;
	}

    public static String getFromAddress() {
        return fromAddress;
    }

    public static void setFromAddress(String fromAddress) {
        MessageVerifier.fromAddress = fromAddress;
    }


}
