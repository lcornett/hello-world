/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.response.gui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class SortWindow extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	private int index = 0;
	private JPanel contentPane;
	private String[] labels = {"Primary Sort:", "Secondary Sort:", "Tertiary Sort:"};
	JComboBox<String> comboBox, orderComboBox;
	private JPanel mainPanel;
	private ArrayList<JComboBox<String>> comboBoxes = new ArrayList<JComboBox<String>>();
	private ArrayList<JLabel> jlabels = new ArrayList<JLabel>();
	private ArrayList<JLabel> orderLabels = new ArrayList<JLabel>();
	private ArrayList<JComboBox<String>> orderBoxes = new ArrayList<JComboBox<String>>();
	private GridLayout layout;
	private static ResponseFileEditor application;
	

	/**
	 * Create the frame.
	 */
	public SortWindow() {
		setTitle("Sort");
		setBounds(100, 100, 557, 209);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		layout = new GridLayout(1,4,5,5);
		
		mainPanel = new JPanel();
		contentPane.add(mainPanel, BorderLayout.PAGE_START);
		mainPanel.setLayout(layout);
		
		JLabel lblSort = new JLabel(labels[index++]);
		lblSort.setHorizontalAlignment(SwingConstants.TRAILING);
		mainPanel.add(lblSort);		
		
		comboBox = new JComboBox<String>();
		lblSort.setLabelFor(comboBox);
		comboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"", "Environment", "PayfoneEnvironment", "Feature Name", "Scenario Name", "Content Type"}));
		mainPanel.add(comboBox);
		
		JLabel lblOrder = new JLabel("Sort Order:");
		lblOrder.setHorizontalAlignment(SwingConstants.TRAILING);
		mainPanel.add(lblOrder);
		
		orderComboBox = new JComboBox<String>();
		lblSort.setLabelFor(orderComboBox);
		orderComboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"Ascending", "Descending"}));
		mainPanel.add(orderComboBox);

		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(null);
		contentPane.add(buttonPanel);
		
		JButton btnAddSubsort = new JButton("Add Subsort");
		btnAddSubsort.setBounds(84, 39, 109, 23);
		btnAddSubsort.addActionListener(this);
		buttonPanel.add(btnAddSubsort);
		
		JButton btnRemoveSubsort = new JButton("Remove Subsort");
		btnRemoveSubsort.setBounds(203, 39, 120, 23);
		btnRemoveSubsort.addActionListener(this);
		buttonPanel.add(btnRemoveSubsort);
		
		JButton btnNewButton = new JButton("Apply");
		btnNewButton.addActionListener(this);
		btnNewButton.setBounds(333, 39, 89, 23);
		buttonPanel.add(btnNewButton);
		
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		
		switch (command) {
		case "Add Subsort":
			try {
				layout.setRows(layout.getRows() + 1);
				JLabel lblSort = new JLabel(labels[index++]);
				lblSort.setHorizontalAlignment(SwingConstants.TRAILING);
				mainPanel.add(lblSort);
				jlabels.add(lblSort);
				
				JComboBox<String> comboBox = new JComboBox<String>();
				lblSort.setLabelFor(comboBox);
				comboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"", "Environment", "PayfoneEnvironment", "Feature Name", "Scenario Name", "Content Type"}));
				mainPanel.add(comboBox);
				comboBoxes.add(comboBox);
				
				JLabel label = new JLabel("Sort Order:");
				lblSort.setHorizontalAlignment(SwingConstants.TRAILING);
				mainPanel.add(label);
				orderLabels.add(label);
				
				JComboBox<String> orderComboBox = new JComboBox<String>();
				label.setLabelFor(orderComboBox);
				orderComboBox.setModel( new DefaultComboBoxModel<String>(new String[] {"Ascending", "Descending"}));
				mainPanel.add(orderComboBox);
				orderBoxes.add(orderComboBox);				
					
				mainPanel.revalidate();
				mainPanel.repaint();
			} catch (ArrayIndexOutOfBoundsException e1) {
				JOptionPane.showMessageDialog(null, "You cannot add any mores subsorts!");
				layout.setRows(layout.getRows() - 1);
				--index;
			}
			break;
		case "Apply":
			int count = 0;
			int[] indices = new int[comboBoxes.size() + 1];
			indices[count++] = comboBox.getSelectedIndex();
			
			for (JComboBox<String> box : comboBoxes) {
				indices[count++] = box.getSelectedIndex();
			}
			
			TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(application.table.getModel());
			List<RowSorter.SortKey> sortKeys = new ArrayList<>();
			int sortKey = comboBox.getSelectedIndex();
			SortOrder order = orderComboBox.getSelectedIndex() == 0 ?  SortOrder.ASCENDING : SortOrder.DESCENDING;

			switch (indices.length) {
			case 1:
				sortKeys.add(new RowSorter.SortKey(sortKey, order));
				break;
			default:
//				int[] keys = new int[orderBoxes.size()];
//				SortOrder[] orders = new SortOrder[orderBoxes.size()];
				sortKeys.add(new RowSorter.SortKey(sortKey, order));

				for (int i = 1; i < indices.length - 1; i++ ) {
					sortKey = comboBoxes.get(i).getSelectedIndex();
					order = orderBoxes.get(i).getSelectedIndex() == 0 ? SortOrder.ASCENDING : SortOrder.DESCENDING;
					sortKeys.add(new RowSorter.SortKey(sortKey, order));					
				}
				break;
			}
				sorter.setSortKeys(sortKeys);
				application.table.setRowSorter(sorter);
				this.dispose();

			break;
		case "Remove Subsort":
			try {
				JLabel label = jlabels.get(jlabels.size() - 1);
				mainPanel.remove(label);
				jlabels.remove(label);
				
				JComboBox<String> combo = comboBoxes.get(--index -1);
				mainPanel.remove(combo);
				comboBoxes.remove(combo);
				
				JLabel orderLabel = orderLabels.get(orderLabels.size() - 1);
				mainPanel.remove(orderLabel);
				orderLabels.remove(orderLabel);
				
				JComboBox<String> orderBox = orderBoxes.get(orderBoxes.size() - 1);
				mainPanel.remove(orderBox);
				orderBoxes.remove(orderBox);
				
				layout.setRows(layout.getRows() - 1);
				mainPanel.revalidate();
				mainPanel.repaint();
			System.out.println(layout.getRows());
			} catch (ArrayIndexOutOfBoundsException e1) {
				JOptionPane.showMessageDialog(null, "The primary sort controls cannot be removed!");
				--index;
			}
			break;
		}
		
	}
	
	/**
	 * A method to set the variable for the ResponseFileEditor
	 * @param application An instance of the ResponseFileEditor class
	 */
	public void setApplication(ResponseFileEditor application) {
		SortWindow.application = application;
	}
}
