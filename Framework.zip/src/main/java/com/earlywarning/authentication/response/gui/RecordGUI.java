/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.response.gui;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

/**
 * A class for the window of response record. This class takes care of creating 
 * making the form visible. 
 * @author cornettl
 *
 */
public class RecordGUI extends JFrame {
	private static final long serialVersionUID = 11L;
	JPanel contentPane;
	JTextField txtFeature;
	JTextField txtScenario;
	JComboBox<String> cboEnvironment, cboPayfoneEnvironment, cboContentType;
	JTextArea textArea;
	JButton btnAdd;
	private EventHandler eventHandler = new EventHandler(this);


	/**
	 * Create the frame.
	 */
	public RecordGUI() {
		setResizable(false);
		setTitle("Add Record");
		setBounds(100, 100, 524, 755);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 488, 695);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblEnvironment = new JLabel("Environment:");
		lblEnvironment.setHorizontalAlignment(SwingConstants.TRAILING);
		lblEnvironment.setBounds(10, 23, 115, 19);
		panel.add(lblEnvironment);
		
		JLabel lblPayfoneEnvironment = new JLabel("Payfone Environment:");
		lblPayfoneEnvironment.setHorizontalAlignment(SwingConstants.TRAILING);
		lblPayfoneEnvironment.setBounds(10, 46, 115, 24);
		panel.add(lblPayfoneEnvironment);
		
		JLabel lblFeatureName = new JLabel("Feature Name:");
		lblFeatureName.setHorizontalAlignment(SwingConstants.TRAILING);
		lblFeatureName.setBounds(10, 71, 115, 24);
		panel.add(lblFeatureName);
		
		JLabel lblScenarioName = new JLabel("Scenario Name:");
		lblScenarioName.setHorizontalAlignment(SwingConstants.TRAILING);
		lblScenarioName.setBounds(10, 97, 115, 24);
		panel.add(lblScenarioName);
		
		JLabel lblContentType = new JLabel("Content Type:");
		lblContentType.setHorizontalAlignment(SwingConstants.TRAILING);
		lblContentType.setBounds(10, 121, 115, 24);
		panel.add(lblContentType);
		
		JLabel lblResponse = new JLabel("Response:");
		lblResponse.setBounds(10, 144, 115, 24);
		panel.add(lblResponse);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 166, 468, 460);
		panel.add(scrollPane);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		
		String[] envOptions = {"", "qa", "prod"};
		cboEnvironment = new JComboBox<String>();
		cboEnvironment.setToolTipText("The environment that this response will be found in. This field may be empty if this a Payfone test but the Payfone Envifonment must be completed.");
		cboEnvironment.setModel(new DefaultComboBoxModel(new String[] {"", "qa", "prod"}));

		cboEnvironment.setBounds(135, 23, 153, 19);
		panel.add(cboEnvironment);
		
		String[] payfoneOptions = {"", "staging", "prod"};
		cboPayfoneEnvironment = new JComboBox<String>();
		cboPayfoneEnvironment.setToolTipText("The Payfone Environment that the application is pointed to. If not associated with a Payfone test case, this field man be empty but the Environment field is required.");
		cboPayfoneEnvironment.setModel(new DefaultComboBoxModel(new String[] {"", "staging", "prod"}));
		cboPayfoneEnvironment.setBounds(135, 49, 153, 19);
		panel.add(cboPayfoneEnvironment);
		
		txtFeature = new JTextField();
		txtFeature.setToolTipText("The name of the feature from the feature file. ");
		txtFeature.setHorizontalAlignment(SwingConstants.LEFT);
		txtFeature.setBounds(135, 73, 343, 20);
		panel.add(txtFeature);
		txtFeature.setColumns(10);
		
		txtScenario = new JTextField();
		txtScenario.setToolTipText("The name of the scenario from the feature file.");
		txtScenario.setHorizontalAlignment(SwingConstants.LEFT);
		txtScenario.setColumns(10);
		txtScenario.setBounds(135, 99, 343, 20);
		panel.add(txtScenario);
		
		String[] contentOptions = {"application/json", "text/xml"};
		cboContentType = new JComboBox<String>();
		cboContentType.setToolTipText("The content type of the message.");
		cboContentType.setModel(new DefaultComboBoxModel(new String[] {"application/json", "text/xml"}));
		cboContentType.setBounds(135, 125, 153, 20);
		panel.add(cboContentType);
		
		btnAdd = new JButton("Add");
		btnAdd.setToolTipText("Add the current record to the table.");
		btnAdd.setBounds(147, 647, 89, 23);
		btnAdd.addActionListener(eventHandler);
		panel.add(btnAdd);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setToolTipText("Cancels the operation.");
		btnCancel.setBounds(246, 647, 89, 23);
		btnCancel.addActionListener(eventHandler);
		panel.add(btnCancel);
	}
	
	/**
	 * A method that validates the fields of the class. There are only three fields of concern 
	 * because the Combo Boxes are never empty. 
	 * @return true if the fields are not null or empty.
	 */
	boolean validateFields() {
		boolean result = false;
		boolean environment = false;
		boolean payfoneEnvironment = false;
		
		try {
			environment = cboEnvironment.getSelectedIndex() == 0 ? false : true;
			payfoneEnvironment = cboPayfoneEnvironment.getSelectedIndex() == 0 ? false : true;
			
			if (environment || payfoneEnvironment) {
				result = true;
			}
			result = txtFeature.getText().isEmpty() ? false : result;
			result = txtScenario.getText().isEmpty() ? false : result;
			result = textArea.getText().isEmpty() ? false : result;
		} catch (NullPointerException e) {
			result = false;
		}
		
		return result;
	}
}
