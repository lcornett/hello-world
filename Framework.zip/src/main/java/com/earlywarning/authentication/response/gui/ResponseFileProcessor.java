/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.response.gui;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * A class that handles the operations on the ecpected responses file. The operations are:<ul>
 * 	<li>Opening and reading he file.</li>
 * 	<li>Creating the table model that will display the read records.</li>
 * 	<li>Saving the file.</li>
 * 	<li>Formatting the json or xml message.</li></ul>
 * @author cornettl
 *
 */
public class ResponseFileProcessor {
	
	/**
	 * Opens and reads the file, creates the table model for the main form and returns the table model.
	 * @param file The file to be read.
	 * @return The created table model containing the data and column names.
	 */
	public DefaultTableModel readFile(File file) {
		DefaultTableModel model = null;
		
		JSONParser parser = new JSONParser();
		
		try (FileReader reader = new FileReader(file)) {
			Object obj = parser.parse(reader);
			JSONObject jsonObject = (JSONObject) obj;
			JSONArray responses = (JSONArray) jsonObject.get("responses");
			
			model = createTableModel(responses);			
		} catch (IOException | ParseException e) {
			GuiExceptionHandler.handleException(e);
			e.printStackTrace();
		} 
		return model;

	}
	
	/**
	 * Saves the contents of the table to a file.
	 * @param file The file to save the records to.
	 * @param table The table containing the data to save.
	 */
	public void saveFile(File file, JTable table) {
		ExpectedResponses expected = new ExpectedResponses();
		ArrayList<Response> responses = new ArrayList<Response>();
		int rows = table.getModel().getRowCount();
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			for (int i = 0; i < rows; i++) {
				Response response = new Response();
				response.setEnvironment(table.getModel().getValueAt(i, 0).toString());
				response.setPayfoneEnvironment(table.getModel().getValueAt(i, 1).toString());
				response.setFeature(table.getModel().getValueAt(i, 2).toString());
				response.setScenario(table.getModel().getValueAt(i, 3).toString());
				response.setContentType(table.getModel().getValueAt(i, 4).toString());
				response.setExpectedResponse(table.getModel().getValueAt(i, 5).toString());
				responses.add(response);			
			}
			
			expected.setResponses(responses);
			
			mapper.writerWithDefaultPrettyPrinter().writeValue(file, expected);
		} catch (IOException e) {
			GuiExceptionHandler.handleException(e);
			e.printStackTrace();
		}
	}
	
	/**
	 * A method that formats the xml message into a pretty format
	 * @param xml The xml string.
	 * @return The pretty formattted xml string
	 */
	private static String xmlFormat(String xml) {
		
		try {			
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setValidating(false);
			DocumentBuilder db = dbf.newDocumentBuilder();
			
			Document doc = db.parse(new ByteArrayInputStream(xml.getBytes()));
			
			Writer out = null;
			try {
				TransformerFactory factory = TransformerFactory.newInstance();
				factory.setAttribute("indent-number", new Integer(4));
				
				Transformer tf = factory.newTransformer();
				tf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
				tf.setOutputProperty(OutputKeys.INDENT, "yes");
				out = new StringWriter();
				tf.transform(new DOMSource(doc), new StreamResult(out));
			} catch (TransformerConfigurationException e) {
				GuiExceptionHandler.handleException(e);
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				GuiExceptionHandler.handleException(e);
				e.printStackTrace();
			} catch (TransformerFactoryConfigurationError e) {
				GuiExceptionHandler.handleException(e);
				e.printStackTrace();
			} catch (TransformerException e) {
				GuiExceptionHandler.handleException(e);
				e.printStackTrace();
			}
			
			return out.toString();
		} catch (ParserConfigurationException e1) {
			GuiExceptionHandler.handleException(e1);
			e1.printStackTrace();
		} catch (SAXException e1) {
			GuiExceptionHandler.handleException(e1);
			e1.printStackTrace();
		} catch (IOException e1) {
			GuiExceptionHandler.handleException(e1);
			e1.printStackTrace();
		} finally {
			
		}
		
		return null;
	}
	
	/**
	 * A method that performs the work of creating the table model.
	 * @param responses The responses as read from the file.
	 * @return A populated table model
	 */
	DefaultTableModel createTableModel(JSONArray responses) {
		String[] columnNames = {"Environment", "Payfone Environment", "Feature Name", "Scenario Name", "Content Type", "Expected Response"};
		
		DefaultTableModel model = new DefaultTableModel(columnNames, 0);
		
		if (null != responses) {
			for (Object response : responses) {
				JSONObject current = (JSONObject) response;
				
				Vector<String> row = new Vector<String>();
				row.add((String) current.get("environment"));
				row.add((String) current.get("payfoneEnvironment"));
				row.add((String) current.get("feature"));
				row.add((String) current.get("scenario"));
				row.add((String) current.get("contentType"));
				row.add((String) current.get("expectedResponse"));
				model.addRow(row);
			} 
		} 
		return model;
	}
	
	/**
	 * A method that formats the response message into pretty format. This method detects whether 
	 * the message passed in as the argumant is JSON or XML.
	 * @param response The response message to format.
	 * @return The formatted response.
	 */
	public static String responseFormatter(String response) {
		// determine the type
		try {
			if (response.startsWith("{")) {
				ObjectMapper mapper = new ObjectMapper();
				Object json = mapper.readValue(response, Object.class);
				return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(json);
			} else if (response.startsWith("<")) {
				
				return xmlFormat(response);
				
			}
		} catch (JsonParseException e) {
			GuiExceptionHandler.handleException(e);
			e.printStackTrace();
		} catch (JsonMappingException e) {
			GuiExceptionHandler.handleException(e);
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			GuiExceptionHandler.handleException(e);
			e.printStackTrace();
		} catch (IOException e) {
			GuiExceptionHandler.handleException(e);
			e.printStackTrace();
		}
		return null;
	}

}
