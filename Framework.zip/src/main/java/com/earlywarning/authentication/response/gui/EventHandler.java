/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.response.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringReader;
import java.util.Vector;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.DefaultTableModel;

import org.apache.commons.io.FilenameUtils;

/**
 * A class that processes almost all of the application's menu and button events. Some 
 * events, like the table mouse events are handled by anonymous inner classes.
 * @author cornettl
 *
 */
public class EventHandler implements ActionListener, WindowListener {
	static ResponseFileEditor application;
	static RecordGUI record;
	private ResponseFileProcessor processor = new ResponseFileProcessor();

	/**
	 * Constructor that takes an instance of the ResponseFileEditor.
	 * @param editor An instance of the ResponseFileEditor class.
	 */
	public EventHandler(ResponseFileEditor editor) {
		application = editor;
	}
	
	/**
	 * A constructor that takes an instance of the RecordGUI class.
	 * @param record An instance of the RecordGUI class.
	 */
	public EventHandler(RecordGUI record) {
		EventHandler.record = record;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		switch (command) {
			case "About":
				doAbout();
				break;
			case "Add":
				doAdd();
				break;
			case "Cancel":
				doCancel();
				break;
			case "Clear Filter":
				doClearFilter();
				break;
			case "Close":
				doClose();
				break;
			case "Create":
				doCreate();
				break;
			case "Delete":
				doDelete();
				break;
			case "Exit":
				doExit();
				break;
			case "Find":
				doFind();
				break;
			case "New":
				doNew();
				break;
			case "Open":
				doOpen();
				break;
			case "Save":
				doSave();
				break;
			case "Save As":
				doSaveAs();
				break;
			case "Sort":
				doSort();
				break;
			case "Update":
				doUpdate();
				break;
			case "Update Record":
				doUpdateRecord();
				break;
			default: 
				String msg = "The command " + command + " is not implemented.";
				JOptionPane.showMessageDialog(null, msg);
		}

	}
	
	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosing(WindowEvent e) {
		doExit();
	}

	@Override
	public void windowClosed(WindowEvent e) {
		// Not Implemented
		
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// Not implemented
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// Not implementedd
		
	}

	@Override
	public void windowActivated(WindowEvent e) {
		// Not implemented
		
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// Not implemented
		
	}
	
	/**
	 * A method that handles an event on the About menu item. The only thing this does is display
	 * a dialog box with information abbout the application.
	 */
	private void doAbout() {
		String message = "This application is the property of Early Warning Services\u2122!"
				+ "\nIt was developed by: Larry Cornett."
				+ "\nFor information about the application, please contact the developer.";
		JOptionPane.showMessageDialog(null, message);
	}
	
	/**
	 * A method which is invoked from the RecordGUI, that adds the new Response record to the 
	 * record list. Before adding the record to the list, the text fields are validated. If 
	 * validation fails, the user is prompted to close the form or leave it open.
	 */
	private void doAdd() {
		String response = null;
		
		if (record.validateFields()) {
			String contentType = record.cboContentType.getSelectedItem().toString();
			Vector<String> row = new Vector<String>();
			row.add(record.cboEnvironment.getSelectedItem().toString());
			row.add(record.cboPayfoneEnvironment.getSelectedItem().toString());
			row.add(record.txtFeature.getText());
			row.add(record.txtScenario.getText());
			row.add(contentType);
			response = record.textArea.getText();
			if (contentType.equals("text/xml")) {
				response = parseXml(response);
			} else {
				response = response.replaceAll("\n", "").replaceAll("\r", "").replaceAll("  ", "");
			}
			row.add(response);
			record.setVisible(false);
			DefaultTableModel model = (DefaultTableModel) application.table.getModel();
			model.addRow(row);
			application.table.setModel(model);
			application.isDirty = true;
			setFileMenuItems(false, false, true, true, true);
			setEditMenuItems(true, true, true);
			setSearchMenuItems(true, true, false);
		} else {
			String message = "One or more of the record fields is empty. Do you want to close the record form?";
			int option = JOptionPane.showConfirmDialog(null, message, "Error", JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE, null);
			
			if (option == 0) {
				record.setVisible(false);
				record.dispose();
			} 			
		}
	}


	/**
	 * A method, called from the RecordGUI class that cancels the current operation.
	 */
	private void doCancel() {
		record.setVisible(false);
		record.dispose();
		application.eventHandler.setFileMenuItems(true, true, true, false, true);
		application.eventHandler.setEditMenuItems(true, true, true);
		application.eventHandler.setSearchMenuItems(true, true, true);
	}
	
	/**
	 * A method that clears a filter that has been set.
	 */
	private void doClearFilter() {
		application.table.setRowSorter(null);
		application.isFiltered = false;
		setFileMenuItems(false, false, false, true, true);
		setEditMenuItems(true, true, true);
		setSearchMenuItems(true, true, true);
	}
	
	/**
	 * A method that handles events on the File -> Close menu item. The tasks of this method are:<ul>
	 * 	<li>Check to see if the file has been changed and needs to be saved. If so, displays a dialog to the user.<li>
	 * 	<li>Clears the table.<li>
	 * 	<li>Sets the currentFile variable in the GUI.<li>
	 * 	<li>Sets the menu items to their appropriate enabled values.</li>
	 * 	<li>Resets the flag that prompts the user to save the file.</li>,?ul>
	 */
	private void doClose() {
		String msg = ""; 
		
		if (application.isDirty) {
			msg = "There are unsaved records in the file. Do you wish to save them?";
			int option = JOptionPane.showOptionDialog(null, msg, "Unsaved Records", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, "Yes");
			System.out.println(option);
			if (option == 0) {
				doSave();
			} else if (option == 2) {
				return;
			} 
		}
		application.table.clearSelection();
		DefaultTableModel model = processor.createTableModel(null);
		application.table.setModel(model);
		ResponseFileEditor.currentFile = null;
		
		setFileMenuItems(true, true, false, false, false);
		setEditMenuItems(false, false, false);
		setSearchMenuItems(false, false, false);

		application.isDirty = false;
		application.isFiltered = false;
	}
	
	/**
	 * A method to handle events on the Edit -> Create menu item. This method instantiates 
	 * an instance of the Record GUI and displays it.
	 */
	private void doCreate() {
		setFileMenuItems(false, false, false,false, false);
		setEditMenuItems(false, false, false);
		setSearchMenuItems(false, false, false);
		
		RecordGUI record = new RecordGUI();
		record.setVisible(true);
	}
	
	/**
	 * A method that deletes a row from the table.
	 */
	private void doDelete() {
		JTable table = application.table;
		int rowNum = table.getSelectedRow();
		if (rowNum >= 0) {
			int modelIndex = table.convertRowIndexToModel(rowNum);
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			model.removeRow(modelIndex);
		}
	}
	
	/**
	 * A method that checks if the work needs to be saved and quits the application. If the 
	 * work has not been saved, a dialog is displayed asking the user to save.
	 */
	private void doExit() {
		if (application.isDirty) {
			String message = "The file has not been saved. Do you want to save the file?";
			int option = JOptionPane.showConfirmDialog(null, message, "Closing Application", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null);
			
			if (option == 0) {
				doSave();
			}
		}
		System.exit(0);
	}

	/**
	 * 	A method that handles events on the Search -> Find mwnu item. This method displays the
	 * Search window and passes an instance of the GUI to the window so that it can act on the controls.
	 */
	private void doFind() {
		setFileMenuItems(false, false, false, false, true);
		setEditMenuItems(false, false, false);
		setSearchMenuItems(false, false, false);
		
		SearchWindow search = new SearchWindow();
		search.setApplication(application);
		search.setVisible(true);
	}
	
	/**
	 * A method that handles events on the File -> New menu item. The tasks of
	 * this method are:<ul>
	 * 	<li>Refresh the TableModel so that no rows are displayed in the table.</li>
	 * 	<li>Set the menu items and buttons to the appropriate enabled values.</li></ul>
	 */
	private void doNew() {
		ResponseFileEditor.currentFile = null;
		DefaultTableModel model = processor.createTableModel(null);
		application.table.setModel(model);
		
		setFileMenuItems(false, false, true, false, false);
		setEditMenuItems(true, false, false);
	}
	
	/**
	 * A method that handles events on the File -> Open menu item. This method
	 * displays the file chooser, opens the selected file, uses the ResponseFileProcessor
	 * class to read in the file and return the TableModel, sets the currentFile variable
	 * in the GUI class and sets the menu items to the appropriate enabled values.
	 */
	private void doOpen() {
		final JFileChooser chooser = new JFileChooser();
		FileFilter filter = new FileFilter() {
			public String getDescription() {
				return "JSON Files (*.json)";
			}
			public boolean accept (File file) {
				if (file.isDirectory()) {
					return true;
				} else {
					return file.getName().toLowerCase().endsWith(".json");
				}
			}
		};
		chooser.addChoosableFileFilter(filter);
		chooser.setFileFilter(filter);
		int returnVal = 0;
		File file = null;
		
		returnVal = chooser.showOpenDialog(null);
		
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			file = chooser.getSelectedFile();
			DefaultTableModel model = processor.readFile(file);
			ResponseFileEditor.currentFile = file.getAbsolutePath();
			application.table.setModel(model);
			
			setFileMenuItems(false, false, true, false, true);
			setEditMenuItems(true, true, true);
			setSearchMenuItems(true, true, false);
		}
	}
	
	/**
	 * A mehtod that handles events on the File -> Save menu item. The tasks performed are:<ul>
	 * 	<li>Checks to determine if the filename is known.</li>
	 * 	<li>If the filename is unknown, displays the file Chooser.</li>
	 * 	<li>Calls the ResponseFileProcessor class to save the file.</li>
	 * 	<li>Enables and disables the appropriate menu items.
	 * 	<li>Resets the flag that determines if the file needs to be saved.</li></ul>
	 */
	private void doSave() {
		final JFileChooser chooser = new JFileChooser();
		FileFilter filter = new FileFilter() {
			public String getDescription() {
				return "JSON Files (*.json)";
			}
			public boolean accept (File file) {
				if (file.isDirectory()) {
					return true;
				} else {
					return file.getName().toLowerCase().endsWith(".json");
				}
			}
		};
		chooser.setFileFilter(filter);	
		int returnVal = 0;
		File file = null;
		
		if (ResponseFileEditor.currentFile != null) {
			file = new File(ResponseFileEditor.currentFile);
		} else {
			returnVal = chooser.showSaveDialog(null);
			if (returnVal == 0) {
				file = chooser.getSelectedFile();
				if (FilenameUtils.getExtension(file.getName()).equals("json")) {
					// filename os as is
				} else {
					file = new File(file.toString() + ".json");
					file = new File(file.getParentFile(), FilenameUtils.getBaseName(file.getName()) + ".json");
				}
			}
		}
			
		processor.saveFile(file, application.table);
		
		application.isDirty = false;
		
		setFileMenuItems(false, false, true, false, true);
		setEditMenuItems(true, true, true);
		setSearchMenuItems(true, true, false);
		
		
	}
	
	/**
	 * A method that handles the events of the File -> Save As menu item. The methods tasks are:<ul>
	 * 	<li>Displays the FileChooser Save dialog.</li>
	 * 	<li>Calls the ResponseFileProcessor's saveFile method.</li>
	 * 	<li>Updates the GUI's currentFile variable.</li>
	 * 	<li>Updates the GUI's flag to save new work.</li>
	 *  <li>Updates the enabled property of the menu items.</li></ul>
	 */
	private void doSaveAs() {
		final JFileChooser chooser = new JFileChooser();
		FileFilter filter = new FileFilter() {
			public String getDescription() {
				return "JSON Files (*.json)";
			}
			public boolean accept (File file) {
				if (file.isDirectory()) {
					return true;
				} else {
					return file.getName().toLowerCase().endsWith(".json");
				}
			}
		};
		chooser.setFileFilter(filter);
		int returnVal = 0;
		File file = null;
		
		returnVal = chooser.showSaveDialog(null);
		
		if (returnVal == 0) {
			file = chooser.getSelectedFile();
			if (FilenameUtils.getExtension(file.getName()).equals("json")) {
				// filename os as is
			} else {
				file = new File(file.toString() + ".json");
				file = new File(file.getParentFile(), FilenameUtils.getBaseName(file.getName()) + ".json");
			}
		}
		
		processor.saveFile(file, application.table);
		ResponseFileEditor.currentFile = file.getAbsolutePath();
		application.isDirty = false;
		
		setFileMenuItems(false, false, true, false, true);
		setEditMenuItems(true, true, true);
		setSearchMenuItems(true, true, false);
	}


	
	/**
	 * A method that handles events on the Sort menu item. The tasks performed by this method are:<ul>
	 * 	<li>Create and display the SortWindow.</li>
	 * 	<li>Pass an instance of the ResponseFileEditor (GUI) to the window so it can access the controls.M/li></ul>
	 */
	private void doSort() {
		SortWindow sort = new SortWindow();
		sort.setVisible(true);
		sort.setApplication(application);

	}
	
	/**
	 * A method that handles the event on the Edit -> Update menu item. The tasks of this method are:<ul>
	 * 	<li>Check if a row from the table is selected. If not a dialog is displayed prompting the user to select a row.</li>
	 * 	<li>Create an instance of the RecordGUI class, populates it with the selected row's data and displays it.</li></ul>
	 */
	void doUpdate() {
		RecordGUI record = new RecordGUI();
		record.setTitle("Update Record");
		record.btnAdd.setText("Update Record");
		String msg = "";
		JTable table = application.table;
		
		
		if (table.getSelectedRow() != -1) {
			record.cboEnvironment.setSelectedItem((table.getValueAt(table.getSelectedRow(), 0)));
			record.cboPayfoneEnvironment.setSelectedItem(table.getValueAt(table.getSelectedRow(), 1));
			record.txtFeature.setText(table.getValueAt(table.getSelectedRow(), 2).toString());
			record.txtScenario.setText(table.getValueAt(table.getSelectedRow(), 3).toString());
			record.cboContentType.setSelectedItem(table.getValueAt(table.getSelectedRow(), 4));
			record.textArea.setText(ResponseFileProcessor.responseFormatter(table.getValueAt(table.getSelectedRow(), 5).toString()));
			
			setFileMenuItems(false, false, false, false, true);
			setEditMenuItems(false, false, false);
			setSearchMenuItems(false, false, false);
			record.setVisible(true);
			return;
		} else {
			msg = "There are no table rows selected. Please select a row!";
		} 
		
		JOptionPane.showMessageDialog(null, msg);	
		return;
	}
		
	/**
	 * A method that is called from the RecordGUI to update the table row being edited. 
	 * Besides updating the table row, the fields of the main form are updated as well.
	 * Finally, the application's flag for saving is updated and the Record form is disposed of.
	 */
	private void doUpdateRecord() {
		JTable table = application.table;
		int rowNum = table.getSelectedRow();
		String contentType = record.cboContentType.getSelectedItem().toString();
		String response = "";
		
		table.setValueAt(record.cboEnvironment.getSelectedItem().toString(), rowNum, 0);
		application.cboEnvironment.setSelectedItem(record.cboEnvironment.getSelectedItem().toString());
		table.setValueAt(record.cboPayfoneEnvironment.getSelectedItem().toString(), rowNum, 1);
		application.cboPayfoneEnv.setSelectedItem(record.cboPayfoneEnvironment.getSelectedItem().toString());
		table.setValueAt(record.txtFeature.getText(), rowNum, 2);
		application.txtFeature.setText(record.txtFeature.getText());
		table.setValueAt(record.txtScenario.getText(), rowNum, 3);
		application.txtScenario.setText(record.txtScenario.getText());
		table.setValueAt(record.cboContentType.getSelectedItem().toString(), rowNum, 4);
		application.cboContentType.setSelectedItem(record.cboContentType.getSelectedItem().toString());
		
		response = record.textArea.getText();
		if (contentType.equals("text/xml")) {
			response = parseXml(response);
		} else {
			response = record.textArea.getText().replaceAll("\n", "").replaceAll("\r", "").replaceAll("  ", "");
		}
		table.setValueAt(response, rowNum , 5);
		application.response.setText(record.textArea.getText());
		application.isDirty = true;
		
		setFileMenuItems(false, false, true, false, true);
		setEditMenuItems(true, true, true);
		setSearchMenuItems(true, true, false);
		
		record.setVisible(false);
		record.dispose();
	}
		
	/**
	 * A method that reads a formatted xml string and turns it into an unformatted string
	 * by removing new line characters, carriage returns and white space.
	 * @param original The formatted xml string.
	 * @return The unformatted string.
	 */
	private String parseXml(String original) {
		System.out.println(original);
		String line = "";
		StringBuilder sb = new StringBuilder();
		
		try (BufferedReader br = new BufferedReader(new StringReader(original))){
			while ((line=br.readLine()) != null ) {
				sb.append(line.trim());
			}
			
		} catch (FileNotFoundException e) {
			GuiExceptionHandler.handleException(e);
			e.printStackTrace();
		} catch (IOException e1) {
			GuiExceptionHandler.handleException(e1);
			e1.printStackTrace();
		}
		
		return sb.toString();
	}
	
	/**
	 * A method that enables or disables the menu items and buttons for the File menu.
	 * @param newItem The enabled value for the New menu item.
	 * @param openItem The enabled value for the Open menu item and the Open button.
	 * @param closeItem The enabled value for the Close menu item.
	 * @param saveItem The enabled value for the Save menu item and the Save buton.
	 * @param saveAsItem The enabled value for the Save As menu item and the Save As button
	 */
	void setFileMenuItems(boolean newItem, boolean openItem, boolean closeItem, boolean saveItem, boolean saveAsItem) {
		try {
			newItem = application.currentFile != null ? false : newItem;
			application.mntmNew.setEnabled(newItem);
			
			openItem = application.currentFile != null ? false : openItem;
			application.mntmOpen.setEnabled(openItem);
			application.btnOpen.setEnabled(openItem);
			
			application.mntmClose.setEnabled(closeItem);
			
			saveItem = application.isDirty ? true : saveItem;
			application.mntmSave.setEnabled(saveItem);
			application.btnSave.setEnabled(saveItem);
			application.mntmSaveAs.setEnabled(saveAsItem);	
			application.btnSaveAs.setEnabled(saveAsItem);
		} catch (Exception e) {
			GuiExceptionHandler.handleException(e);
			e.printStackTrace();
		}
		
	}
	
	/**
	 * A method that enables or disables the menu items and buttons for the edit menu.
	 * @param createItem The enabled value for the Create menu item and button.
	 * @param updateItem The enabled value for the Update menu item and button.
	 * @param deleteItem The enabled value for the Delete menu item and button.
	 */
	void setEditMenuItems(boolean createItem, boolean updateItem, boolean deleteItem) {
		try {
			application.mntmCreate.setEnabled(createItem);
			application.btnCreate.setEnabled(createItem);
			application.mntmUpdate.setEnabled(updateItem);
			application.btnUpdate.setEnabled(updateItem);
			application.mntmDelete.setEnabled(deleteItem);
			application.btnDelete.setEnabled(deleteItem);
		} catch (Exception e) {
			GuiExceptionHandler.handleException(e);
			e.printStackTrace();
		}
	}
	
	/**
	 * A method that sets the enabled property for the menu items under the search menu.
	 * @param findItem The enabled value for the Find menu item.
	 * @param sortItem The enabled property for the Sort menu item.
	 */
	void setSearchMenuItems(boolean findItem, boolean sortItem, boolean clearFilter) {
		
		try {
			findItem = application.isFiltered ? false : findItem;
			application.mntmFind.setEnabled(findItem);
			
			sortItem = application.isFiltered ? false : sortItem;
			application.mntmSort.setEnabled(sortItem);
			
			clearFilter = application.isFiltered ? true : clearFilter;
			application.mntmClearFilter.setEnabled(clearFilter);
			
		} catch (Exception e) {
			GuiExceptionHandler.handleException(e);
			e.printStackTrace();
		}
	}

}
