/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.response.json;

import java.util.ArrayList;

import com.earlywarning.authentication.common.Address;
import com.earlywarning.authentication.common.Entry;
import com.earlywarning.authentication.common.Event;
import com.earlywarning.authentication.common.FinalTargetUrl;
import com.earlywarning.authentication.common.Match;
import com.earlywarning.authentication.common.Vfp;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/**
 * A POJO that represents the dataLookup element in an Authentify JSON
 * Response. 
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_EMPTY)
public class DataLookup {
	private String mobileIdentityCreated;
	private String mobileOperatorName;
	private String callArrivalTime;
	private String consentCollectedDate;
	private String consentDescription;
	private String consentTransactionId;
	private String deviceIp;
	private String email;
	private String enterprisePhoneNumber;
	private String mobileNetworkOperator;
	private String lastVerificationDate;
	private FinalTargetUrl finalTargetUrl;
	private ArrayList<Event> lastChangeEvents;
	private String statusIndex;
	private String deviceType;
	private String ownershipStatus;
	private ArrayList<Entry> flagEntries;
	private ArrayList<Match> matchResults;
	private Address address;
	private Vfp vfp;
}
