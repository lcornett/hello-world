/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.response.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 * A class that displays a JFrame for the purpose of filtering/searching a JTable. 
 * @author cornettl
 *
 */
public class SearchWindow extends JFrame implements ActionListener, WindowListener {
	private static final long serialVersionUID = 1L;
	private ResponseFileEditor application;
	private JPanel contentPane, mainPanel;
	private JTextField textField;
	private JComboBox<String> comboBox;
	int rows = 0;
	ArrayList<JLabel> comboLabels = new ArrayList<JLabel>();
	ArrayList<JComboBox<String>> combos = new ArrayList<JComboBox<String>>();
	ArrayList<JLabel> textLabels = new ArrayList<JLabel>();
	ArrayList<JTextField> textFields = new ArrayList<JTextField>();
	
	/**
	 * A one argument constructor to inject an instance of the application form into the class.
	 * @param app An Instance of the ResponseFileEditor
	 */
	public SearchWindow(ResponseFileEditor app) {
		this.application = app;
	}

	/**
	 * Create the frame.
	 */
	public SearchWindow() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		addWindowListener(this);
		setTitle("Search");
		setBounds(100, 100, 836, 146);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0,0));
		
		mainPanel = new JPanel();
		contentPane.add(mainPanel, BorderLayout.PAGE_START);
		GridBagLayout gbl_mainPanel = new GridBagLayout();
		gbl_mainPanel.columnWidths = new int[] {75, 150, 100, 400};
		gbl_mainPanel.rowHeights = new int[]{20, 0};
		gbl_mainPanel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0};
		gbl_mainPanel.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		mainPanel.setLayout(gbl_mainPanel);
		
		JLabel lblFieldToSearch = new JLabel("Field to Search:");
		lblFieldToSearch.setHorizontalAlignment(SwingConstants.LEFT);
		lblFieldToSearch.setBounds(10, 11, 102, 14);
		GridBagConstraints gbc_lblFieldToSearch = new GridBagConstraints();
		gbc_lblFieldToSearch.fill = GridBagConstraints.BOTH;
		gbc_lblFieldToSearch.insets = new Insets(0, 0, 0, 5);
		gbc_lblFieldToSearch.gridx = 0;
		gbc_lblFieldToSearch.gridy = rows;
		mainPanel.add(lblFieldToSearch, gbc_lblFieldToSearch);
		
		comboBox = new JComboBox<String>();
		comboBox.setToolTipText("Select the field to perform the filter on.");
		comboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"Environment\t", "Payfone Environment", "Feature Name", "Sceanrio Name", "Content Type"}));
		comboBox.setBounds(110, 8, 137, 20);
		GridBagConstraints gbc_comboBox = new GridBagConstraints();
		gbc_comboBox.fill = GridBagConstraints.BOTH;
		gbc_comboBox.insets = new Insets(0, 0, 0, 5);
		gbc_comboBox.gridx = 1;
		gbc_comboBox.gridy = rows;
		mainPanel.add(comboBox, gbc_comboBox);
		
		JLabel lblSearchTerm = new JLabel("Search Term:");
		lblSearchTerm.setBounds(281, 11, 84, 14);
		GridBagConstraints gbc_lblSearchTerm = new GridBagConstraints();
		gbc_lblSearchTerm.fill = GridBagConstraints.BOTH;
		gbc_lblSearchTerm.insets = new Insets(0, 0, 0, 5);
		gbc_lblSearchTerm.gridx = 2;
		gbc_lblSearchTerm.gridy = rows;
		mainPanel.add(lblSearchTerm, gbc_lblSearchTerm);
		
		textField = new JTextField();
		textField.setToolTipText("Enter the term or regular expression to find.");
		textField.setBounds(375, 8, 435, 20);
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.fill = GridBagConstraints.BOTH;
		gbc_textField.gridx = 3;
		gbc_textField.gridy = rows;
		mainPanel.add(textField, gbc_textField);
		textField.setColumns(10);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(null);
		contentPane.add(buttonPanel);
		
		JButton btnAddSubsort = new JButton("Add Filter");
		btnAddSubsort.setBounds(195, 43, 109, 23);
		btnAddSubsort.addActionListener(this);
		buttonPanel.add(btnAddSubsort);
		
		JButton btnRemoveSubsort = new JButton("Remove Filter");
		btnRemoveSubsort.setBounds(314, 43, 120, 23);
		btnRemoveSubsort.addActionListener(this);
		buttonPanel.add(btnRemoveSubsort);
		
		JButton btnNewButton = new JButton("Apply");
		btnNewButton.addActionListener(this);
		btnNewButton.setBounds(444, 43, 89, 23);
		buttonPanel.add(btnNewButton);
		
	}
		
	/**
	 * A method for setting the application variable.
	 * @param application An instance of the ResponseFIleEditor
	 */
	public void setApplication(ResponseFileEditor application) {
		this.application = application;
	}

	/** 
	 * A method to process local actions.
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		int index = -1;
		String searchFor = "";
		
		switch (command) {
			case "Add Filter":	
				

			if (rows < 2) {	
				rows++;
				
				Rectangle rect = this.getBounds();
				rect.setSize((int) rect.getWidth(), (int) rect.getHeight() + 25);
				setBounds(rect);

				JLabel lblFieldToSearch = new JLabel("Field to Search:");
				lblFieldToSearch.setHorizontalAlignment(SwingConstants.LEFT);
				lblFieldToSearch.setBounds(10, 11, 102, 14);
				GridBagConstraints gbc_lblFieldToSearch = new GridBagConstraints();
				gbc_lblFieldToSearch.fill = GridBagConstraints.BOTH;
				gbc_lblFieldToSearch.insets = new Insets(0, 0, 0, 5);
				gbc_lblFieldToSearch.gridx = 0;
				gbc_lblFieldToSearch.gridy = rows;
				mainPanel.add(lblFieldToSearch, gbc_lblFieldToSearch);
				comboLabels.add(lblFieldToSearch);
				
				JComboBox<String> comboBox = new JComboBox<String>();
				comboBox.setToolTipText("Select the field to perform the filter on.");
				comboBox.setModel(new DefaultComboBoxModel<String>(new String[] { "Environment\t", "Payfone Environment",
						"Feature Name", "Sceanrio Name", "Content Type" }));
				comboBox.setBounds(110, 8, 137, 20);
				GridBagConstraints gbc_comboBox = new GridBagConstraints();
				gbc_comboBox.fill = GridBagConstraints.BOTH;
				gbc_comboBox.insets = new Insets(0, 0, 0, 5);
				gbc_comboBox.gridx = 1;
				gbc_comboBox.gridy = rows;
				mainPanel.add(comboBox, gbc_comboBox);
				combos.add(comboBox);
				
				JLabel lblSearchTerm = new JLabel("Search Term:");
				lblSearchTerm.setBounds(281, 11, 84, 14);
				GridBagConstraints gbc_lblSearchTerm = new GridBagConstraints();
				gbc_lblSearchTerm.fill = GridBagConstraints.BOTH;
				gbc_lblSearchTerm.insets = new Insets(0, 0, 0, 5);
				gbc_lblSearchTerm.gridx = 2;
				gbc_lblSearchTerm.gridy = rows;
				mainPanel.add(lblSearchTerm, gbc_lblSearchTerm);
				textLabels.add(lblSearchTerm);
				
				JTextField textField = new JTextField();
				textField.setToolTipText("Enter the term or regular expression to find.");
				textField.setBounds(375, 8, 435, 20);
				GridBagConstraints gbc_textField = new GridBagConstraints();
				gbc_textField.fill = GridBagConstraints.BOTH;
				gbc_textField.gridx = 3;
				gbc_textField.gridy = rows;
				mainPanel.add(textField, gbc_textField);
				textFields.add(textField);
				
				mainPanel.revalidate();
				mainPanel.repaint();
			} else {
				String msg = "You cannot add any more filters!";
				JOptionPane.showMessageDialog(null,  msg);
			}
			break;
			case "Apply":
				index = this.comboBox.getSelectedIndex();
				searchFor = this.textField.getText();
				ArrayList<Integer> fields = new ArrayList<Integer>();
				fields.add(index);
				ArrayList<String> values = new ArrayList<String>();
				values.add(searchFor);
				
				for (JComboBox<String> box : combos) {
					fields.add(box.getSelectedIndex());
				}
				
				for (JTextField field : textFields) {
					values.add(field.getText());
					
				}
				doApply(fields, values);
				break;
			case "Cancel":	
				
				break;
			case "Remove Filter":		
				rows--;
							
				if (rows >= 0) {
					Rectangle rect = this.getBounds();
					rect.setSize((int) rect.getWidth(), (int) rect.getHeight() - 25);
					setBounds(rect);
		
					JLabel lblFieldToSearch = comboLabels.get(rows);
					mainPanel.remove(lblFieldToSearch);
					comboLabels.remove(rows);
					
					JComboBox<String> combo = combos.get(rows);
					mainPanel.remove(combo);
					combos.remove(rows);
					
					JLabel label = textLabels.get(rows);
					mainPanel.remove(label);
					textLabels.remove(rows);
					
					JTextField field = textFields.get(rows);
					mainPanel.remove(field);
					textFields.remove(rows);
					
					
					mainPanel.revalidate();
					mainPanel.repaint();
				} else {
					String msg = "You cannot remove the main filter. Close the filter dialog!";
					JOptionPane.showMessageDialog(null,  msg);
				}

				break;
		}
		
	}
	
	/**
	 * A method that creates one or more RowFilters and adds them to the table model
	 * @param index A list of index numbers for the field to filter on.
	 * @param searchFor A list of search terms to filter on.
	 */
	private void doApply(ArrayList<Integer> index, ArrayList<String> searchFor) {
		RowFilter<Object, Object> filter;
		List<RowFilter<Object, Object>> filters = new ArrayList<RowFilter<Object, Object>>();
		
		for (int i = 0; i < index.size(); i++) {
			int myIndex = i;
			filter = new RowFilter<Object, Object>() {
				public boolean include(Entry entry) {
					String population = entry.getStringValue(index.get(myIndex));
					return population.equals(searchFor.get(myIndex));
				}
			};
			filters.add(filter);
		}
		filter = RowFilter.andFilter(filters);
		
		TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(application.table.getModel());
		sorter.setRowFilter(filter);
		application.table.setRowSorter(sorter);
		
		application.isFiltered = true;
		application.eventHandler.setFileMenuItems(false, false, true, false, true);
		application.eventHandler.setEditMenuItems(true,  true,  true);
		application.eventHandler.setSearchMenuItems(false, false, true);
		this.dispose();
	}

	@Override
	public void windowOpened(WindowEvent e) {
		// Not implemented
		
	}

	@Override
	public void windowClosing(WindowEvent e) {
		application.eventHandler.setSearchMenuItems(true, true, false);
		
	}

	@Override
	public void windowClosed(WindowEvent e) {
		// not implemented
		
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// Not implemented
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// Not implemented
		
	}

	@Override
	public void windowActivated(WindowEvent e) {
		// Not implemented
		
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// Not implemented
		
	}
}
