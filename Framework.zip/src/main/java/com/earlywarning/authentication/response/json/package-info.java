/**
 * 
 */
/**
 * Contains classes that represent objects in an Authentify JSON Response. This package only contains classes that
 * are different from their counterpart in the request.
 * 
 * @author cornettl
 *
 */
package com.earlywarning.authentication.response.json;