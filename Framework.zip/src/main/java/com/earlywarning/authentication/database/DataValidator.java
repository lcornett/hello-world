/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import com.earlywarning.authentication.common.ApiDriver;
import com.earlywarning.authentication.common.StoredParams;
import com.earlywarning.authentication.startup.Env;
import com.earlywarning.authentication.xml.XmlResponseValidator;
import lombok.extern.log4j.Log4j2;
import org.mockito.MockingDetails;
import org.mockito.Mockito;

import javax.swing.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * A class that validates that the expected values match the actual values from the database 
 * for named fields. Some of these fields are contained in the Request message, some are 
 * contained in the Response message, some are just expected and won't be found in either of 
 * the messages.
 * @author cornettl
 *
 */
@Log4j2
public class DataValidator {
	static boolean result;
	static ResultSetCreator creator;
    static boolean saveCode = true;


	/**
	 * Gets a dataset from the database and compares the expected values to the actual values in
	 * the dataset.
	 * @param map The expected values.
	 * @return true if all of the values are validated, false otherwise
	 */
	public static boolean validateData(Map<String, String> map) {
		Set<String> keys = map.keySet();
		ArrayList<TableRecord> dataSet = getDataSet(); 
		ArrayList<TableRecord> reducedSet;
		result = true;
		String regex = "get[A-Za-z\\(\\)\\.]+";
		String expected = null;
        String regex2 = "getStoredParam";
        String regex3 = "getDemoNumber";
        String className = null;
        String value = "";
        String teid = "";

		try {
			for (String key : keys) {
				switch (key) {
					case "Action":
						className = "SessionInfoRecord";
						reducedSet = getReducedSet(dataSet, className);
						validateValue(key, map.get(key), reducedSet);
						break;
					case "asID":
						className = "SessionInfoSoRecord";
						reducedSet = getReducedSet(dataSet, className);
						validateValue(key, map.get(key), reducedSet);
						break;
					case "HashPhone":
						className = "SessionResourcesRecord";
						reducedSet = getReducedSet(dataSet, className);
						if (map.get(key).matches(regex)) {
							expected = getEwDeviceId();
						} else {
							expected = map.get(key);
						}
						validateValue(key, expected, reducedSet);
						break;
					case "phoneNumber":
						className = "SessionInfoSoRecord";
						reducedSet = getReducedSet(dataSet, className);
						String phoneNumber = null;
						if (map.get(key).matches(regex)) {
                            if (map.get(key).matches(regex2)) {
                                phoneNumber = StoredParams.retrieve("phoneNumber");
                            }
                            else if (map.get(key).matches(regex3)) {
                                phoneNumber = StoredParams.retrieve("demoNumber");
                            } else {
                                phoneNumber = getProperty(map.get(key));
                            }
						}

                        else {
							phoneNumber = map.get(key);
						}
						validateValue(key, phoneNumber, reducedSet);
						break;
					case "resourceID":
						className = "SessionResourcesRecord";
						reducedSet = getReducedSet(dataSet, className);
						validateValue(key, map.get(key), reducedSet);
						break;
                    case "Duration":
                        className = "SessionResourcesRecord";
                        reducedSet = getReducedSet(dataSet, className);
                        validateValue(key, map.get(key), reducedSet);
                        break;
					case "State":
						className = "SessionInfoRecord";
						reducedSet = getReducedSet(dataSet, className);
						validateValue(key, map.get(key), reducedSet);
						break;
					case "Status":
						className = "SessionInfoRecord";
						reducedSet = getReducedSet(dataSet, className);
						validateValue(key, map.get(key), reducedSet);
						break;
					case "sessionresources.Status":
						String localKey = "Status";
						className = "SessionResourcesRecord";
						reducedSet = getReducedSet(dataSet, className);
						validateValue(localKey, map.get(key), reducedSet);
						break;
					case "SubType":
						className = "SessionResourcesRecord";
						reducedSet = getReducedSet(dataSet, className);
						validateValue(key, map.get(key), reducedSet);
						break;
					case "vendorlink.phoneNumber":
						className = "VendorLinkRecord";
						reducedSet = getReducedSet(dataSet, className);
						validateValue(key, map.get(key), reducedSet);
						break;
                    case "AplicationId":
                        className = "ApplicationId";
                        reducedSet = getReducedSet(dataSet, className);
                        validateValue(key, map.get(key), reducedSet);
                        break;
                    case "typeID":
                        className = "SessionResourcesRecord";
                        reducedSet = getReducedSet(dataSet, className);
                        validateValue(key, map.get(key), reducedSet);
                        break;
                    case "Registrar":
                        className = "SessionResourcesRecord";
                        reducedSet = getReducedSet(dataSet, className);
                        validateValue(key, map.get(key), reducedSet);
                        break;
                    case "fileName":
                        className = "SessionFilesRecord";
                        reducedSet = getReducedSet(dataSet, className);
                        value = map.get(key);
                        teid = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//teid/text()");
                        if(value.contains("<teid>")){
                            value = value.replace("<teid>",teid);
                        }
                        validateValue(key, value, reducedSet);
                        break;
                    case "location":
                        className = "SessionFilesRecord";
                        reducedSet = getReducedSet(dataSet, className);
                        validateValue(key, map.get(key), reducedSet);
                        break;
                    case "tag":
                        className = "SessionGroupDataRecord";
                        reducedSet = getReducedSet(dataSet, className);
                        validateValue(key, map.get(key), reducedSet);
                        break;
                    case "value":
                        className = "SessionGroupDataRecord";
                        reducedSet = getReducedSet(dataSet, className);
                        value = map.get(key);
                        teid = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//teid/text()");
                        if(value.contains("getTeidValue")){
                            value = value.replace("getTeidValue",teid);
                        }
                        if(value.contains("getPinFromUser")){
                            String input = JOptionPane.showInputDialog("Please enter the pin number for Call#1");
                            value = value.replace("getPinFromUser",input);
                        }

                        validateValue(key, value, reducedSet);
                        break;

				default:
						String msg = "No such Key! " + key;
						log.info(msg);

					
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		return result;
	
	}
	
	/**
	 * Validates the values from the vendorLink table in the databasse against the expected values.
	 * @param map The name value paris of the expeccted values.
	 * @return true if the values match, false otherwise.
	 */
	public static boolean validateVendorLink(Map<String, String> map) {
		Set<String> keys = map.keySet();
		ArrayList<TableRecord> vendorLinkData = getVendorLinkData();
		ArrayList<TableRecord> reducedSet = null;
		result = true;
		String regex = "get[A-Za-z\\(\\)\\.]+";
		String expected = null;
		String className = "VendorLinkRecord";

		try {
			for (String key : keys) {
				switch (key) {
					case "AccountID":
						reducedSet = getReducedSet(vendorLinkData, className);
						validateValue(key, map.get(key), reducedSet);
						break;
					case "InternalGUID":
						reducedSet = getReducedSet(vendorLinkData, className);
						if (map.get(key).matches(regex)) {
							expected = getEwDeviceId();
						} else {
							expected = map.get(key);
						}
						validateValue(key, expected, reducedSet);
						break;
					case "ExternalGUID":
						reducedSet = getReducedSet(vendorLinkData, className);
						if (map.get(key).matches(regex)) {
							expected = getLegacyDeviceId();
						} else {
							expected = map.get(key);
						}
						validateValue(key, expected, reducedSet);
						break;
					case "phoneNumber":
						reducedSet = getReducedSet(vendorLinkData, className);
						if (map.get(key).matches(regex)) {
							expected = getPhoneNumber();
						} else {
							expected = map.get(key);
						}
						validateValue(key, expected, reducedSet);
						break;
					case "SOID":
						reducedSet = getReducedSet(vendorLinkData, className);
						validateValue(key, map.get(key), reducedSet);
						break;
					default:
						String msg = "The field requested " + key + " is not available!";
						updateResult(false);
						log.info(msg);
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		return result;

	}

    /**
     * Gets the response from ApiDriver
     * Retrieves the tag and value from the xml or json response, for the key passed in the argument
     * Calculates the length of the value string
     * @param key A path to an element.
     * @param len The expected length of a string.
     * @return true, if the length matches with the expected value passed as an argument, false otherwise
     * 
     * This is not a db related method
     */
    public static boolean validateValueLength(String key,Integer len ){
        boolean ret = false;
        String contentType = "";
        String value = "";
        try {
            contentType = ApiDriver.getResp().contentType();

            if (contentType.contains("json")) {
                value = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), key);
            } else if (contentType.contains("xml")) {
                String xmlKey = "//" + key + "/text()";
                value = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), xmlKey);
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            log.debug(e.getMessage(), e);
        }
        int length = value.length();

        if(length == len){
            ret = true;
        }

        return ret;
    }

    /**
     * Gets the response from ApiDriver
     * Retrieves the tag and value from the xml or json response, for the dynamic field passed as an argument
     * Validates the properties of the value retrieved
     * @param key A path to an element.
     * @return true, if the value is compliant with its properties, false otherwise
     *
     * This is not a db related method
     */
    public static boolean validateDynamicField(String key){
        boolean ret = false;
        String contentType = "";
        String value = "";
        
        try {
            contentType = ApiDriver.getResp().contentType();

            if (contentType.contains("json")) {
                value = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), key);
            } else if (contentType.contains("xml")) {
                String xmlKey = XmlResponseValidator.getXmlKey(key);
                value = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), xmlKey);
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            log.debug(e.getMessage(), e);
        }
        
        switch (key.toLowerCase()) {
	        case "replyto":	
		        String environment = Env.getProperty("environment");
		        String replyToString = Env.getProperty(environment + "ReplyTo");
		        String replyTo[] = replyToString.split(",");
		
		        for(int i =0;i<replyTo.length;i++) {
		            String content = replyTo[i];
		            if (value.contains(content)) {
		                log.info("The actual and expected value of " + key + " are the same.");
		            	ret = true;
		            } 
		        }
		        
		        if (!ret) {
		        	log.info("The actual value of " + key + " is " + value + "and does not equal the expected value.");
		        }
		        break;	
	        case "timestamp":
	        case "timestamprequest":
	        case "timestamplinealloc":
	        case "timestampconnect":
	        case "timestampiso8601":
	        	String regex = "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z";
				if (value.matches(regex)) {
					log.info("check for the current date in the " + key + ".");
					Date crrentDate = new Date();
					DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
					String dateString = df.format(crrentDate);
					log.info("The current date is " + dateString + ".");
					if (value.contains(dateString)) {
						log.info("The actual value and the expected value of the " + key + " are the same.");
						ret = true;
					} else {
						log.info("The actual value of " + key + " is " + value + ", does not match the expected value "
								+ dateString + ". ");
						ret = false;
					} 
				} else {
					log.info("The value of " + key + " is not in the ISO8601 format!");
					ret = false;
				}
				break;
	        default:	
	        	log.info("The key " + key + " does not exist!");
	        	ret = false;
	        	break;
        }

        return ret;
    }

	/**
	 * A method to compare the expected and the actual value of a database field. The result of the comparison is logged.
	 * The overall result of the data validation is updated.
	 * @param key The name of the field that is being compared.
	 * @param expected The expected value of the field being compared.
	 * @param set The database record being compared.
	 */
	private static void validateValue(String key, String expected, ArrayList<TableRecord> set) {
		String[] expectedValues = expected.split(";"); //; is used as separator to validate values in different rows of the db
		boolean found = false;
		String className;
		RecordProcessor processor = new RecordProcessor();
		String actual = "";
		String cumulativeActual = "";
		String msg = null;
		ArrayList<TableRecord> temp = new ArrayList<TableRecord>();
		
		temp.addAll(set);
		if (expectedValues.length == set.size()) {
			for (String value : expectedValues) {
				
				try {
					for (TableRecord record : temp) {
						className = record.getClass().getSimpleName();

						switch (className) {
							case "SessionDataRecord":
								actual = checkForNull(processor.processSessionData((SessionDataRecord) record, key));
								
								if (value.equals(actual)) {
									found = true;
									temp.remove(record);
								} else {
									found = false;
								}
								break;
							case "SessionFilesRecord":
								actual = checkForNull(processor.processSesionFiles((SessionFilesRecord) record, key));
								
								if (value.equals(actual)) {
									found = true;
									temp.remove(record);
								} else {
									found = false;
								}

								break;
							case "SessionGroupDataRecord":
								actual = checkForNull(processor.processGroupData((SessionGroupDataRecord) record, key));
								
								if (value.equals(actual)) {
									found = true;
									temp.remove(record);
								} else {
									found = false;
								}
	
								break;
							case "SessionInfoRecord":
								actual = checkForNull(processor.processSessionInfo((SessionInfoRecord) record, key));
								
								if (value.equals(actual)) {
									found = true;
									temp.remove(record);
								} else {
									found = false;
								}
	
								break;
							case "SessionInfoSoRecord":
								actual = checkForNull(processor.processSessionInfoSo((SessionInfoSoRecord) record, key));
								
								if (value.equals(actual)) {
									found = true;
									temp.remove(record);
								} else {
									found = false;
								}	
								break;
							case "SessionResourcesRecord":
								actual = checkForNull(processor.processSessionResources((SessionResourcesRecord) record, key));
                                String[] valueArray = value.split(":");//: is used as separator to validate various possible values for the same row in the db

                                for(String eachValue : valueArray) {
                                    if (eachValue.equals(actual)) {
                                        found = true;
                                        temp.remove(record);
                                        break;
                                    } else {
                                        found = false;
                                    }
                                }
								break;
							case "VendorLinkRecord":
								actual = checkForNull(processor.processVendorLink((VendorLinkRecord) record, key));
								
								if (value.equals(actual)) {
									found = true;
									temp.remove(record);
								} else {
									found = false;
								}	
								break;
                            case "ResponsiveWebRecord":
                                actual = checkForNull(processor.processResponsiveWeb((ResponsiveWebRecord) record, key));

                               if(key.equals("Code")){
                                   if(saveCode){
                                       StoredParams.store(key, actual);
                                       saveCode=false;
                                   }
                               }

                                if(value.equals("notEmpty")){
                                    if(actual.equals("")){
                                        found = false;
                                    }else{
                                        found = true;
                                        temp.remove(record);
                                    }
                                }else if (value.equals(actual)) {
                                    found = true;
                                    temp.remove(record);
                                } else {
                                    found = false;
                                }
                                break;
						}
					}
					if (cumulativeActual.isEmpty()) {
						cumulativeActual = actual;
					} else {
						cumulativeActual += "," + actual;
					}

				} catch (Exception e) {
					msg = "This exception happened because an empty ArrayList was encountered during processing.\n This is expected and not a problem.";
					log.debug(msg);
				}
			}
			
			if (!found) {
				msg = "The actual value for key " + key + " is " + cumulativeActual + " and does not equal the expected value " + expected + ".";
				log.info(msg);
			} else {
				msg = "The actual and expected value for the key " + key + " are the same.";
				log.info(msg);
			}
			updateResult(found);
		} else {
			msg = "The number of expected values " + expectedValues.length + " does not correspond with the actual values " + set.size() + "!";
			log.error(msg);
			result = false;
		}
		return;
	}

	/**
	 * The method that updates the overall result of the data validation.
	 * @param status The result of a single comparison
	 */
	private static void updateResult(boolean status) {
		if (result == true && status == false) {
			result = false;
		}

	}
	
	/**
	 * A method to get the dataset of actual values from the database
	 * @return
	 */
	private static ArrayList<TableRecord> getDataSet() {
		final String keyName = "ewSID";
		String ewSid = "";
		String contentType = "";
		
		try {
			contentType = ApiDriver.getResp().contentType();
			
			if (contentType.contains("json")) {
				ewSid = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), keyName);
			} else if (contentType.contains("xml")) {
				ewSid = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), "//teid/text()");
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		log.info("The ewSID is " + ewSid);
		MockingDetails details = Mockito.mockingDetails(creator);
		if (!details.isMock()) {
			creator = new ResultSetCreator(ewSid);
		}
		
		return creator.getResultSet();
	}
	
	/**
	 * Retrieves a value from the environment.properties file
	 * @return The value of the requested property.
	 */
	private static String getProperty(String key) {
		String result = null;
		
		if (key.contains("get(")) {
			result = getResponseElement(key);
		} else {
			String env = Env.getProperty("payfoneEnvironment");
			result = Env.getProperty(env + key.substring(3)).replaceAll("-", "");
		}
		
		return result;
	}
	
	/**
	 * A methodd to create a new ResultSetCreator if the current ResultSetCreator 
	 * is not mocked. Then the dataset is returned for the vendorLink table.
	 * @return The vendorLink result Set
	 */
	private static ArrayList<TableRecord> getVendorLinkData() {		
		MockingDetails details = Mockito.mockingDetails(creator);
		if (!details.isMock()) {
			creator = new ResultSetCreator();
		}
			
		return creator.getVendorLinkData();		
	}
	
	/**
	 * A method to get the ewDeviceId from the current response
	 * @return The latest response's ewDeviceId
	 */
	static String getEwDeviceId() {
		String jsonKey = "data.ewDeviceId";
		String xmlKey = "//ewDeviceId/text()";
		String key = "get(";
		String contentType = null;
		
		contentType = ApiDriver.getResp().contentType();
		
		if (contentType.contains("json")) {
			key += jsonKey + ")";
		} else if (contentType.contains("xml")) {
			key += xmlKey + ")";
		}
		return getResponseElement(key);
	}

	/**
	 * A method to get the legacydeviceid from the latest response
	 * @return The legacyDevceID from the latest response
	 */
	static String getLegacyDeviceId() {
		String jsonKey = "data.legacyDeviceId";
		String xmlKey = "//legacyDeviceId/text()";
		String key = "get(";
		String contentType = null;
		
		contentType = ApiDriver.getResp().contentType();
		
		if (contentType.contains("json")) {
			key += jsonKey + ")";
		} else if (contentType.contains("xml")) {
			key += xmlKey + ")";
		}
		return getResponseElement(key);
	}
	
	/**
	 * A method to get the value of the phoneNumber element from the latest response.
	 * @return The value of the phone number element from the latest response.
	 */
	static String getPhoneNumber() {
		String jsonKey = "data.phoneNumber";
		String xmlKey = "//phoneNumber/text()";
		String key = "get(";
		String contentType = null;
		
		contentType = ApiDriver.getResp().contentType();
		if (contentType.contains("json")) {
			key += jsonKey + ")";
		} else if (contentType.contains("xml")) {
			key += xmlKey + ")";
		}
		return getResponseElement(key);
	}
	
	/**
	 * A method that processes the dataset returned from the database to return a subset 
	 * of rows from one table. That way we don't have to look through rows that don't have 
	 * the column of interest.
	 * @param fullSet The set of database records returned by the ResultSetCreator.
	 * @param className The simple class name of the desired table rows.
	 * @return The set of records that match the className.
	 */
	static ArrayList<TableRecord> getReducedSet(ArrayList<TableRecord> fullSet, String className) {
		ArrayList<TableRecord> result;
		
		result = (ArrayList<TableRecord>) fullSet.stream()
			.filter(record -> record.getClass().getSimpleName().equals(className))
			.collect(Collectors.toList());
		return result;
	}
	
	/**
	 * A method that returns an empty string if the argument passed is null. If the argument passed
	 * in is not null, that argument is returned.
	 * @param valueToCheck The string to check for null.
	 * @return The empty of original string.
	 */
	private static String checkForNull(String valueToCheck) {
		return valueToCheck == null ? "" : valueToCheck;
	}

    /**
     * A method that returns an empty string if the argument passed is null. If the argument passed
     * in is not null, that argument is returned. It is public in order to access outside of the class.
     * @param valueToCheck The string to check for null.
     * @return The empty of original string.
     */
    public static String checkNull(String valueToCheck) {
        return valueToCheck == null ? "" : valueToCheck;
    }
	
	/**
	 * A method that gets an element's value from a response. The element to get is wrapped in
	 * the string get(&lt;element&gt;) which needs to be stripped off. The full path for the element 
	 * is required for this to work.
	 * @param key The path of the element to get the value of.
	 * @return The value of the element.
	 */
	static String getResponseElement(String key) {
		String value = null;
		String contentType = null;
		String realKey = key.substring(4, key.length() - 1);
		contentType = ApiDriver.getResp().contentType();
		if (contentType.contains("xml")) {
			value = ApiDriver.retrieveXMLvaluefromTag(ApiDriver.getResp(), realKey);
		} else if (contentType.equals("application/json")) {
			value = ApiDriver.retrieveJsonValueString(ApiDriver.getResp(), realKey);
		}
		return value;
	}

    /**
     * Validates the values from the ResponsiveWeb table in the database against the expected values.
     * @param map The name value paris of the expeccted values.
     * @return true if the values match, false otherwise.
     */
    public static boolean validateResponsiveWebData(Map<String, String> map){
        Set<String> keys = map.keySet();
        ArrayList<TableRecord> responsiveData = getResponsiveData();
        ArrayList<TableRecord> reducedSet = null;
        result = true;
        String className = "ResponsiveWebRecord";

        try{

            for(String key: keys){
                switch (key){
                    case "Name":
                        reducedSet = getReducedSet(responsiveData, className);
                        validateValue(key, map.get(key), reducedSet);
                        break;
                    case "Status":
                        reducedSet = getReducedSet(responsiveData, className);
                        validateValue(key, map.get(key), reducedSet);
                        break;
                    case "Code":
                        reducedSet = getReducedSet(responsiveData, className);
                        validateValue(key, map.get(key), reducedSet);
                        break;
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage());
            log.debug(e.getMessage(), e);
        }

        return result;

    }

    /**
     * A methodd to create a new ResultSetCreator if the current ResultSetCreator
     * is not mocked. Then the dataset is returned for the vendorLink table.
     * @return The ResponsiveWeb result Set
     */
    public static ArrayList<TableRecord> getResponsiveData() {
        MockingDetails details = Mockito.mockingDetails(creator);
        if (!details.isMock()) {
            creator = new ResultSetCreator();
        }

        return creator.getResponsiveData();
    }
}
