/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import lombok.Data;

/**
 * A POJO that represents a row of the result set from the query on the SessionInfo table.
 * This class utilizes the lombok.Data annotation for the implementation of the getters 
 * and setters of the following class properties:<ul>
 * 	<li>state</li>
 * 	<li>status</li>
 * 	<li>action</li>
 * 	<li>accountId</li></ul>
 * @author cornettl
 *
 */
@Data
public class SessionInfoRecord implements TableRecord {
	private String state, status, action, accountId;
}
