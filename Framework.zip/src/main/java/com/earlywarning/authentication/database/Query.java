/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

/**
 * An enum that holds the database queries that get executed for the database validation of the test cases.
 * Currently, element is a string array of 6 queries. If not all queries are used, the remaining elements are
 * empty strings.
 * @author cornettl
 *
 */
public enum Query {
	/**
	 * The first element. This element contains 6 querries
	 */
	QUERY1 ("select state, status, action, accountId from sessioninfo where sessionid = ?",
			  "select * from sessioninfoso where sessionid = ?", 
			  "select resourceid, status, hashphone, subtype, typeid, registrar, duration from sessionresources where sessionid = ?",
			  "select * from sessionfiles where sessionid = ?",
			  "select * from sessiondata where sessionid = ?",
			  "select * from sessiongroupdata where sgid = ?"),
	/**
	 * The third element. This element contains 1 query.
	 */
	PAYFONE3 ("select * from [register01].[dbo].[vendorlink] where externalguid = ?", "", "", "", "", "");
	
	/** 
	 * The constructor for the class.
	 * @param statement1 The first query
	 * @param statement2 The second query
	 * @param statement3 The third query
	 * @param statement4 The fourth query
	 * @param statement5 The fifth query
	 */
	Query(String statement1, String statement2, String statement3, String statement4, String statement5, String statement6) {
		this.statement1 = statement1;
		this.statement2 = statement2;
		this.statement3 = statement3;
		this.statement4 = statement4;
		this.statement5 = statement5;
		this.statement6 = statement6;
	}
	
	private final String statement1;
	private final String statement2;
	private final String statement3;
	private final String statement4;
	private final String statement5;
	private final String statement6;
	
	/**
	 * A method that gets the non empty queries and returns them as a String array.
	 * @return Array of query strings
	 */
	public String[] getStatements() {
		String[] statements = new String[getCount()]; 
		int count = 0;
		
		if (!getStatement1().isEmpty()) 
			statements[count++] = getStatement1();
		if (!getStatement2().isEmpty()) 
			statements[count++] = getStatement2();
		if (!getStatement3().isEmpty()) 
			statements[count++] = getStatement3();
		if (!getStatement4().isEmpty()) 
			statements[count++] = getStatement4();
		if (!getStatement5().isEmpty()) 
			statements[count++] = getStatement5();
		if (!getStatement6().isEmpty()) 
			statements[count++] = getStatement6();
		return statements;			
	}
		

	/**
	 * A rpivate method that counts the number of non empty queries in an element.
	 * @return The number of non-empty querries
	 */
	private int getCount() {
		int valid = 0;
		
		if (!getStatement1().isEmpty())
			valid++;
		if (!getStatement2().isEmpty())
			valid++;
		if (!getStatement3().isEmpty())
			valid++;
		if (!getStatement4().isEmpty())
			valid++;
		if (!getStatement5().isEmpty())
			valid++;
		if (!getStatement6().isEmpty())
			valid++;
		
		return valid;
	}
	private String getStatement1() {
		return statement1;
	}
	
	private String getStatement2() {
		return statement2;
	}
	
	private String getStatement3() {
		return statement3;
	}
	
	private String getStatement4() {
		return statement4;
	}
	
	private String getStatement5() {
		return statement5;
	}
	
	private String getStatement6() {
		return statement6;
	}
}
