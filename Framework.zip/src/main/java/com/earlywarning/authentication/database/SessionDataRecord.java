/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.database;

import lombok.Data;

/**
 * A POJO that represents a row of the query on the SessionData table. 
 * This class uses the lombok.Data annotation to implement the getters
 * and setters for the following class properties:<ul>
 * 	<li>tag</li>
 * 	<li>value</li>
 * 	<li>timestamp</li>
 * 	<li>sessionId</li></ul>
 * @author cornettl
 *
 */
@Data
public class SessionDataRecord implements TableRecord {
	private String tag, value, timestamp, sessionId;
}
