/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.xmlcompare;

import com.earlywarning.authentication.jsoncompare.StringComparator;
import com.earlywarning.authentication.xml.XmlLastChangeEvents;
import com.earlywarning.authentication.xml.XmlResponseDataLookup;

/**
 * A class for comparing the elements of the XmlDataLookup element of two
 * AuthentXML response messages.
 * @author cornettl
 *
 */
class XmlDataLookupComparator extends StringComparator {

	/**
	 * The method that performs the comparison of the child elements of the XmlDataLookup element. Only
	 * the elements that can be expected to be the same are compared.
	 * @param expected The element to compare to.
	 * @param actual The element to compare.
	 * @return true if the elements match, false otherwise
	 */
	public boolean compare(XmlResponseDataLookup expected, XmlResponseDataLookup actual) {
		String expectedValue = null;
		String actualValue = null;
		String[] keys = {"lastChangeEvents", "mobileIdentityCreated", "mobileOperatorName", "statusIndex"};
		
		for (String key : keys) {
			switch (key) {
				case "lastChangeEvents":
					XmlLastChangeEvents expectedEvents = expected.getLastChangeEvents();
					XmlLastChangeEvents actualEvents = actual.getLastChangeEvents();
					XmlLastChangeEventsComparator comparator = new XmlLastChangeEventsComparator();
					updateStatus(comparator.compare(expectedEvents, actualEvents));
					break;
				case "mobileIdentityCreated":
					expectedValue = expected.getMobileIdentityCreated();
					actualValue = actual.getMobileIdentityCreated();
					updateStatus(compareString(key, expectedValue, actualValue));
					break;
				case "mobileOperatorName":
					expectedValue = expected.getMobileOperatorName();
					actualValue = actual.getMobileOperatorName();
					updateStatus(compareString(key, expectedValue, actualValue));
					break;
				case "statusIndex":
					expectedValue = expected.getStatusIndex();
					actualValue = actual.getStatusIndex();
					updateStatus(compareString(key, expectedValue, actualValue));
					break;
			}
		}
		return status;
	}
}
