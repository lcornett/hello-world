/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.xmlcompare;

import com.earlywarning.authentication.jsoncompare.StringComparator;
import com.earlywarning.authentication.xml.XmlEventType;
import com.earlywarning.authentication.xml.XmlLastChangeEvents;

/**
 * A class for comparing the XmlLastChangeEvents element of two AuthentXML response messages.
 * @author cornettl
 *
 */
class XmlLastChangeEventsComparator extends StringComparator {

	/**
	 * The method to compare the XmlLastChangeEvents element.
	 * @param expected The value to compare to.
	 * @param actual The value to compare.
	 * @return true if the elements match, false otherwise
	 */
	public boolean compare(XmlLastChangeEvents expected, XmlLastChangeEvents actual) {
		XmlEventType[] expectedEventType = expected.getEventType();
		XmlEventType[] actualEventType = actual.getEventType();
		
		XmlEventTypeComparator comparator = new XmlEventTypeComparator();
		updateStatus(comparator.compare(expectedEventType, actualEventType));
		
		return status;
	}
}
