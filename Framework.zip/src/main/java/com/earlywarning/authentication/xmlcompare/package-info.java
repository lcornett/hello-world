/**
 * 
 */
/**
 * A package containing the classes that compare the elements of the AuthentXMLResponse class.
 * @author cornettl
 *
 */
package com.earlywarning.authentication.xmlcompare;