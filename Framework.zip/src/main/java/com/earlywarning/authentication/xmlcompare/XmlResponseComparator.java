/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.xmlcompare;

import com.earlywarning.authentication.jsoncompare.StringComparator;
import com.earlywarning.authentication.xml.AuthentXmlResponse;
import com.earlywarning.authentication.xml.ResponseBody;
import com.earlywarning.authentication.xml.ResponseHeader;

/**
 * A class that compares the elements of an AuthentXML response message.
 * @author cornettl
 *
 */
public class XmlResponseComparator extends StringComparator {
	
	/**
	 * A method that performs the comparison of two instances of the AuthentXMLResponse class.
	 * @param expected The response to compare to.
	 * @param actual The response to compare.
	 * @return true if the responses match, false otherwise.
	 */
	public boolean compareResponse(AuthentXmlResponse expected, AuthentXmlResponse actual) {
		String[] keys = {"header", "body", };
		
		try {			
			for (String key : keys) {
				switch (key) {
					case "body":
						XmlBodyComparator bodyComparator = new XmlBodyComparator();
						ResponseBody expectedBody = expected.getBody();
						ResponseBody actualBody = actual.getBody();
						updateStatus(bodyComparator.compare(expectedBody, actualBody));
						break;
					case "header":
						XmlHeaderComparator headerComparator = new XmlHeaderComparator();
						ResponseHeader expectedHeader = expected.getHeader();
						ResponseHeader actualHeader = actual.getHeader();
						updateStatus(headerComparator.compare(expectedHeader, actualHeader));
						break;

				}
			}
		return status;
		} finally {
			
		}
	}
}
