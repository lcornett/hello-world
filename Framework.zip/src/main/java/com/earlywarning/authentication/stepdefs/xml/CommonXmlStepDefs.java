/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.stepdefs.xml;

import java.util.Map;

import com.earlywarning.authentication.xml.AuthentXML;
import com.earlywarning.authentication.xml.XmlRequestCreator;

import cucumber.api.DataTable;
import cucumber.api.java8.En;

/**
 * <p>A Cucumber step definition class using Java 8 lambdas. These step definitions
 * act on messages (requests and responses) that are defined in the com.earlywarning.authentication.xml
 * package. It is the XML version of the CommonStepDefs class which was designed to handle JSON messages.
 * Because this class is the XML version of the CommonStepDefs class and is for XML is how this class got 
 * it's name. The step definitions included in this class are described below.</p>
 * 
 * @author cornettl
 *
 */
public class CommonXmlStepDefs implements En {
	private static AuthentXML request;
	
	public CommonXmlStepDefs() {
		Given("^the Authentify request has the values$", (DataTable data) -> {
			Map<String, String> map = data.asMap(String.class, String.class);
			request = XmlRequestCreator.createRequest(map);
		});

	
	}
}
