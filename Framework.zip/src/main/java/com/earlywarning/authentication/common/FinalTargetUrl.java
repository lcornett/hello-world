/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/**
 * A POJO that represents the FinalTargetUrl element of the Authentify
 * JSON request message. This class utilizes the lombok Data and the 
 * jackson JsonInclude annotations. The Data annotation implements the
 * setter and getter for the private property:<ul><li>value</li></ul>
 * Please see the 
 * <a href="{@docRoot}/com/earlywarning/authentication/common/package-summary.html#tags"> package-info</a>
 * page for additional information about the annotations.
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_EMPTY)
public class FinalTargetUrl {
	private String value;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	
}
