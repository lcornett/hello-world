/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * A POJO that represents the dataLookup json element of an Authentify request
 * message.
 * This class utilizes the lombok Data and the jackson JsonInclude annotations.
 * The Data annotation provides setters and getters for the following private properties:<ul>
 * 	<li>finalTargetUrl</li>
 * 	<li>mobileNetworkOperator</li>
 * 	<li>deviceIp</li>
 * 	<li>consentCollectedDate</li>
 * 	<li>consentDescription</li>
 * 	<li>consentTransactionId</li>
 * 	<li>lastVerificationDate</li>
 * 	<li>vfp</li>
 * 	<li>enterprisePhoneNumber</li>
 * 	<li>callArrivalTime</li>
 * 	<li>email</li>
 * 	<li>address</li></ul>
 * For more information about these annotations please see the
 * <a href="{@docRoot}/com/earlywarning/authentication/common/package-summary.html#tags">package-info</a> page.
 * 
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_EMPTY)
public class DataLookup {
	@JsonProperty("FinalTargetUrl")
	private FinalTargetUrl finalTargetUrl;
	private String mobileNetworkOperator;
	private String deviceIp;
	private String consentCollectedDate;
	private String consentTransactionId;
	private String consentDescription;
	private String lastVerificationDate;
	private Vfp vfp;
	private String enterprisePhoneNumber;
	private String callArrivalTime;
	private String email;
	private Name name;
	private Address address;
	
	

}
