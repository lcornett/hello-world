/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.utils;

import java.lang.reflect.Modifier;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.fasterxml.jackson.databind.introspect.AnnotatedField;
import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;

/**
 * Class that defines how names of JSON properties ("external names") are derived from names of POJO 
 * methods and fields ("internal names"), in cases where they are not auto-detected and no explicit 
 * annotations exist for naming. Methods are passed information about POJO member for which name is 
 * needed, as well as default name that would be used if no custom strategy was used. 
 * Default (empty) implementation returns suggested ("default") name unmodified. 
 * Note that the strategy is guaranteed to be called once per logical property (which may be represented 
 * by multiple members; such as pair of a getter and a setter), but may be called for each: implementations 
 * should not count on exact number of times, and should work for any member that represent a property. 
 * In absence of a registered custom strategy, default Java property naming strategy is used, which leaves 
 * field names as is, and removes set/get/is prefix from methods (as well as lower-cases initial sequence 
 * of capitalized characters).

 * @author cornettl
 *
 */
public class CustomPropertyNamingStrategy extends PropertyNamingStrategy {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
    public String nameForField(MapperConfig<?> config, AnnotatedField field, String defaultName) {
        return convertForField(defaultName);
    }

    @Override
    public String nameForGetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName) {
        return convertForMethod(method, defaultName);
    }

    @Override
    public String nameForSetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName) {
        return convertForMethod(method, defaultName);
    }

    private String convertForField(String defaultName) {
        return defaultName;
    }

    private String convertForMethod(AnnotatedMethod method, String defaultName) {
        if (isGetter(method)) {
            return method.getName().substring(3);
        }
        if (isSetter(method)) {
            return method.getName().substring(3);
        }
        return defaultName;
    }

    @SuppressWarnings("deprecation")
	private boolean isGetter(AnnotatedMethod method) {
        if (Modifier.isPublic(method.getModifiers()) && method.getGenericParameterTypes().length == 0) {
            if (method.getName().matches("^get[A-Z].*") && !method.getGenericType().equals(void.class))
                return true;
            if (method.getName().matches("^is[A-Z].*") && method.getGenericType().equals(boolean.class))
                return true;
        }
        return false;
    }

    @SuppressWarnings("deprecation")
	private boolean isSetter(AnnotatedMethod method) {
        return Modifier.isPublic(method.getModifiers()) && method.getGenericType().equals(void.class) && method.getGenericParameterTypes().length == 1
                && method.getName().matches("^set[A-Z].*");
    }

}
