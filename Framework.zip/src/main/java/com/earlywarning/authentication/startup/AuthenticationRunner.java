/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.startup;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/**
 * This is a JUnit test class. The purpose of this class is to start the JUnit
 * runner. The @RunWith annotation tells JUnit which class is the startup class
 * to be executed. The @CcucumberOptions annotation is used to configure cucumber.
 * To find out all of the Cucumber configurations go to the 
 * <a href=https://cucumber.io/docs/reference/jvm#configuration>Cucumber web site</a>.
 *
 * @author cornettl
 *
 */
@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"html:../logs/authentication-test-log"},
							features = {"src/test/resources/features/"},
							glue = "com.earlywarning.authentication.stepdefs"
							, tags = "@tag14"
				)
public class AuthenticationRunner {

}
