/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.responses;

import java.util.Map;
import java.util.Set;

import com.earlywarning.authentication.common.ApiDriver;
import com.earlywarning.authentication.jsoncompare.StringComparator;

import io.restassured.response.Response;

/**
 * A class that gets the expected response and the actual response and compares the element values.
 * @author cornettl
 *
 */
public class ResultComparator extends StringComparator {
	
	/**
	 * A method that compares the elements of an expected response with an actual response.
	 * @param map Specifies which elements to compare.
	 * @return ture if the elements match, false otherwise.
	 */
	public boolean compare(Map<String, String> map) {
		String expectedType = null;
		String actualType = null;
		String expectedValue = null;
		String actualValue = null;
		Response actualResponse = ApiDriver.getResp();
		Set<String> keys = map.keySet();
		
		actualType = convertContentType(actualResponse.contentType());
		
		Response expectedResponse = new ExpectedResponseRetriever().retrieveExpectedResponse(actualType);		
		expectedType = expectedResponse.contentType();
		
		for (String key : keys) {
			if (expectedType.equals("text/xml")) {
				expectedValue = ApiDriver.retrieveXMLvaluefromTag(expectedResponse, key);
			} else if (expectedType.equals("application/json")) {
				expectedValue = ApiDriver.retrieveJsonValueString(expectedResponse, key);
			}
			
			if (actualType.contains("xml")) {
				actualValue = ApiDriver.retrieveXMLvaluefromTag(actualResponse, key);
			} else if (actualType.contains("json")) {
				actualValue = ApiDriver.retrieveJsonValueString(actualResponse, key);
			}
			
			updateStatus(compareString(key,actualValue, expectedValue));
			
		}
		
		return status;
	}
	
	/**
	 * A method that looks for xml in the contentType. If xml is found the value
	 * text/xml is returned.
	 * @param contentType The contentType to evaluate.
	 * @return A contentType
	 */
	private String convertContentType(String contentType) {
		
		if (contentType.contains("xml") || contentType.contains("XML")) {
			contentType = "text/xml";
		}
		
		return contentType;
	}
	

}
