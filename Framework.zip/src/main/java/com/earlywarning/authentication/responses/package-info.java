/**
 * 
 */
/**
 * Contains the classes that handle creating and verifying the expected responses for the test scenarios.
 * The Authentify QA department wanted a way to verify an actual response from a request is equal to an
 * expected response. To accomplish this, with so many of the response fields being unique, a method had 
 * to be devised 
 * @author cornettl
 *
 */
package com.earlywarning.authentication.responses;