/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.authentication.responses;

import com.earlywarning.authentication.common.ApiDriver;
import com.earlywarning.authentication.startup.Env;
import com.earlywarning.authentication.stepdefs.EmptyStepDef;
import com.earlywarning.authentication.utils.FileFinder;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import cucumber.api.Scenario;
import io.restassured.config.JsonConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.internal.ResponseParserRegistrar;
import io.restassured.internal.RestAssuredResponseImpl;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * A class that reads the responses.json file and retrieves the text for the expected response.
 * The text is then converted into a RestAssured response. It is worth noting that the Response
 * may be either JSON or XML as determined by the responses.json file.
 * @author cornettl
 *
 */
@Log4j2
public class ExpectedResponseRetriever {
	private static ExpectedResponses expected;

	/**
	 * The only public method for this class. 
	 * @param contentType The contentType of the response to retrieve.
	 * @return An instance of the Response class.
	 */
	public Response retrieveExpectedResponse(String contentType) {
		return getExpectedResponse(contentType);
	}
	
	/**
	 * A method to retrieve the name of the currently running scenario.
	 * @return The name of tthe current scenario
	 */
	private String getScenario() {
		Scenario scenario = EmptyStepDef.scenario;
		String scenarioName = scenario.getName();
		return scenarioName;
	}
	
	/**
	 * A method to read the responses.json file and populate the ExpectedResponses class
	 */
	private void setExpectedResponses() {
		String responseFile = Env.getProperty("responseFile");
		String filePath = FileFinder.find(responseFile);
		File file = new File(filePath);
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			if (null == expected) {
				expected = mapper.readValue(file, ExpectedResponses.class);
			}
		} catch (JsonParseException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (JsonMappingException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		} catch (IOException e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
	}
	
	/**
	 * a method that processes the ExpectedResponses list filtering the responses 
	 * for the environment and the scenario name to return the response that is 
	 * appropriate for the current scenario.
	 * @return An instance of a RestAssured Response class.
	 */
	private io.restassured.response.Response getExpectedResponse(final String contentType) {
		String expectedString = null;
		ArrayList<com.earlywarning.authentication.responses.Response> responses = null;
        List<com.earlywarning.authentication.responses.Response> res =null;
		String scenarioName = getScenario();
		String environment = Env.getProperty("environment");
		String payfoneEnvironment = Env.getProperty("payfoneEnvironment");
		io.restassured.response.Response raResponse = null;
		List<com.earlywarning.authentication.responses.Response> finalResponses = new ArrayList<com.earlywarning.authentication.responses.Response>();

		if (null == expected) {
			setExpectedResponses();
		}

		responses = expected.getResponses();
		
		 res = responses.stream()
			.filter(response -> response.getScenario().equals(scenarioName))
			.filter(response -> response.getContentType().equals(contentType))
			.collect(Collectors.toList());
		
		for (com.earlywarning.authentication.responses.Response response : res) {
			if (response.getEnvironment().equals(environment) || response.getEnvironment().isEmpty()) {
				if (response.getPayfoneEnvironment().equals(payfoneEnvironment) || response.getPayfoneEnvironment().isEmpty()) {
					finalResponses.add(response);
				}
			}
		}
		
		if ((finalResponses.size() > 1) || (finalResponses.size() == 0)) {
			log.error("The number of expected responses returned is: " + finalResponses.size() + ". Please review the expected responses file and correct the situation. Returning the first response in the list.");
			raResponse = createResponse(finalResponses.get(0).getExpectedResponse(), contentType);
		} else {
			raResponse = createResponse(finalResponses.get(0).getExpectedResponse(), contentType);
		}
		
		return raResponse;		
	}

    /**
     * A method that gets the value from response and can be called only in this class.
     * @param resp actualResponse
     * @param key key of the value. Either xml or json.
     * @return An instance of the RestAssured Response class
     */
    private String getValue(Response resp, String key) {
        if(resp.getContentType().contains("xml")){
            return ApiDriver.retrieveXMLvaluefromTag(resp, key);
        }
        return ApiDriver.retrieveJsonValueString(resp, key);
    }

    /**
	 * A method that creates an instance of a RestAssured Response class from a string.
	 * @param source The string containing the text for the expected response.
	 * @param contentType The contentType of the expected response. Either xml or json.
	 * @return An instance of the RestAssured Response class
	 */
	private io.restassured.response.Response createResponse(String source, String contentType) {
		Parser parser = null;
		RestAssuredResponseImpl impl = new RestAssuredResponseImpl();
		io.restassured.response.Response response = null;

		
		if (contentType.equals("text/xml")) {
			parser = Parser.XML;
		} else {
			parser = Parser.JSON;
		}
		
		impl.setContent(source);
		impl.setContentType(contentType);
		ResponseParserRegistrar rpr = new ResponseParserRegistrar();
		rpr.registerParser(contentType, parser);
		impl.setRpr(rpr);
		impl.setConfig(new RestAssuredConfig().jsonConfig(new JsonConfig()));
		response = impl;

		return response;
	}

}
