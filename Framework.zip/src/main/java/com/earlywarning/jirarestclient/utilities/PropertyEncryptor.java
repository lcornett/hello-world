/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.jirarestclient.utilities;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * A simple GUI for encrypting strings and copying them to the clipboard.
 * @author cornettl
 *
 */
public class PropertyEncryptor {

	private JFrame frmPropertyEncryptor;
	JTextField txtInput;
	JTextField txtResult;
	JButton btnEncrypt;
	JButton btnCopy;

	/**
	 * Launch the application.
	 * @param args This method expects no parameters
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PropertyEncryptor window = new PropertyEncryptor();
					window.frmPropertyEncryptor.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PropertyEncryptor() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		EncryptionListener listener = new EncryptionListener(this);
		
		frmPropertyEncryptor = new JFrame();
		frmPropertyEncryptor.setTitle("Property Encryptor");
		frmPropertyEncryptor.setBounds(100, 100, 450, 168);
		frmPropertyEncryptor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frmPropertyEncryptor.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblInput = new JLabel("String to Encrypt:");
		lblInput.setBounds(22, 20, 131, 16);
		panel.add(lblInput);
		
		JLabel lblResult = new JLabel("Encrypted String:");
		lblResult.setBounds(22, 48, 129, 16);
		panel.add(lblResult);
		
		txtInput = new JTextField();
		txtInput.setBounds(137, 15, 211, 26);
		txtInput.addFocusListener(listener);
		txtInput.addActionListener(listener);
		panel.add(txtInput);
		txtInput.setColumns(10);
		
		txtResult = new JTextField();
		txtResult.setEditable(false);
		txtResult.setColumns(10);
		txtResult.setBounds(137, 43, 211, 26);
		panel.add(txtResult);
		
		btnEncrypt = new JButton("Encrypt");
		btnEncrypt.setEnabled(false);
		btnEncrypt.setBounds(92, 99, 117, 29);
		btnEncrypt.addActionListener(listener);
		panel.add(btnEncrypt);
		
		btnCopy = new JButton("Copy");
		btnCopy.setEnabled(false);
		btnCopy.setBounds(241, 99, 117, 29);
		btnCopy.addActionListener(listener);
		panel.add(btnCopy);
	}
}

