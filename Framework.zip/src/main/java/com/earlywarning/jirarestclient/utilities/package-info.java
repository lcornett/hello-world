/**
 * 
 */
/**
 * This package contains utility classes required to configure the ability to connect to 
 * Jira.
 * @author cornettl
 *
 */
package com.earlywarning.jirarestclient.utilities;